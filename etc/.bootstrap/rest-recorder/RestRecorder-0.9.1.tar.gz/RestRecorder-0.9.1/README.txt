RestRecorder
------------

A tool that submits a set of predefined REST commands against REST enabled targets and records output.
Please read the docs/rest-recorder/README.txt file for further instructions.
