#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: WebServer
#   A simple front-end (rest API) for retreieve status, configuration informationand statistics for RR.
#
# Authors: Albert Pang, Thomas Bastian
#
'''

import logging
from .RestRecorder import RestRecorder
from aiohttp import web
from json import dumps, loads, JSONEncoder
from json.decoder import JSONDecodeError

DEFAULT_WEB_SERVER_PORT = 9988

DEFAULT_LOGGING_LEVEL = 'INFO'
VALID_LOGGING_LEVELS = {'NOTSET': 0, 'DEBUG': 10, 'INFO': 20, 'WARNING': 30, 'ERROR': 40, 'CRITICAL': 50}
VALID_LOGGING_LEVELS_LOOKUP = {v: k for k, v in VALID_LOGGING_LEVELS.items()}

# Logger
log = logging.getLogger(__name__)

class ComplexEncoder(JSONEncoder):
    def default(self, obj):
        if hasattr(obj, 'reprJSON'):
            return obj.reprJSON()
        else:
            print(obj)
            return JSONEncoder.default(self, obj)

async def statusHandler(request):
    data = {}
    data['status'] = 'ok'
    return web.json_response(data)

async def infoHandler(request):
    rr_context = RestRecorder.get_rr_context()
    data = {}
    if rr_context is None:
        data['status'] = 'error'
    else:
        data = await rr_context.reprJSON()
    return web.Response(text=dumps(data, cls=ComplexEncoder, sort_keys=True))

async def loggingGetHandler(request):
    data = {}
    data['loggers'] = {}

    for name, _ in logging.root.manager.loggerDict.items():
        if name.startswith('restrecorder'):
            logger = logging.getLogger(name)
            level = logger.getEffectiveLevel()
            data['loggers'][name] = VALID_LOGGING_LEVELS_LOOKUP.get(level, 'UNKNOWN')

    return web.json_response(data)


async def loggingPostHandler(request):
    data = dict()
    data['status'] = None

    content_type = request.headers.get('Content-Type', None)
    tdata = await request.text()
    params = {}
    if content_type == 'application/json':
        try:
            params = loads(tdata)
        except (JSONDecodeError) as e:
            data['status'] = 'failed'
            data['msg'] = str(e)

            return web.json_response(data)

    if params:
        new_level = params.get('level', DEFAULT_LOGGING_LEVEL)
        logger_names = params.get('loggers', [])
        for name, _ in logging.root.manager.loggerDict.items():
            if name in logger_names:
                log.info(f"setting logger {name} to {new_level}")
                logger = logging.getLogger(name)
                try:
                    logger.setLevel(new_level)
                except ValueError as e:
                    data['status'] = 'failed'
                    data['msg'] = str(e)
                    return web.json_response(data)

    data['status'] = 'ok'
    return web.json_response(data)


async def statsHandler(request):
    rr_context = RestRecorder.get_rr_context()
    data = {}
    if rr_context is None:
        data['status'] = 'error'
    else:
        data = await rr_context.reprStats()
    return web.Response(text=dumps(data, sort_keys=True))

async def statsFormattedHandler(request):
    rr_context = RestRecorder.get_rr_context()
    output = ""
    if rr_context is None:
        output = "STATUS: Error"
    else:
        output = await rr_context.reprStatsFormatted()
    return web.Response(text=output)

async def init_app() -> web.Application:
    '''
    All the available endpoints are added here.
    '''
    app = web.Application()
    app.add_routes([web.get("/", statusHandler)])
    app.add_routes([web.get("/info", infoHandler)])
    app.add_routes([web.get("/logging", loggingGetHandler)])
    app.add_routes([web.post("/logging", loggingPostHandler)])
    app.add_routes([web.get("/stats", statsHandler)])
    app.add_routes([web.get("/stats/formatted", statsFormattedHandler)])
    app.add_routes([web.get("/status", statusHandler)])

    return app

async def startWebServer(port=DEFAULT_WEB_SERVER_PORT):
    app = await init_app()
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, port=port)
    await site.start()
