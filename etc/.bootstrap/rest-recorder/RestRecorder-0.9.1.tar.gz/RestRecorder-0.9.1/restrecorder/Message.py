#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: message.
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
'''
#
'''

import logging
import os


# Logger
log = logging.getLogger(__name__)


# End of line (be DOS compatible and add \r)
MESSAGE_EOL = "\r\n"

# Message begin marker
MESSAGE_PREFIX = "///// "
    
# Message end marker
MESSAGE_END = "....."
    
# Tag separator
MESSAGE_TAG_SEPARATOR = ": "

# Message tag
MESSAGE_TAG_MESSAGE = "Message";

# Section tag
MESSAGE_TAG_SECTION = "Section";

# Message type controller
MESSAGE_TYPE_CONTROLLER = "CONTROLLER";

# Message type controller query
MESSAGE_TYPE_QUERY = "QUERY";
MESSAGE_TYPE_SUB_QUERY = "SUB-QUERY";

# Message type controller result
MESSAGE_TYPE_RESULT = "RESULT";


'''
# 
'''
class Message():
    def __init__(self, messageType=None):
        self.message = MESSAGE_PREFIX + MESSAGE_EOL
        if messageType is not None:
            self.message += MESSAGE_PREFIX + MESSAGE_TAG_MESSAGE + \
                MESSAGE_TAG_SEPARATOR + messageType + MESSAGE_EOL

    def addTag(self, tagName, tagValue):
        self.message += MESSAGE_PREFIX + tagName + \
            MESSAGE_TAG_SEPARATOR + tagValue + MESSAGE_EOL

    def addSection(self, sectionName, sectionValue):
        self.message += MESSAGE_PREFIX + MESSAGE_TAG_SECTION + \
                MESSAGE_TAG_SEPARATOR + sectionName + MESSAGE_EOL
        self.message += sectionValue
        if (len(sectionValue) > 0) and (not sectionValue.endswith("\n")):
            self.message += MESSAGE_EOL

    def __str__(self):
        self.message += MESSAGE_END + MESSAGE_EOL
        return self.message


'''
# 
'''
class MessageWriter():
    def __init__(self, pathMessage, pathPrefix, pathSuffix, 
            fileSizeLimit, printStream):
        self.pathMessage = pathMessage
        self.pathPrefix = pathPrefix
        self.pathSuffix = pathSuffix
        if fileSizeLimit <= 0:
            #Limit to 2G on purpose
            self.fileSizeLimit = 2**31
        else:
            self.fileSizeLimit = fileSizeLimit
        self.printStream = printStream
        self.fileNumber = 0
        self._initFile()

    def write(self, messageText):
        # TODO: check for string
        self.f.write(messageText)
        self.f.flush()

    def getOutputFilePath(self):
        fileNumberString = "%02d" % self.fileNumber
        return self.pathPrefix + "-" + fileNumberString + self.pathSuffix;

    def close(self):
        self.f.close()

    def _initFile(self):
        fpath = self.getOutputFilePath()
        try:
            # Always append
            self.f = open(fpath,"a+")
            flen = os.fstat(self.f.fileno()).st_size
            if flen <= 0:
                emptyMessage = Message()
                self.f.write(str(emptyMessage))
                self.f.flush()
            print(self.pathMessage + fpath, file=self.printStream)

        except IOError as e:
            raise e
