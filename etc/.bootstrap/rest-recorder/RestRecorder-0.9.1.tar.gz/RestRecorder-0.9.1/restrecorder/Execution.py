#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: abstract execution.
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
'''
#
'''

import asyncio
import json
import logging
import sys
import traceback
import types
from .actions.Action import ActionContext
from .RestRecorder import RestRecorder


# Logger
log = logging.getLogger(__name__)


'''
# Abstract execution.
'''
class Runnable():
    @staticmethod
    def buildScope(w, o, pscope=None, anames=[]):
        log.debug("o: %s, vars(o): %s, pscope: %s, anames: %s" % (o, vars(o), pscope, anames))
        cscope = {}
        if pscope is not None:
            cscope.update(pscope)
        for k, v in vars(o).items():
            if k.startswith("rr") or k in anames:
                cscope[k] = v
        log.debug("w: %s, cscope: %s" % (w, cscope))
        return cscope

    # ActionContext is the home of all local user variables (i.e. self.*)
    @staticmethod
    def buildActionContext(name, target, o, pscope=None, anames=[]):
        # Build actionContext based on scope from current object and parent scope
        return ActionContext(lscope=Runnable.buildScope(name, o, pscope=pscope, anames=anames), target=target)

    # TODO: needs to be kept in sync with ActionContext
    def setupLocalScope(self, scope):
        # Update current variables with scope
        vars(self).update(scope)
        # Add reference to self
        self.self = self
        # A generator that delivers an endless stream of self. Useful for list-comprehension
        self.rr_self = self.generator_self()

    def generator_self(self):
        while True:
            yield self

    async def process_actions(self, actionContext, actions, pipeline, currentData):
        if len(actions) > 0:
            # Process actions
            log.debug("%s pipeline in [%s]" % (pipeline, currentData))
            for action in actions:
                currentData = await actionContext.process(currentData, action)
            log.debug("%s pipeline out [%s]" % (pipeline, currentData))
        return currentData

    async def run(self):
        pass

    async def eval_targets(self, lscope):
        # Eval targets
        # Evaluate expression
        # The expression argument is parsed and evaluated as a python expression
        # (technically speaking, a condition list) using the globals and locals
        # dictionaries as global and local namespace. If the globals dictionary
        # is present and lacks '__builtins__', the current globals are copied
        # into globals before expression is parsed. This means that expression
        # normally has full access to the standard __builtin__ module and
        # restricted environments are propagated. If the locals dictionary is
        # omitted it defaults to the globals dictionary. If both dictionaries
        # are omitted, the expression is executed in the environment where eval()
        # is called. The return value is the result of the evaluated expression.
        # eval(expression[, globals[, locals]])
        try:
            rr_context = RestRecorder.get_rr_context()
            rr_globals = rr_context.get_rr_globals()
            targets = []
            (_eval_source, _eval_compile) = self.rr_rcommand.targets
            _targets = eval(_eval_compile, rr_globals, lscope)
            # TODO: check _targets is an array of dict()
            if _targets is None:
                return self.rr_defaultTargets
            for _target in _targets:
                try:
                    if "clone" in _target:
                        # Clone target
                        target = await rr_context.targets.clone(_target)
                    elif "name" in _target:
                        # Use named target
                        target = rr_context.targets.getTargetByName(_target["name"])
                        if target is None:
                            log.warning("target name [%s] does not exist" % (_target["name"]))
                            continue
                    else:
                        # Error
                        log.warning("target must either clone or reference existing target [%s]" % (_target))
                        continue
                    targets.append(target)
                except asyncio.CancelledError as e:
                    raise e
                except Exception as e:
                    log.warning("dynamic target exception [%s] [%s]" % (_target, e))
            return targets

        except asyncio.CancelledError as e:
            raise e

        except KeyError as e:
            log.warning("KeyError exception [%s] for eval [%s]" % \
                        (e, self.rr_rcommand.targets))

    def get_urls(self, rcommand_config):
        urls = []
        if rcommand_config["url"] is not None:
            urls.append(rcommand_config["url"])
            indexVariable = None
        else:
            indexVariable = rcommand_config["eurlvar"]
            urls = self.eval_eurl(rcommand_config)
        return (urls, indexVariable)

    def get_headers(self, rcommand_config):
        headers = dict()
        if rcommand_config["headers"] is not None:
            headers.update(rcommand_config["headers"])
        if rcommand_config["eheaders"] is not None:
            self.eval_kv(rcommand_config["eheaders"], headers)
        return headers

    def get_params(self, rcommand_config):
        params = dict()
        if rcommand_config["params"] is not None:
            params.update(rcommand_config["params"])
        if rcommand_config["eparams"] is not None:
            self.eval_kv(rcommand_config["eparams"], params)
        return params

    def get_body(self, rcommand_config):
        body = rcommand_config["body"]
        if body is None:
            body = ""
        _ebody = ""
        ebody = rcommand_config["ebody"]
        if ebody is not None:
            if type(ebody) == tuple:
                # Eval expression
                try:
                    rr_globals = RestRecorder.get_rr_context().get_rr_globals()
                    (_eval_source, _eval_compile) = ebody
                    _ebody = eval(_eval_compile, rr_globals, locals())
                    if type(_ebody) != bytes and types(_ebody) != str:
                        _ebody = str(_ebody)
                except KeyError as e:
                    log.warning("KeyError exception [%s] for eval [%s]" % \
                                (e, _eval_source))
            elif type(ebody) == dict:
                # Eval dictionary
                _ebody = {}
                self.eval_kv(ebody, _ebody)
                _ebody = json.dumps(_ebody)
            else:
                raise Exception("bad ebody type [%s]" % type(ebody))
        # TODO: return bytes here?
        return body + _ebody

    def set_variable(self, indexVariable, content):
        if indexVariable is not None:
            vars(self).update({indexVariable: content})
            log.debug("indexVariable [%s] [%s]" % (indexVariable, vars(self)[indexVariable]))

    def reset_variable(self, indexVariable):
        if indexVariable is not None:
            vars(self).pop(indexVariable, None)

    def eval_eurl(self, rcommand_config):
        # Eval <variable> <method> <dynamic url>
        # The expression argument is parsed and evaluated as a python expression
        # (technically speaking, a condition list) using the globals and locals
        # dictionaries as global and local namespace. If the globals dictionary
        # is present and lacks '__builtins__', the current globals are copied
        # into globals before expression is parsed. This means that expression
        # normally has full access to the standard __builtin__ module and
        # restricted environments are propagated. If the locals dictionary is
        # omitted it defaults to the globals dictionary. If both dictionaries
        # are omitted, the expression is executed in the environment where eval()
        # is called. The return value is the result of the evaluated expression.
        # eval(expression[, globals[, locals]])
        try:
            rr_globals = RestRecorder.get_rr_context().get_rr_globals()
            eurl = eval(rcommand_config["eurl"], rr_globals, locals())
            # TODO: assume eurl is an array here
            return eurl

        except KeyError as e:
            log.warning("KeyError exception [%s] for eval [%s]" % \
                        (e, rcommand_config["eurl"]))

    def eval_kv(self, kv_source, kv_store):
        # Eval <key>: <value>
        # The expression argument is parsed and evaluated as a python expression
        # (technically speaking, a condition list) using the globals and locals
        # dictionaries as global and local namespace. If the globals dictionary
        # is present and lacks '__builtins__', the current globals are copied
        # into globals before expression is parsed. This means that expression
        # normally has full access to the standard __builtin__ module and
        # restricted environments are propagated. If the locals dictionary is
        # omitted it defaults to the globals dictionary. If both dictionaries
        # are omitted, the expression is executed in the environment where eval()
        # is called. The return value is the result of the evaluated expression.
        # eval(expression[, globals[, locals]])
        try:
            rr_globals = RestRecorder.get_rr_context().get_rr_globals()
            for (k, v) in kv_source.items():
                # v is a tuple (<original eval>, <compiled eval>)
                (_eval_source, _eval_compile) = v
                ev = eval(_eval_compile, rr_globals, locals())
                kv_store[k] = ev

        except KeyError as e:
            log.warning("KeyError exception [%s] for eval [%s]" % \
                        (e, kv_source.items()))


'''
# An ExecutionTaskContext
'''
class ExecutionTaskContext():
    def __init__(self, scope):
        self.scope = scope
        self.adata_task = []

    def merge(self, adata):
        log.debug("merging adata [%s]" % (adata))
        self.adata_task.append(adata)

    def get(self):
        return self.adata_task


'''
# ExecutionFuture
'''
class ExecutionFuture():
    def __init__(self, runnable):
        self.runnable = runnable
        self.future = None
        try:
            self.future = asyncio.create_task(runnable.run())
            log.debug("future task submit [%s] [%s]" %
                      (self.runnable, self.future))
            # Add task to global task list
            rr_context = RestRecorder.get_rr_context()
            rr_context.taskAdd(self.future)

        except asyncio.CancelledError as e:
            raise e

        except Exception as e:
            log.error("future submit failed(e) [%s]" % (e))

        finally:
            pass

    async def get(self):
        v = None
        try:
            if self.future is not None:
                await self.future
                v = self.future.result()
                # Remove task from global task list
                rr_context = RestRecorder.get_rr_context()
                rr_context.taskDel(self.future)
            log.debug("future result [%s]" % (v))

        except asyncio.CancelledError as e:
            # Task is being cancelled
            log.debug("future cancelled [%s]" % (self.future))
            raise e

        except Exception as e:
            traceback.print_exc(file=sys.stdout)
            log.error("future result failed(e) [%s]" % (e))

        finally:
            pass

        return v
