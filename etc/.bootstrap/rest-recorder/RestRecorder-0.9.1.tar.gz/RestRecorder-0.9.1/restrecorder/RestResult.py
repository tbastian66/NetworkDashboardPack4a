#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: result.
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
'''
#
'''

import json
import logging
import math
import time
from .Message import Message, MESSAGE_TYPE_RESULT


# Logger
log = logging.getLogger(__name__)


'''
# 
'''
class RestResult():
    DATA_KEY_LABEL = "label"
    DATA_KEY_ORIGIN = "origin"
    DATA_KEY_PARTITION = "partition"

    def __init__(self):
        # Associated query
        self.query = None
        # Status: < 0 => typically HTTP status code, else >=0 byte count
        self.status = -1
        # Output text/body
        self.stdout = ""
        # localBeginTime in time.time() format
        self.localBeginTime = None
        # localEndTime in time.time() format
        self.localEndTime = None
        # resultTags: optional dictionary
        self.resultTags = None
        # Dynamic runtime data only
        self.kvData = None
        # Underlying Requests.response
        self.response = None
        # Source
        self.source = None

    def headerAsDict(self, label=None):
        d = { "Source": self.source, "Label": "default/default", "Status": self.status, 
              "LocalBeginTime": self.localBeginTime, "LocalEndTime": self.localEndTime }
        _label = self.getData(RestResult.DATA_KEY_LABEL)
        if _label is not None:
            d["Label"] = _label
        if label is not None:
            d["Label"] = label
        _origin = self.getData(RestResult.DATA_KEY_ORIGIN)
        if _origin is not None:
            d["Origin"] = _origin
        if self.query is not None:
            d.update({ "Query": self.query.asDict() })
        if self.resultTags is not None:
            d.update({ "Tags": self.resultTags })
        return d

    def asDict(self, rrHeader=None, rrStdout=None):
        d = dict()
        if rrHeader is None:
            rrHeader = self.headerAsDict()
        d['RR.HEADER'] = rrHeader
        if rrStdout is None:
            rrStdout = self.stdout
        d['Stdout'] = rrStdout
        return d

    def setData(self, key, value):
        if self.kvData is None:
            self.kvData = {}
        self.kvData[key] = value

    def getData(self, key):
        if self.kvData is None:
            return None
        return self.kvData.get(key, None)

    def __str__(self):
        message = Message(MESSAGE_TYPE_RESULT)

        message.addTag("Status", str(self.status))

        if ((self.localBeginTime is not None) and (self.localEndTime is not None)):
            self._addDateTimeTag(message, "LocalBeginTime", self.localBeginTime);
            self._addDateTimeTag(message, "LocalEndTime", self.localEndTime);

        # Dump everything else as proper JSON
        message.addTag("Json", json.dumps(self.headerAsDict()))

        if self.query is not None:
            message.addTag("Command", str(self.query))

        message.addSection("Stdout", self.stdout)

#        Throwable throwable = getThrowable();
#        if (throwable != null) {
#            StringBuilder causeMessage = new StringBuilder();
#            while (throwable != null) {
#                String throwableMessage = throwable.getMessage();
#                if (throwableMessage == null) {
#                    throwableMessage = "<unknown>";
#                }
#                throwableMessage += MESSAGE_EOL;
#                causeMessage.append(throwableMessage);
#                throwable = throwable.getCause();
#            }
#            message.addSection("Cause", causeMessage.toString());
#        }
        
        return str(message)

    def _addDateTimeTag(self, message, tag, timestamp):
        pd1 = time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(timestamp))
        (ts_frac, ts_whole) = math.modf(timestamp)
        ts_frac = ("%.6f" % ts_frac)[1:]
        tlt = time.localtime(timestamp)
        tgm = time.gmtime(timestamp)
        hh = tlt[3] - tgm[3]
        mm = tlt[4] - tgm[4]
        sign = '+' if hh >= 0 else '-'
        dateOutput = ("%.6f" % timestamp) + " (" + pd1 + ts_frac + sign + ("%02d" % hh) + (":%02d" % mm) + ")"
        message.addTag(tag, dateOutput)
