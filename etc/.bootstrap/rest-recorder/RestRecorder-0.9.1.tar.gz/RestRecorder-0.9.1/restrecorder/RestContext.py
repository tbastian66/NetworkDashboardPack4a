#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: context.
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
'''
#
'''

import asyncio
import logging


# Logger
log = logging.getLogger(__name__)


'''
# Context object for holding state across invocations
# - requests.Session - session
'''
class RestContext():
    def __init__(self, userContext=None, baseURL=None, target=None):
        log.debug("creating context with userContext [%s], baseURL [%s], target [%s]" %
                  (userContext, baseURL, target))
        self.userContext = userContext
        self.baseURL = baseURL
        self.target = target
        self.session = None
        self.defaultParams = None
        self.defaultHeaders = None
        self.sessionOpenHook = None
        self.sessionCloseHook = None

    def __enter__(self):
        log.debug("__enter__ called")
        try:
            self.sessionOpenHook(self)

        except Exception as e:
            log.error("failed to open session [%s]" % (e))
            return None

        return self

    def __exit__(self, exc_type, exc_value, traceback):
        log.debug("__exit__ called [%s] [%s] [%s]" % (exc_type, exc_value, traceback))
        try:
            self.sessionCloseHook(self)

        except Exception as e:
            log.error("failed to close session [%s]" % (e))

        return False

    async def __aenter__(self):
        log.debug("__aenter__ called")
        try:
            await self.sessionOpenHook(self)

        except asyncio.CancelledError as e:
            raise e

        except Exception as e:
            log.error("failed to open session [%s]" % (e))
            return None

        return self

    async def __aexit__(self, exc_type, exc_value, traceback):
        log.debug("__aexit__ called [%s] [%s] [%s]" % (exc_type, exc_value, traceback))
        try:
            await self.sessionCloseHook(self)

        except asyncio.CancelledError as e:
            raise e

        except Exception as e:
            log.error("failed to close session [%s]" % (e))

        return False
