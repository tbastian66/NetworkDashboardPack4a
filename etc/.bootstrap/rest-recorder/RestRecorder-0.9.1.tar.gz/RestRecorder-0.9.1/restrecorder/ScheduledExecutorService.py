#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# ScheduledExecutorService
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
'''
#
'''

import asyncio
import logging
import sys
import time
import traceback
from .RestRecorder import RestRecorder


# Logger
log = logging.getLogger(__name__)


# Wrapper to submit job
def jobSubmit(job):
    # Remove timer handle
    del job.stp.timers[job]
    # Submit job
    try:
        t = asyncio.create_task(job.run())
        log.debug("future task [%s]" % (str(t)))
        job.stp.tasks.append(t)
    except asyncio.CancelledError as e:
        raise e
    except Exception as e:
        log.error("future task failed(e) [%s]" % (e))


'''
# Drop-in replacement for Java ScheduledExecutorService
'''
class ScheduledExecutorService():
    def __init__(self):
        # Dict of job: timerHandle
        self.timers = {}
        # List of tasks
        self.tasks = []

    async def awaitTermination(self, timeout, timeUnit):
        try:
            _sleepTime = TimeUnit.getTime(timeout, timeUnit)
            await asyncio.sleep(_sleepTime)
            # Reap tasks that are done
            for t in self.tasks:
                if t.done():
                    self.tasks.remove(t)
        except asyncio.CancelledError as e:
            raise e
        except Exception:
            traceback.print_exc(file=sys.stdout)
        return self.getActiveCount() == 0

    def getActiveCount(self):
        return len(self.timers) + len(self.tasks)

    # schedule(Runnable command, long delay, TimeUnit unit)
    def schedule(self, runnable, initialDelay, timeUnit):
        job = self.getJob(runnable, initialDelay, 0, timeUnit)
        loop = asyncio.get_running_loop()
        ev = loop.call_later(job.getInitialDelay(), jobSubmit, job)
        self.timers[job] = ev
        log.debug("JOB schedule [%s]" % (str(ev)))

    # scheduleAtFixedRate(Runnable command, long initialDelay, long period, TimeUnit unit)
    def scheduleAtFixedRate(self, runnable, initialDelay, period, timeUnit):
        job = self.getJob(runnable, initialDelay, period, timeUnit)
        loop = asyncio.get_running_loop()
        ev = loop.call_later(job.getInitialDelay(), jobSubmit, job)
        self.timers[job] = ev
        log.debug("JOB schedule fixed rate [%s]" % (str(ev)))

    async def shutdownNow(self):
        log.debug("shutdownNow")
        # Cancel all scheduled timers
        for _, ev in self.timers.items():
            log.debug("cancel timer [%s]" % (ev))
            ev.cancel()
        for t in self.tasks:
            log.debug("cancel task [%s]" % (t))
            t.cancel()
        for t in self.tasks:
            try:
                await t
            except asyncio.CancelledError:
                pass
            except Exception as e:
                log.error("future task wait(e) [%s]" % (e))

    def getJob(self, runnable, initialDelay, period, timeUnit):
        _initialDelay = TimeUnit.getTime(initialDelay, timeUnit)
        _period = TimeUnit.getTime(period, timeUnit)
        runAt = time.monotonic() + _initialDelay
        return Job(runnable, _initialDelay, _period, runAt, self)


'''
# Drop-in replacement for Java TimeUnit
'''
class TimeUnit():
    SECONDS = 1
    MILLISECONDS = 2

    @staticmethod
    def getTime(time, timeUnit):
        if timeUnit == TimeUnit.SECONDS:
            divideBy = 1.0
        elif timeUnit == TimeUnit.MILLISECONDS:
            divideBy = 1000.0
        else:
            raise "unknown timeUnit"
        return float(time) / divideBy


'''
# asyncio callback to execute job runnable and schedule next run if any
'''
class Job():
    def __init__(self, runnable, initialDelay, period, runAt, stp):
        self.runnable = runnable
        self.initialDelay = initialDelay
        self.period = period
        self.runAt = runAt
        self.stp = stp

    def getInitialDelay(self):
        return self.initialDelay

    async def run(self):
        # Run JOB
        try:
            log.debug("JOB start [%s]" % (self))
            await self.runnable.run()
            log.debug("JOB end [%s]" % (self))
        except asyncio.CancelledError as e:
            raise e
        except Exception:
            traceback.print_exc(file=sys.stdout)
        finally:
            pass

        try:
            if self.period > 0:
                # Reschedule
                now = time.monotonic()
                self.runAt = self.runAt + self.period
                delay = self.runAt - now
                if delay < 0:
                    delay = 0
                loop = asyncio.get_running_loop()
                ev = loop.call_later(delay, jobSubmit, self)
                self.stp.timers[self] = ev
                log.debug("JOB reschedule [%s]" % (str(ev)))
        except asyncio.CancelledError as e:
            raise e
        except Exception:
            traceback.print_exc(file=sys.stdout)
