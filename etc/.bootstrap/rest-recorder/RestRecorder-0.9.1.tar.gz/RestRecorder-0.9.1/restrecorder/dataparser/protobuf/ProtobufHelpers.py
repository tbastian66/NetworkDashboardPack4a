#
# Copyright 2021 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: Google Protobuf helpers.
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
'''
#
'''

import base64
import logging
import socket
import struct
from google.protobuf.descriptor import FieldDescriptor
from google.protobuf.reflection import MakeClass


# Logger
log = logging.getLogger(__name__)


# Converters
def bytes2str(v):
    return base64.b64decode(v).decode('utf-8')

def str2uint64(v):
    return int(v)

def str2int64(v):
    return int(v)

def ip2str(v):
    if v['af'] == 'ADDR_FAMILY_INET':
        # IPv4
        addr = base64.b64decode(v['addr'])
        if len(addr) == 0:
            v = None
        else:
            #(ip) = struct.unpack("!I", b)
            try:
                v = socket.inet_ntop(socket.AF_INET, addr)
            except ValueError:
                v = addr.decode("utf-8")
    elif v['af'] == 'ADDR_FAMILY_INET6':
        # IPv6
        addr = base64.b64decode(v['addr'])
        if len(addr) == 0:
            v = None
        else:
            try:
                v = socket.inet_ntop(socket.AF_INET6, addr)
            except ValueError:
                v = addr.decode("utf-8")
    else:
        v = None
    return v

def mac2str(v):
    #v = base64.b64decode(v['addr']).hex()
    return "%02x:%02x:%02x:%02x:%02x:%02x" % struct.unpack("BBBBBB", base64.b64decode(v['addr']))

def presence_mac2str(v):
    mac_address = base64.b64decode(v['addr']).lower().decode('utf-8')
    return ':'.join(format(s, '02x') for s in bytes.fromhex(mac_address))

def uint642ip(v):
    b = struct.pack('!Q', v)
    return socket.inet_ntop(socket.AF_INET, b[-4:])


'''
# Collection of protobuf related helpers
#
'''
class ProtobufHelpers():

    @staticmethod
    def processObjects(rootObjects):
        for k, v in rootObjects.items():
            fields = []
            log.debug("collecting fields for: %s, %s, %s" % (k, v['root'], v['messages']))
            ProtobufHelpers.processObject(v['root'], v['messages'], fields, None)
            v['fields'] = fields
            log.debug('---')
            for field in fields:
                log.debug(field)
            log.debug('-')

    @staticmethod
    def processObject(messageObject, messages, fields, path):
        if path is None:
            path = []
        names = []
        clazz = str(messageObject)
        valueConverter = messages.get(clazz, None)
        if valueConverter is not None:
            log.debug("clazz match: %s" % (clazz))
            names.append((path[-1], valueConverter))
            fields.append((path[0:-1], names))
            return
        for field in messageObject.DESCRIPTOR.fields:
            #log.debug("field: %s %s %s" % (field.name, field.full_name, field.containing_type))
            if field.message_type is not None:
                # Another message
                childMessageObject = MakeClass(field.message_type)
                childPath = path.copy()
                childPath.append(field.json_name)
                ProtobufHelpers.processObject(childMessageObject, messages, fields, childPath)
            elif field.type == FieldDescriptor.TYPE_UINT64:
                # UINT64
                log.debug("uint64: %s, %s" % (field.json_name, path))
                names.append((field.json_name, str2uint64))
            elif field.type == FieldDescriptor.TYPE_INT64:
                # INT64
                log.debug("int64: %s, %s" % (field.json_name, path))
                names.append((field.json_name, str2int64))
            elif field.type == FieldDescriptor.TYPE_BYTES:
                # BYTES
                log.debug("bytes: %s, %s" % (field.json_name, path))
                names.append((field.json_name, bytes2str))
        if len(names) > 0:
            fields.append((path, names))

    @staticmethod
    def convertFields(rootObject, messageDict):
        for field in rootObject['fields']:
            # Work on path
            (path, names) = field
            log.debug("processing field %s %s" % (path, names))
            convertField(path, messageDict, names)


def convertField(path, d, names):
    log.debug("recurse path: %s, d: %s, names: %s" % (path, d, names))
    if len(path) == 0:
        for name, converter in names:
            if not name in d:
                continue
            iv = d[name]
            try:
                d[name] = converter(iv)
                log.debug("converting name: %s, from: %s, to: %s", name, iv, d[name])
            except Exception as e:
                log.error("failed converting name: %s, from: %s/%d, with: %s, reason: %s", name, iv, len(iv), converter, e)
    else:
        p = path[0]
        if p in d:
            d = d[p]
            if isinstance(d, list):
                for _d in d:
                    convertField(path[1:], _d, names)
            else:
                convertField(path[1:], d, names)
