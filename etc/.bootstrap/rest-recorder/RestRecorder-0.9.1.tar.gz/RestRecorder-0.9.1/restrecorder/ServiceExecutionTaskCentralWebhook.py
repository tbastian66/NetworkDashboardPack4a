#
# Copyright 2024 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: service execution task for service-central-webhook.
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
'''
#
'''

import asyncio
import logging
import ssl
import time
import traceback
from .Execution import Runnable, ExecutionTaskContext, ExecutionFuture
from .RestQuery import RestQuery
from .RestResult import RestResult
from aiohttp import web, MultipartReader


# Logger
log = logging.getLogger(__name__)


'''
# A ServiceExecutionTask* exists per active target
'''
class ServiceExecutionTaskCentralWebhook(Runnable):
    def __init__(self, target, rcommand, taskContext):
        # Setup local scope
        self.setupLocalScope(taskContext.scope)
        # Use the reserved namespace
        self.rr_target = target
        self.rr_rcommand = rcommand
        self.rr_taskContext = taskContext

    # Override
    async def run(self):
        # MUST catch all exceptions
        try:
            log.debug("task execution start [%s]" % (self.rr_target.name))
            target_config = self.rr_target.config

            # By default SSL is disabled
            ssl_context = None
            if "certificate_file" in target_config and "certificate_key" in target_config:
                ssl_context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
                ssl_context.load_cert_chain(target_config["certificate_file"], target_config["certificate_key"])
            app = web.Application()
            app['_rr_task'] = self
            app.add_routes([
                web.post('/', handle_message),
            ])
            runner = web.AppRunner(app)
            await runner.setup()
            site = web.TCPSite(runner, port=target_config["port"], ssl_context=ssl_context)
            await site.start()
            log.debug("runner up [%s]" % (self.rr_target.name))
            while True:
                await asyncio.sleep(30)
            await runner.cleanup()

        except asyncio.CancelledError as e:
            # Task is being cancelled
            log.debug("[%s] execution cancelled [%s]" % (self.rr_target.name, self))
            raise e

        except Exception as e:
            traceback.print_exc()
            log.error("[%s] task execution failed(e) [%s]" % (self.rr_target.name, e))

        finally:
            pass


'''
# Handler for /
'''
async def handle_message(request):
    log.debug("request: [%s] headers: [%s]" % (request, request.headers))
    rr_task = request.app['_rr_task']
    t0 = time.perf_counter()
    pdata = await request.json()

    # Here we generate a pseudo RestResult
    restResult = RestResult()
    restResult.localBeginTime = restResult.localEndTime = time.time()
    restResult.source = rr_task.rr_target.config["name"]
    restResult.status = 0 if request.content_length is None else request.content_length
    restResult.stdout = pdata
    rr_task.rr_result = restResult

    actionContext = Runnable.buildActionContext("action: opipe", rr_task.rr_target,
                                                rr_task, pscope=rr_task.rr_taskContext.scope)
    currentOutput = await rr_task.process_actions(actionContext,
                                                  rr_task.rr_rcommand.oactions,
                                                  "opipe",
                                                  pdata)

    t1 = time.perf_counter()
    log.debug("processed in %d ms" % ((t1 - t0) * 1000))
    return web.Response(status=200)
