#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# Common services
#
# Authors: Thomas Bastian, Jeff Goff
#
#
'''

'''
# Parameters
'''
'''
#
'''

import json
import logging
from csv import DictWriter, DictReader
from yaml import load, dump, FullLoader
from yaml.scanner import ScannerError


# Logger
log = logging.getLogger(__name__)


def loadJsonContentProvider(target, targetOptions, path):
    log.debug("loading JSON content [%s] [%s] [%s]" % (target, targetOptions, path))
    if targetOptions.contentProvider is None:
        # File content
        return loadJsonFile(path)
    else:
        # TODO: other content
        return (None, None)


def loadJsonFile(fileName):
    log.debug("loading JSON file [%s]" % (fileName))
    try:
        f = open(fileName, 'r')
        fileContent = f.read()
        f.close()
        fileJson = json.loads(fileContent)
        log.debug("loaded JSON [%s]" % (fileJson))
        return (fileJson, None)

    except Exception as e:
        log.debug("loading JSON failed [%s]" % (e))
        return (None, e)


def saveJsonFile(fileName, data):
    log.debug("saving JSON file [%s]" % (fileName))
    try:
        fileContent = json.dumps(data)
        log.debug("saved text [%s]" % (fileContent))
        f = open(fileName, 'w')
        f.write(fileContent)
        f.close()
        return None

    except Exception as e:
        log.debug("saving JSON failed [%s]" % (e))
        return e


class YmlError(Exception):
    def __init__(self, message, e=None):
        Exception.__init__(self)
        self.message = message
        self.e = e


def loadYmlContent(contentProvider):
    log.debug("loading YML content from [%s]" % (contentProvider))
    try:
        # Make use of ContentProvider auto format detection
        content = load(contentProvider.getContentYml(), Loader=FullLoader)
        log.debug("loaded YML [%s]" % (content))
        return (content, None)

    except ScannerError as e:
        log.debug("loading YML failed [%s] [%s]" % (e, type(e)))
        return (None, YmlError(str(e)))

    except Exception as e:
        log.debug("loading YML failed [%s] [%s]" % (e, type(e)))
        return (None, e)


def requestsResponseDump(response):
    text = "\n>>> "
    text += str(response.url) + " " + str(response.status) + "\n"
    text += "REQUEST HEADERS: " + str(response.request_info.headers) + "\n"
    #text += "REQUEST COOKIES: " + str(response.request.cookies) + "\n"
    #text += "REQUEST BODY: " + str(response.request_info.body) + "\n"
    text += "RESPONSE HEADERS: " + str(response.headers) + "\n"
    text += "RESPONSE COOKIES: " + str(response.cookies) + "\n"
    #text += "RESPONSE TEXT: " + str(response.text) + "\n"
    text += "---"
    return text


def requestsResponseDumpOverview(response):
    text = ">>> "
    text += str(response.status) + " " + str(response.url)
    if response.headers is not None:
        text += " " + response.headers.get('Content-Length', '?')
        text += " " + response.headers.get('Content-Type', '?')
    return text


def intervalToSeconds(interval):
    if interval.endswith("s"):
        return float(interval[:-1])
    elif interval.endswith("m"):
        return float(interval[:-1]) * 60
    elif interval.endswith("h"):
        return float(interval[:-1]) * 60 * 60
    elif interval.endswith("d"):
        return float(interval[:-1]) * 24 * 60 * 60
    else:
        return float(interval)


'''
#
# Returns all rows of a CSV file.
#
'''
def loadCsvFile(fileName, delimiter=',', quotechar='"', flags='rtU', fields=None):
    rows = []
    # U flag for MacOS
    f = open(fileName, flags)
    reader = DictReader(f, delimiter=delimiter, quotechar=quotechar, fieldnames=fields)
    for row in reader:
        rows.append(row)
    f.close()
    return rows

'''
#
# Writes all rows to a CSV file.
#
'''
def writeCsvFile(rows, fileName, flags='wb', fields=None):
    f = open(fileName, flags)
    writer = DictWriter(f, fieldnames=fields, extrasaction="ignore")
    if fields is not None:
        csvHeader = dict((key,key) for key in fields)
        writer.writerow(csvHeader)
    for row in rows:
        writer.writerow(row)
    f.close()
