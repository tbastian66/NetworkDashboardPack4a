#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: rcommands processing.
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
'''
#
'''

import asyncio
import json
import logging
from .actions.Action import Action
from .actions.ActionParser import ActionParser
from .Commons import loadYmlContent, intervalToSeconds, YmlError


# Logger
log = logging.getLogger(__name__)


'''
# RCommandConfigError.
'''
class RCommandConfigError(Exception):
    def __init__(self, message, rcommand=None, e=None):
        Exception.__init__(self)
        self.message = message
        self.rcommand = rcommand
        self.e = e


'''
# RCommandSchedule
'''
class RCommandSchedule():
    # Special schedules
    SCHEDULE_BEGIN = -1
    SCHEDULE_END = -2
    SCHEDULE_NAME = -3
    SCHEDULE_WS = -4
    SCHEDULE_SERVICE = -5

    def __init__(self):
        # Seconds between two executions
        self.interval = None
        # Execution count per cycle
        self.executionCountPerCycle = None
        # Seconds between two cycles
        self.cycleInterval = None
        # Number of cycles
        self.cycleCount = None
        # Execution duration (i.e. interrupt after)
        self.executionDuration = None
        # Datasource name
        self.datasourceName = None
        # WebSocket type
        self.wsType = None
        # Service type
        self.serviceType = None

    def __str__(self):
        return "RCommandSchedule: %s/%s" % \
            (self.interval, self.datasourceName)

    @staticmethod
    def parse(schedule, printStream=None):
        splits = str(schedule).split(';')
        log.debug("schedule [%s] splits [%s]" % (schedule, splits))
        if splits is None:
            raise Exception("split() returned None")
        lsplits = len(splits)

        if lsplits == 5:
            pass
        elif lsplits == 4:
            pass
        elif lsplits == 3:
            pass
        elif lsplits == 2:
            pass
        elif lsplits == 1:
            rcommandSchedule = RCommandSchedule()
            if splits[0] == "begin":
                rcommandSchedule.interval = RCommandSchedule.SCHEDULE_BEGIN
            elif splits[0] == "end":
                rcommandSchedule.interval = RCommandSchedule.SCHEDULE_BEGIN
            elif splits[0].startswith("name:"):
                rcommandSchedule.interval = RCommandSchedule.SCHEDULE_NAME
                nsplits = splits[0].split(':', 1)
                if nsplits is None or len(nsplits) != 2:
                    raise Exception("bad name specification [%s], use name:<name> syntax" % splits[0])
                rcommandSchedule.datasourceName = nsplits[1]
            elif splits[0].startswith("ws:"):
                rcommandSchedule.interval = RCommandSchedule.SCHEDULE_WS
                nsplits = splits[0].split(':', 1)
                if nsplits is None or len(nsplits) != 2:
                    raise Exception("bad ws specification [%s], use ws:[client|server] syntax" % splits[0])
                rcommandSchedule.wsType = nsplits[1]
            elif splits[0].startswith("service-"):
                rcommandSchedule.interval = RCommandSchedule.SCHEDULE_SERVICE
                nsplits = splits[0].split('-', 1)
                if nsplits is None or len(nsplits) != 2:
                    raise Exception("bad service specification [%s], use service-<service> syntax" % splits[0])
                rcommandSchedule.serviceType = nsplits[1]
            else:
                rcommandSchedule.interval = intervalToSeconds(splits[0])
            return rcommandSchedule
        raise Exception("unparseable schedule [%s]" % schedule)

    async def reprJSON(self):
        data = {}
        data['interval'] = self.interval,
        data['datasourceName'] = str(self.datasourceName)
        return data


'''
# RCommand holds all information about a REST command.
# Following parameters are supported:
# -
#   schedule: <schedule>[s|m|h|d] | begin | end | name:<name>
#   request: [<variable>] <method> <url>
#   page: <static dictionary>
#   headers: <static dictionary>
#   eheaders: <eval dictionary>
#   params: <static dictionary>
#   eparams: <eval dictionary>
#   body: <static json> | string
#   ebody: <eval json dictionary> | <eval expression>
#   ipipe: # input actions, multiple actions are run in sequence
#     - action: <action>
#     - ...
#   opipe: # output actions, multiple actions are run in sequence
#     - action: <action>
#     - ...
#   targets: <eval array of dict>
'''
class RCommand():
    def __init__(self, platform, config):
        log.debug("rcommand platform [%s] config [%s]" % (platform, config))
        self.platform = platform
        self.config = config
        self.iactions = []
        self.oactions = []
        self.targets = None
        self.page = None
        self._preprocess_config()

    def __str__(self):
        return "RCommand: %s/%s" % (self.platform, self.config)

    def _preprocess_config(self):
        # schedule
        if "schedule" not in self.config:
            raise RCommandConfigError("schedule parameter is missing")
        _schedule = str(self.config["schedule"])
        try:
            self.config["schedule"] = RCommandSchedule.parse(_schedule)
        except Exception as e:
            raise RCommandConfigError("invalid schedule parameter value [%s]" % _schedule, e=e)
        log.debug("rcommand schedule [%s]" % self.config["schedule"])
        # request
        splits = self.config["request"].strip().split(' ', 2)
        lsplits = len(splits)
        if lsplits == 2:
            # Regular: <method> <static url>
            self.config["method"] = splits[0].strip()
            self.config["url"] = splits[1].strip()
            log.debug("rcommand request [%s] [%s]" % \
                      (self.config["method"], self.config["url"]))
        elif lsplits == 3:
            # Eval: <variable> <method> <dynamic url>
            # TODO: check that <variable> exists only once globally, maintain global list of them?
            self.config["method"] = splits[1].strip()
            self.config["url"] = None
            eurl = splits[2].strip()
            self.config["eurl"] = compile(eurl, eurl, 'eval')
            self.config["eurlvar"] = splits[0].strip()
            log.debug("rcommand request [%s] [%s] [%s]" % \
                      (self.config["eurlvar"], self.config["method"], eurl))
        else:
            # Error
            log.error("bad line [%s], needs to be [<variable>] <method> <url>" % (self.config["request"]))
            raise RCommandConfigError("invalid request parameter value [%s], needs to be [<variable>] <method> <url>" % self.config["request"])
        # page
        page = self.config.get("page", None)
        if page is not None:
            self.page = {}
            self.page.update(page)
            for (k, v) in page.items():
                if k == "begin" or k == "next" or k == "end":
                    self.page[k] = (v, compile(v, v, 'eval'))
            log.debug("rcommand page [%s]" % (self.page))
        # headers
        if self.config.get("headers", None) is None:
            self.config["headers"] = None
        log.debug("rcommand headers [%s]" % self.config["headers"])
        # eheaders
        eheaders = self.config.get("eheaders", None)
        if eheaders is not None:
            for (k, v) in eheaders.items():
                try:
                    eheaders[k] = (v, compile(v, v, 'eval'))
                    log.debug("rcommand eheaders [%s] [%s]" % (k, v))
                except Exception as e:
                    raise RCommandConfigError("invalid eheaders parameter key [%s] value [%s]" % (k, v), e)
        else:
            self.config["eheaders"] = None
        log.debug("rcommand eheaders [%s]" % self.config["eheaders"])
        # params
        if self.config.get("params", None) is None:
            self.config["params"] = None
        log.debug("rcommand params [%s]" % self.config["params"])
        # eparams
        eparams = self.config.get("eparams", None)
        if eparams is not None:
            for (k, v) in eparams.items():
                try:
                    eparams[k] = (v, compile(v, v, 'eval'))
                    log.debug("rcommand eparams [%s] [%s]" % (k, v))
                except Exception as e:
                    raise RCommandConfigError("invalid eparams parameter key [%s] value [%s]" % (k, v), e=e)
        else:
            self.config["eparams"] = None
        log.debug("rcommand eparams [%s]" % self.config["eparams"])
        # body
        body = self.config.get("body", None)
        if body is not None:
            if type(body) == bytes or type(body) == str:
                # Already a string
                pass
            elif type(body) == dict:
                # Dump JSON as string
                self.config["body"] = json.dumps(body)
            else:
                raise RCommandConfigError("body must be static JSON or string [%s]" % (body))
        else:
            self.config["body"] = None
        log.debug("rcommand body [%s]" % self.config["body"])
        # ebody
        ebody = self.config.get("ebody", None)
        if ebody is not None:
            if type(ebody) == bytes or type(ebody) == str:
                # Eval expression
                self.config["ebody"] = (ebody, compile(ebody, ebody, 'eval'))
            elif type(ebody) == dict:
                # Eval dictionary
                for (k, v) in ebody.items():
                    try:
                        ebody[k] = (v, compile(v, v, 'eval'))
                        log.debug("rcommand ebody [%s] [%s]" % (k, v))
                    except Exception as e:
                        raise RCommandConfigError("invalid ebody parameter key [%s] value [%s]" % (k, v), e=e)
            else:
                raise RCommandConfigError("ebody must be eval dictionary or eval expression [%s]" % (ebody))
        else:
            self.config["ebody"] = None
        log.debug("rcommand ebody [%s]" % str(self.config["ebody"]))
        # ipipe
        ipipe = self.config.get("ipipe", None)
        if ipipe is not None:
            self.iactions = self._preprocess_config_pipe(ipipe, Action.PIPELINE_INPUT)
        log.debug("rcommand iactions [%s]" % self.iactions)
        # opipe
        opipe = self.config.get("opipe", None)
        if opipe is not None:
            self.oactions = self._preprocess_config_pipe(opipe, Action.PIPELINE_OUTPUT)
        log.debug("rcommand oactions [%s]" % self.oactions)
        # targets
        targets = self.config.get("targets", None)
        if targets is not None:
            self.targets = (targets, compile(targets, targets, 'eval'))

    def _preprocess_config_pipe(self, iopipe, pipeline):
        actions = []
        for _action in iopipe:
            action = ActionParser.parse(self, _action, pipeline)
            if action is not None:
                actions.append(action)
        return actions

    def open(self):
        log.debug("[%s]" % self)
        for iaction in self.iactions:
            iaction.open()
        for oaction in self.oactions:
            oaction.open()

    def close(self):
        log.debug("[%s]" % self)
        for iaction in self.iactions:
            iaction.close()
        for oaction in self.oactions:
            oaction.close()

    async def reprJSON(self):
        data = {}
        data['platform'] = self.platform
        data['config'] = str(self.config)
        data['page'] = self.page
        return data


'''
# RCommands.
'''
class RCommands():
    def __init__(self):
        self.rcommands = []
        self.rcommandsByName = {}

    def getRCommands(self):
        return self.rcommands

    def getRCommandByName(self, name):
        return self.rcommandsByName.get(name, None)

    def addFromContentProvider(self, platform, contentProvider, printStream):
        (_rcommands, e) = loadYmlContent(contentProvider)
        if e is not None:
            if isinstance(e, YmlError):
                raise RCommandConfigError(None, e=e)
            if printStream is not None:
                print(str(contentProvider) + " not found, skipping", file=printStream)
            return
        if printStream is not None:
            print("Loading rcommands from " + str(contentProvider), file=printStream)
        for _rcommand in _rcommands:
            try:
                rcommand = RCommand(platform, _rcommand)
                self.rcommands.append(rcommand)
                if rcommand.config["schedule"].datasourceName is not None:
                    self.rcommandsByName[rcommand.config["schedule"].datasourceName] = rcommand
            except RCommandConfigError as e:
                raise e
            except Exception as e:
                raise e

    def open(self):
        log.debug("[%s]" % self)
        for rcommand in self.rcommands:
            try:
                rcommand.open()
            except Exception as e:
                raise e

    def close(self):
        log.debug("[%s]" % self)
        for rcommand in self.rcommands:
            try:
                rcommand.close()
            except Exception as e:
                raise e

    async def reprJSON(self):
        data = []
        for rcommand in self.rcommands:
            output = await rcommand.reprJSON()
            data.append(output)
        return data
