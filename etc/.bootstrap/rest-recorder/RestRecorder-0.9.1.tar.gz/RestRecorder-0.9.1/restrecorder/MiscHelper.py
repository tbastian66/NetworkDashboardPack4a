#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# Misc. helper
#
# Authors: Thomas Bastian, Jeff Goff
#
#
'''

'''
# Parameters
'''
'''
#
'''

import asyncio
import logging
import time
from .Commons import loadJsonFile, saveJsonFile
from .RCommands import RCommands, RCommandConfigError
from .RestRecorder import RestRecorder, RestRecorderException
from .targets.Target import TargetConfigError, TargetOptions,\
    TargetAuthenticationError, TargetError
from .targets.Targets import Targets


# Logger
log = logging.getLogger(__name__)


async def loadTargets(rr_state):
    try:
        # Loading targets
        rr_context = RestRecorder.get_rr_context()
        rr_context.targets = Targets(rr_state.get("targets", {}))
        targetOptions = TargetOptions(printStream=rr_context.printStream,
                                      createMessageWriter="file" in rr_context.cliOptions.log_store,
                                      userContext=rr_context, contentProvider=None)
        await rr_context.targets.addFromContentProvider(rr_context.cliOptions.targets, targetOptions)
    except (TargetConfigError, TargetAuthenticationError, TargetError) as e:
        if e.target is not None:
            targetMessage = e.target
            if e.target is not None and "name" in e.target.config:
                targetMessage = e.target.config["name"]
            print("Target: [%s]" % (targetMessage), file=rr_context.printStream)
        if e.message is not None:
            print("Error: %s" % (e.message), file=rr_context.printStream)
        if e.e is not None:
            print("Message: [%s]" % (e.e.message), file=rr_context.printStream)
        raise RestRecorderException(e, 1)
    except asyncio.CancelledError as e:
        raise e
    except Exception as e:
        if e.message is not None:
            print("Error: %s" % (e.message), file=rr_context.printStream)
        raise RestRecorderException(e, 1)


def loadRCommands(platforms):
    try:
        # Loading all rcommands
        rr_context = RestRecorder.get_rr_context()
        rr_context.rcommands = RCommands()
        for platform, rcommands_content_provider in platforms.items():
            rr_context.rcommands.addFromContentProvider(platform, rcommands_content_provider, \
                rr_context.printStream)
    except RCommandConfigError as e:
        if e.rcommand is not None:
            print("RCommand: [%s]" % (e.rcommand), file=rr_context.printStream)
        if e.message is not None:
            print("Error: %s" % (e.message), file=rr_context.printStream)
        if e.e is not None:
            print("Message: [%s]" % (e.e.message), file=rr_context.printStream)
        raise RestRecorderException(e, 1)
    except Exception as e:
        if e.message is not None:
            print("Error: %s" % (e.message), file=rr_context.printStream)
        raise RestRecorderException(e, 1)


def loadContext():
    rr_context = RestRecorder.get_rr_context()
    print("Restoring saved context", file=rr_context.printStream)
    (_state, e) = loadJsonFile(rr_context.cliOptions.rrstate)
    if e is not None:
        log.info(".rrstate not found")
        return None
    else:
        log.info(".rrstate loaded")
        return _state


async def saveContext(rr_state):
    # Save context
    rr_state["version"] = 2
    rr_state["updatedAt"] = time.time()
    # Delete version 1 state
    if "targets" in rr_state:
        del rr_state["targets"]
    loadedTargetsState = rr_state.get("targetsByPlatform", {})
    rr_context = RestRecorder.get_rr_context()
    targetsState = await rr_context.targets.close()
    loadedTargetsState.update(targetsState)
    rr_state.update({ "targetsByPlatform": loadedTargetsState })
    rr_context.rcommands.close()
    e = saveJsonFile(rr_context.cliOptions.rrstate, rr_state)
    if e is not None:
        raise RestRecorderException(e, 1)
    # TODO: restrict permissions to owner on UNIX, i.e. 400 and Windows?
