#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: targets processing.
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
'''
#
'''

import aiohttp
import asyncio
import json
import logging
import time
from .Target import Target, TargetAuthenticationError, TargetConfigError, TargetError
from ..Commons import requestsResponseDump


# Logger
log = logging.getLogger(__name__)


'''
# TargetCppm is the concrete implementation for platform "cppm".
References:

    https://arubapedia.arubanetworks.com/arubapedia/index.php/How-To:_Clearpass_REST_API

Sample implementation:

    https://github.com/aruba/clearpass-api-python-snippets

API Clients can be configured in ClearPass Guest -> Administration -> API Services -> API Clients

There are 3 ways an API client can be configured
1. grant_type = client_credentials
   required parameters: client_id, client_secret
2. grant_type = password
   required parameters: client_id, client_secret, username, password
3. grant_type = password (Public Client)
   required parameters: client_id, username, password

# Understands following YAML
# -
#   platform: cppm                 # MANDATORY
#   name: <name>                   # OPTIONAL, default <url> host part
#   grant_type: client_credentials # OPTIONAL, default to client_credentials if no username present, password otherwise
#   client_id: <client_id>         # MANDATORY, client ID from ClearPass Guest API configuration
#   client_secret: <client_secret> # MANDATORY (if grant_type=client_credentials), client secret from ClearPass Guest
#   url: <URL>                     # MANDATORY
#   - url: "https://clearpass_fqdn" or "https://ip_address"
#
#   -OR-
#
# -
#   platform: cppm                 # MANDATORY
#   name: <name>                   # OPTIONAL, default <url> host part
#   grant_type: password           # OPTIONAL, default to oauth2 if username present, else oauth2_token
#   username: <username>           # MANDATORY
#   password: <password>           # MANDATORY
#   client_id: <client_id>         # MANDATORY, client ID from ClearPass Guest
#   client_secret: <client_secret> # OPTIONAL, if API client is configured as public client, client_secret can be omitted
#   url: <URL>                     # MANDATORY
#   - url: "https://clearpass_fqdn" or "https://ip_address"
#

'''
class TargetCppm(Target):
    def __init__(self, config, state, targetOptions):
        # Check for mandatory parameters
        if "client_id" not in config:
            raise TargetConfigError("client_id parameter is missing")
        if "url" not in config:
            raise TargetConfigError("url parameter is missing")
        # Check for optional parameters
        if "grant_type" not in config:
            if "username" in config:
                config["grant_type"] = "password"
            else:
                config["grant_type"] = "client_credentials"
        # Validate config
        if config["grant_type"] == "client_credentials":
            if "client_secret" not in config:
                raise TargetConfigError("client_secret parameter is missing for grant_type=client_credentials")
        elif config["grant_type"] == "password":
            if not config["username"] or \
               not config["password"]:
                raise TargetConfigError("username, password, client_id required for password authentication")
        else:
            raise TargetConfigError("auth parameter must be client_credentials or password")
        self.setupParamTimeout(config)
        # Initialize
        Target.__init__(self, "cppm", config, targetOptions)
        self._currentToken = None
        self._currentSession = None
        self._defaultParams = None
        self._timer = None
        self._safetyDelay = 60
        self._forceRefresh = False
        self._setup(state)

    def _setup(self, state):
        log.debug("from state [%s]" % (state))
        # Load state token
        state_token = None
        state_is_valid = False
        if "token" in state:
            # Use token from state
            token = state["token"]
            (v, e) = self._validateToken(token)
            if e is None:
                state_token = token
                state_is_valid = v
        if state_is_valid:
            # Use state token
            self._currentToken = state_token
            log.debug("using token from state [%s]" % (state_token))

    def _stopTimer(self):
        log.debug("in _stopTimer: self._timer:[%s]" % (self._timer))
        if self._timer is not None:
            self._timer.cancel()

    def _startTimer(self, delay):
        self._stopTimer()
        loop = asyncio.get_running_loop()
        self._timer = loop.call_later(delay, timerCallback, self)
        log.debug("in _startTimer: self._timer: [%s] delay: [%d]" % (self._timer, delay))

    def _validateToken(self, token):
        # Ensure token is sane and check if it has expired
        log.debug("[%s]" % (token))
        if token is None:
            return (False, None)
        e = None
        if "created_at" not in token:
            e = Exception("created_at missing")
        if "expires_in" not in token:
            e = Exception("expires_in missing")
        if "access_token" not in token:
            e = Exception("access_token missing")
        if "refresh_token" not in token and self.config["grant_type"] != "client_credentials":
            e = log.warning("refresh_token missing. grant_type must be client_credentials")
        try:
            now = time.time()
            created_at = float(token["created_at"]) / 1000.0
            expires_in = float(token["expires_in"])
            expires_at = created_at + expires_in - self._safetyDelay
            if now >= expires_at:
                # Token has expired/about to expire
                return (False, e)
            else:
                # Token is valid
                return (True, e)
        except Exception as _e:
            return (False, _e)

    def _setupExpiration(self, token, now):
        expiresAt = float(token["created_at"]) / 1000.0 + \
            float(token["expires_in"]) - self._safetyDelay
        d = expiresAt - now
        log.debug("_setupExpiration token:[%s] now:[%s] d:[%s]" % (token, now, d))
        if d > 0:
            self._startTimer(d)
        else:
            # TODO: what to do?
            log.error("_setupExpiration: expired token")

    async def _client_credentials_login(self):
        '''
        Login to Cppm with client_id and client_secret
        Get back:
            new access_token
        '''
        log.info("logging in with client_id [%s]" % (self.config["client_id"]))
        headers = { "Content-type": "application/json" }
        payload = {
            "grant_type": "client_credentials" ,
            "client_id": self.config["client_id"],
            "client_secret": self.config["client_secret"],
        }
        body = json.dumps(payload)
        async with aiohttp.ClientSession() as session:
            async with session.request(
                "POST",
                self.config["url"] + "/api/oauth",
                headers=headers,
                data=body,
                allow_redirects=False,
                ssl=False,
                timeout=self._get_aiohttp_timeout()
            ) as response:
                log.debug("%s" % requestsResponseDump(response))
                if response.status == 200:
                    new_token = await response.json()
                    new_token["created_at"] = int(time.time() * 1000.0)
                    log.debug("successfully obtained access_token [%s]" % (new_token))
                    return new_token
                else:
                    rtext = await response.text()
                    log.error("unable to obtain access_token, status [%d], message [%s]" % \
                        (response.status, rtext))
        return False

    async def _password_login(self):
        '''
        Login to Cppm with client_id, username, password and optionally client_secret
        Get back:
            new access_token
        '''
        log.info("logging in with client_id [%s] and username [%s]" % (self.config["client_id"], self.config["username"]))
        headers = { "Content-type": "application/json" }
        payload = {
            "grant_type": "password" ,
            "client_id": self.config["client_id"],
            "username": self.config["username"],
            "password": self.config["password"],
        }
        if "client_secret" in self.config:
            payload["client_secret"] = self.config["client_secret"]
        else:
            log.info("Public client authentication")

        log.debug(payload)

        body = json.dumps(payload)
        async with aiohttp.ClientSession() as session:
            async with session.request(
                "POST",
                self.config["url"] + "/api/oauth",
                headers=headers,
                data=body,
                allow_redirects=False,
                ssl=False,
                timeout=self._get_aiohttp_timeout()
            ) as response:
                log.debug("%s" % requestsResponseDump(response))
                if response.status == 200:
                    new_token = await response.json()
                    new_token["created_at"] = int(time.time() * 1000.0)
                    log.debug("successfully obtained access_token [%s]" % (new_token))
                    return new_token
                else:
                    rtext = await response.text()
                    log.error("unable to obtain access_token, status [%d], message [%s]" % \
                        (response.status, rtext))
        return False

    async def _oauth2(self):
        '''
        Attempt to perform a full authentication if access token is invalid (not present/expired)
        Input:
            client_id
            client_secret
        or
            username
            password
            client_id
            client_secret (optional)
        '''
        log.debug("target [%s] attempting oauth2", (self))
        if self.config["grant_type"] == "client_credentials":
            new_token = await self._client_credentials_login()
        else:
            new_token = await self._password_login()
        return new_token

    async def _oauth2_token_expires(self):
        ''' Re-authenticate and obtain a new access_token.
        Although CPPM supports grant_type=refresh_token authentication, we are not using as:
        1. Only grant_type=password generates a refresh_token, client_credentials does not
        2. The new token generated does not come with a new 'refresh_token'. Therefore,
           there is no way to tell when a refresh_token will expire.
        '''
        async with self.lock:
            log.debug("target [%s] token [%s]" % (self, self._currentToken))
            # Avoid a race for token refresh after a bunch of handle4xx()
            if self._timer is not None:
                expiresIn = self._timer.when() - asyncio.get_running_loop().time()
                if expiresIn > self._safetyDelay:
                    # Recently refreshed, use current token
                    log.debug("target [%s] token [%s] expires [%s]" % (self, self._currentToken, expiresIn))
                    return self._currentToken
            self._stopTimer()
            if self._currentToken is None:
                new_token = await self._oauth2()
                if new_token is not None:
                    self._currentToken = new_token
                    self._setupExpiration(self._currentToken, time.time())
                    self._sessionUpdate()
                    log.debug("using token [%s]" % (self._currentToken))
                    return new_token
                return None
            else:
                new_token = await self._oauth2()
                if new_token is not None:
                    # keep track of refresh_token although it's not being used
                    if "refresh_token" in new_token.keys():
                        self._currentToken["refresh_token"] = new_token["refresh_token"]
                    self._currentToken["access_token"] = new_token["access_token"]
                    self._currentToken["created_at"] = int(time.time() * 1000.0)
                    self._currentToken["expires_in"] = new_token["expires_in"]
                    self._setupExpiration(self._currentToken, time.time())
                    self._sessionUpdate()
                    log.debug("using token [%s]" % (self._currentToken))
                return new_token

    async def _oauth2_token_refresh(self, token):
        '''
        CPPM supports outh token refresh with various limitations:

        1. only grant_type = password would generate a refresh_token
        2. no easy way to find out when a refresh_token will expire. It's set in the UI.

        There is no advantage of using refresh_token as both full re-auth and refresh
        takes 1 API call to /api/oauth

        But if we were to implement it, the following payload need to be POSTed to the
        /api/auth endpoint

        Public Client:
        payload = {
            "grant_type": "refresh_token" ,
            "client_id": "CLIENT_ID",
            "refresh_token": "LAST_VALID_REGRESH_TOKEN"
        }


        non-Public Client:
        payload = {
            "grant_type": "refresh_token" ,
            "client_id": "CLIENT_ID",
            "client_secret": "CLIENT_SECRET",
            "refresh_token": "LAST_VALID_REGRESH_TOKEN"
        }

        "username" and "password" are not necessary for a refresh.
        '''
        pass

    async def open(self):
        await super(TargetCppm, self).open()
        if self._currentToken is None:
            try:
                new_token = await self._oauth2()
            except (aiohttp.client_exceptions.ServerTimeoutError, aiohttp.client_exceptions.ClientConnectorError) as e:
                log.error(f"target:{self.name} cannot obtain oauth2 token ({e})")
                raise TargetAuthenticationError(f"FATAL: no oauth2 token available to work with ({e})", target=self, e=e)
            if new_token is not None:
                self._currentToken = new_token
                self._forceRefresh = False
                log.debug("oauth2 [%s]" % self._currentToken)
            else:
                log.error(f"target:{self.name} cannot obtain oauth2 token")
                raise TargetAuthenticationError("FATAL: no oauth2 token available to work with", target=self)
        if self._forceRefresh:
            # Current token has expired, need to refresh
            self._forceRefresh = False
            self._currentToken["access_token"] = self._currentToken["refresh_token"]
            if await self._oauth2_token_expires() is None:
                # First refresh attempt failed, try once more
                if await self._oauth2_token_expires() is None:
                    raise TargetAuthenticationError("no oauth2 token available", target=self)
        else:
            # Current token is OK, need to schedule refreshing
            self._setupExpiration(self._currentToken, time.time())

    async def close(self):
        self._stopTimer()
        await self._sessionClose()
        await super(TargetCppm, self).close()

    async def handle4xx(self, code4xx):
        log.debug("%s %s" % (self.platform, code4xx))
        # Got 4xx code, try to recover by getting a new token
        return await self._oauth2_token_expires() is not None

    async def _sessionGet(self):
        async with self.lock:
            if self._currentToken is not None:
                # Valid token
                if self._currentSession is None:
                    self._currentSession = \
                        aiohttp.ClientSession(headers={"Accept": "application/json"})
                    self._sessionUpdate()
                return self._currentSession
            else:
                # Invalid token, close any open session
                await self._sessionClose()
                return None

    def _sessionUpdate(self):
        self._defaultParams = {"access_token": self._currentToken["access_token"]}

    async def _sessionOpenHook(self, restContext):
        session = await self._sessionGet()
        restContext.session = session
        restContext.defaultParams = self._defaultParams
        log.debug("restContext [%s], restSession [%s]" % (restContext, restContext.session))

    async def _sessionCloseHook(self, restContext):
        log.debug("restContext [%s], restSession [%s]" % (restContext, restContext.session))
        restContext.session = None
        restContext.defaultParams = None

    def restContext(self):
        restContext = super(TargetCppm, self).restContext()
        restContext.sessionOpenHook = self._sessionOpenHook
        restContext.sessionCloseHook = self._sessionCloseHook
        return restContext

    def state(self):
        return { "token": self._currentToken }


def timerCallback(target):
    log.debug("timer callback for target [%s]" % (target))
    t = asyncio.create_task(target._oauth2_token_expires())
    log.debug("future timer task [%s]" % (str(t)))
