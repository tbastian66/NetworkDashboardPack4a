#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: targets processing.
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
'''
#
'''
import logging

import aiohttp
from true_or_false import true_or_false
from urllib.parse import urlparse

from .Target import TargetAuthenticationError, TargetConfigError, TargetError
from .TargetAcx import TargetAcx
from .TargetAos8 import TargetAos8
from .TargetAsw import TargetAsw
from .TargetCentral import TargetCentral
from .TargetCentralWs import TargetCentralWs
from .TargetCppm import TargetCppm
from .TargetServiceAleIap import TargetServiceAleIap
from .TargetServiceCentralWebhook import TargetServiceCentralWebhook
from ..Commons import loadYmlContent, YmlError


# Logger
log = logging.getLogger(__name__)


# https://github.com/michaelrosejr/pyarubacentral/blob/master/pyarubacentral/auth.py
# http://urllib3.readthedocs.io/en/latest/user-guide.html
# https://docs.ansible.com/ansible/latest/reference_appendices/YAMLSyntax.html

'''
# Targets. Container for all targets.
'''
class Targets():
    def __init__(self, state):
        self.state = state
        self.targets = []
        self.targetsByPlatform = {
            "aos8": [],
            "central": [],
            "central-ws": [],
            "asw": [],
            "acx": [],
            "cppm": [],
            "service-ale-iap": [],
            "service-central-webhook": []
        }
        self.targetsByName = {}

    def getTargets(self):
        return self.targets

    def getPlatforms(self):
        return self.targetsByPlatform.keys()

    def getTargetsByPlatform(self, platform):
        return self.targetsByPlatform[platform]

    def getTargetByName(self, name):
        return self.targetsByName.get(name, None)

    async def addFromContentProvider(self, contentProvider, targetOptions):
        (_targets, e) = loadYmlContent(contentProvider)
        if e is not None:
            if isinstance(e, YmlError):
                raise TargetConfigError(None, e=e)
            if targetOptions.printStream is not None:
                print(str(contentProvider) + " not found, skipping", file=targetOptions.printStream)
            return
        if targetOptions.printStream is not None:
            print("Loading targets from " + str(contentProvider), file=targetOptions.printStream)
        for _target in _targets:
            # Target disable flag
            disable = _target.get("disable", False)
            if disable is None or true_or_false(str(disable)):
                print("Ignoring disabled target #%d from %s" % (_targets.index(_target) + 1, str(contentProvider)),
                      file=targetOptions.printStream)
                continue
            # Target critical flag
            critical = _target.get("critical", False)
            _target["critical"] = critical is None or true_or_false(str(critical))
            platform = _target.get("platform", None)
            try:
                if platform is None:
                    raise TargetConfigError("platform name must be supplied", target=_target)
                self._assignName(_target)
                _duplicate = self.getTargetByName(_target["name"])
                if _duplicate is not None:
                    raise TargetConfigError("duplicate target name " + _target["name"], target=_target)
            except TargetConfigError as e:
                if _target["critical"]:
                    raise e
                else:
                    log.error("TargetConfigError [%s]. Target disabled" % (e.message))
                    continue
            try:
                # Create and open target
                stateByPlatform = self.state.get(platform, {})
                state = stateByPlatform.get(_target["name"], {})
                target = self._createTarget(_target, state, targetOptions)
                if target is not None:
                    ok = await self._openTarget(_target, target)
                    if ok:
                        self._addTarget(_target, target)
            except Exception as e:
                # Other runtime errors
                raise e

    async def close(self):
        targetsState = { }
        for target in self.targets:
            await target.close()
            state = target.state()
            platform = target.config["platform"]
            if not platform in targetsState:
                targetsState[platform] = { }
            targetsState[platform].update({ target.config["name"]: state })
        return targetsState

    async def clone(self, config):
        # Clone from an existing target (as referenced by "clone" parameter)
        if "clone" not in config:
            raise TargetConfigError("clone parameter is missing")
        _fromTarget = self.getTargetByName(config["clone"])
        if _fromTarget is None:
            raise TargetConfigError("target to clone not found")
        # TODO: check for non-cloneable such as central
        # Generate and assign name
        self._assignName(config)
        # Return existing clone
        target = self.getTargetByName(config["name"])
        if target is not None:
            return target
        # Create new dynamic target
        cloneTargetConfig = dict()
        cloneTargetConfig.update(_fromTarget.config)
        cloneTargetConfig.update(config)
        del cloneTargetConfig["clone"]
        target = self._createTarget(cloneTargetConfig, {}, _fromTarget.targetOptions)
        if target is not None:
            ok = await self._openTarget(cloneTargetConfig, target)
            if ok:
                self._addTarget(cloneTargetConfig, target)
        return target

    def _nameFromUrl(self, url):
        try:
            o = urlparse(url)
            log.debug("[%s] [%s]" % (url, o.netloc))
            splits = o.netloc.split(":", 1)
            return splits[0]
        except:
            log.debug("failed on [%s]" % (url))
            return None

    def _assignName(self, config):
        if "name" not in config:
            if "url" in config:
                _name = self._nameFromUrl(config["url"])
                if _name is None:
                    raise TargetConfigError("name parameter is missing or cannot be derived from URL")
                config["name"] = _name
            else:
                raise TargetConfigError("name parameter is missing or cannot be derived from URL")

    def _createTarget(self, config, state, targetOptions):
        try:
            # Instantiate target
            platform = config["platform"]
            if platform == "aos8":
                return TargetAos8(config, state, targetOptions)
            elif platform == "central":
                return TargetCentral(config, state, targetOptions)
            elif platform == "central-ws":
                return TargetCentralWs(config, state, targetOptions)
            elif platform == "asw":
                return TargetAsw(config, state, targetOptions)
            elif platform == "acx":
                return TargetAcx(config, state, targetOptions)
            elif platform == "cppm":
                return TargetCppm(config, state, targetOptions)
            elif platform == "service-ale-iap":
                return TargetServiceAleIap(config, state, targetOptions)
            elif platform == "service-central-webhook":
                return TargetServiceCentralWebhook(config, state, targetOptions)
            else:
                raise TargetConfigError("unknown platform " + platform)
        except TargetConfigError as e:
            if config["critical"]:
                raise e
            else:
                log.error("TargetConfigError [%s]. Target [%s] disabled" % (e.message, config["name"]))
                return None

    async def _openTarget(self, config, target):
        # Open target
        try:
            await target.open()
            return True
        except TargetConfigError as e:
            if config["critical"]:
                raise e
            else:
                log.error("TargetConfigError [%s]. Target [%s] disabled" % (e.message, config["name"]))
        except TargetAuthenticationError as e:
            if config["critical"]:
                raise e
            else:
                log.error("TargetAuthenticationError [%s]. Target [%s] disabled" % (e.message, config["name"]))
        except TargetError as e:
            if config["critical"]:
                raise e
            else:
                log.error("TargetError [%s]. Target [%s] disabled" % (e.message, config["name"]))
        return False

    def _addTarget(self, config, target):
        self.targets.append(target)
        self.targetsByPlatform[config["platform"]].append(target)
        self.targetsByName[config["name"]] = target

    async def reprJSON(self):
        data = []
        for target in self.targets:
            output = await target.reprJSON()
            data.append(output)
        return data

    async def reprStats(self):
        data = []
        for target in self.targets:
            target_stats = await target.reprStats()
            data.append(target_stats)
        return data

    async def reprStatsFormatted(self):
        output = []
        for target in self.targets:
            target_stats = await target.reprStatsFormatted()
            output.append(target_stats)
        return '\n'.join(output)
