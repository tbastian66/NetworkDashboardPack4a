#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: targets processing.
#
# Authors: Thomas Bastian
#
'''
import aiohttp
import asyncio
import logging
import time

from aacommons.misc.Stats import CounterEvent
from true_or_false import true_or_false

from ..Commons import intervalToSeconds
from ..Message import MessageWriter
from ..RestContext import RestContext

# Parameters
DEFAULT_THROTTLE = False  # disable throttling by default
DEFAULT_RATE_LIMIT_SECOND = 0  # Limit number of API calls per second. 0 to disable
DEFAULT_RATE_LIMIT_RETRIES = 0  # Number of retries if per-second rate limit is exceeded. 0 to disable
RATE_LIMIT_EXCEEDED_CODES = [429, 503]  # list of HTTP returned status_code which would be treated as rate limit exceeded


# Logger
log = logging.getLogger(__name__)


# https://github.com/michaelrosejr/pyarubacentral/blob/master/pyarubacentral/auth.py
# http://urllib3.readthedocs.io/en/latest/user-guide.html
# https://docs.ansible.com/ansible/latest/reference_appendices/YAMLSyntax.html


'''
# TargetConfigError.
'''


class TargetConfigError(Exception):
    def __init__(self, message, target=None, e=None):
        Exception.__init__(self)
        self.message = message
        self.target = target
        self.e = e

'''
# TargetAuthenticationError.
'''


class TargetAuthenticationError(Exception):
    def __init__(self, message, target=None, e=None):
        Exception.__init__(self)
        self.message = message
        self.target = target
        self.e = e

'''
# TargetError.
# General Target error not related to configuration or authentication.
'''


class TargetError(Exception):
    def __init__(self, message, target=None, e=None):
        Exception.__init__(self)
        self.message = message
        self.target = target
        self.e = e


'''
# TargetOptions.
'''


class TargetOptions():
    def __init__(self, printStream=None, createMessageWriter=False, userContext=None, contentProvider=None):
        # Print out informational messages to this stream
        self.printStream = printStream
        # Create message writer
        self.createMessageWriter = createMessageWriter
        # User context
        self.userContext = userContext
        # Content provider
        self.contentProvider = contentProvider

    async def reprJSON(self):
        data = {}
        data['printStream'] = str(self.printStream)
        data['createMessageWriter'] = str(self.createMessageWriter)
        data['userContext'] = str(self.userContext)
        data['contentProvider'] = str(self.contentProvider)
        return data


'''
# Target holds all information about a target.
# Base class for all types of target.
# A target is identified by a platform name.
'''
class Target(object):
    def __init__(self, platform, config, targetOptions):
        log.debug("initializing %s with config [%s] and targetOptions [%s]" % (platform, config, targetOptions))
        self.platform = platform
        self.config = config
        self.targetOptions = targetOptions
        self.lock = asyncio.Lock()
        self.stats = CounterEvent(name=self.name)
        self.config["throttle"] = true_or_false(config.get("throttle", DEFAULT_THROTTLE))
        try:
            self.config["rate_limit"] = float(config.get("rate_limit", DEFAULT_RATE_LIMIT_SECOND))
        except ValueError:
            log.warning(f"cannot convert rate_limit parameter to float ({config.get['rate_limit']})")
        self.config["retries"] = int(config.get("retries", DEFAULT_RATE_LIMIT_RETRIES))
        self.config["rate_limit_exceeded_codes"] = RATE_LIMIT_EXCEEDED_CODES

    async def open(self):
        # Do all necessary stuff to be able to process requests against
        log.debug("%s [%s]" % (self.platform, self.targetOptions.userContext))
        # Message writer
        targetWriter = None
        if self.targetOptions.createMessageWriter:
            fn = "rr-" + self.config["name"] + "-" + \
                 time.strftime("%Y%m%d-%H%M%S", time.localtime(time.time()))
            targetWriter = MessageWriter("Recording to file: ", fn, ".log",
                                         10 * 1024 * 1024, self.targetOptions.printStream)
        self.messageWriter = targetWriter

    async def close(self):
        # Close all resources
        log.debug("%s" % (self.platform))
        if self.messageWriter is not None:
            self.messageWriter.close()

    def state(self):
        return {}

    def restContext(self):
        log.debug("%s" % (self.platform))
        restContext = RestContext(userContext=self.targetOptions.userContext,
                                  baseURL=self.config["url"],
                                  target=self)
        return restContext

    def setupParamTimeout(self, config, connectTimeout=60.0, readTimeout=60.0):
        # Output is a tuple: (connect timeout, read timeout)
        timeout = config.get("timeout", None)
        if timeout is None:
            config["timeout"] = (connectTimeout, readTimeout)
            return
        if type(timeout) == list:
            # Array of one or two elements: connect timeout and read timeout
            if len(timeout) == 1:
                config["timeout"] = (float(timeout[0]), float(timeout[0]))
            elif len(timeout) == 2:
                config["timeout"] = (float(timeout[0]), float(timeout[1]))
            else:
                raise TargetConfigError("timeout parameter MUST be array of one or two elements")
        elif type(timeout) == tuple:
            # Already a tuple
            if len(timeout) == 2:
                config["timeout"] = (float(timeout[0]), float(timeout[1]))
            else:
                raise TargetConfigError("timeout parameter MUST be tuple of two elements")
        elif type(timeout) == int:
            config["timeout"] = (float(timeout), float(timeout))
        else:
            raise TargetConfigError("timeout parameter MUST be single value or array/tuple of two elements")

    def setupParamRefresh(self, config, defaultRefresh=900):
        if "refresh" in config:
            _refresh = str(config["refresh"])
            try:
                config["refresh"] = intervalToSeconds(_refresh)
            except Exception as e:
                raise TargetConfigError("invalid refresh parameter value [%s]" % _refresh, e=e)
        else:
            config["refresh"] = defaultRefresh

    async def handle4xx(self, code4xx):
        log.debug("%s %s" % (self.platform, code4xx))
        return False

    def _get_aiohttp_timeout(self):
        timeout = self.config["timeout"]
        return aiohttp.ClientTimeout(sock_connect=timeout[0], sock_read=timeout[1])

    async def _basic_auth_tokenGet(self, now):
        new_token = None
        if self.config["auth"] == "basic":
            # Call target specific basic auth
            new_token = await self._basic_auth()
        else:
            raise Exception("unknown auth method %s" % self.config["auth"])
        if new_token is not None:
            # TODO: use session-expire time or cookie information or refresh configuration
            self.expiresAt = now + self.config["refresh"]
        return new_token

    async def _basic_auth_tokenRelease(self):
        # Release a presumably still valid token acquired previously
        return False

    async def _basic_auth_sessionGet(self):
        async with self.lock:
            now = time.time()
            if self._currentToken is None or now >= self.expiresAt:
                # Release a presumably still valid token acquired previously
                await self._basic_auth_tokenRelease()
                # No token or expired token, acquire new token
                self._currentToken = await self._basic_auth_tokenGet(now)
                if self._currentToken is not None:
                    # Got new token, close current session if any
                    if self._currentSession is not None:
                        await self._currentSession.close()
                        self._currentSession = None
                    # Create new session
                    self._currentSession = await self._basic_auth_sessionNew()
                    log.debug("new session [%s] [%s]" % (self.config["url"], self._currentSession))
                    return self._currentSession
                else:
                    # No token, hence no session
                    return None
            else:
                # Valid token, return current session
                return self._currentSession

    async def _sessionClose(self):
        if self._currentSession is not None:
            await self._currentSession.close()
            self._currentSession = None

    @property
    def name(self):
        return self.config.get("name", str(self))

    @property
    def timeout(self):
        return self.config.get("timeout")

    async def reprJSON(self):
        data = {}
        data[self.name] = {}
        data[self.name]['platform'] = self.platform
        # TODO: might need to obfuscate credentials in 'config' (key, password, secret)
        data[self.name]['config'] = self.config
        data[self.name]['targetOptions'] = await self.targetOptions.reprJSON()
        return data

    async def reprStats(self):
        '''
        return current stats of this target
        '''
        stop_ts = time.time()
        target_stats = self.stats.snapshot(update_stats=True, stop_ts=stop_ts)
        return target_stats

    async def reprStatsFormatted(self):
        '''
        return current stats of this target in a table
        '''
        stop_ts = time.time()
        target_stats = self.stats.snapshot_table(update_stats=True, stop_ts=stop_ts)
        return target_stats
