#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: targets processing.
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
'''
#
'''

import aiohttp
import json
import logging
from .Target import Target, TargetConfigError
from ..Commons import requestsResponseDump


# Logger
log = logging.getLogger(__name__)


'''
# TargetAsw is the concrete implementation for platform "asw".
# Understands following YAML
# -
#   platform: asw             # MANDATORY
#   name: <name>              # OPTIONAL, default <url> host part
#   auth: basic               # OPTIONAL, default basic
#   username: <username>      # MANDATORY
#   password: <password>      # MANDATORY
#   url: <URL>                # MANDATORY
#   refresh: <interval>       # OPTIONAL, default 10m
#   timeout: <connect and read timeout> | [ <connect timeout>, <read timeout> ] # OPTIONAL, default [60, 60]
#
'''
class TargetAsw(Target):
    def __init__(self, config, state, targetOptions):
        # Check for mandatory parameters
        if "username" not in config:
            raise TargetConfigError("username parameter is missing")
        if "password" not in config:
            raise TargetConfigError("password parameter is missing")
        if "url" not in config:
            raise TargetConfigError("url parameter is missing")
        # Check for optional parameters
        if "auth" not in config:
            config["auth"] = "basic"
        if config["auth"] != "basic":
            raise TargetConfigError("auth parameter must be basic")
        self.setupParamRefresh(config, defaultRefresh=600)
        self.setupParamTimeout(config)
        Target.__init__(self, "asw", config, targetOptions)
        self._currentToken = None
        self._currentSession = None

    async def _basic_auth(self):
        log.debug("basic")
        body = json.dumps({ "userName": self.config["username"],
                            "password": self.config["password"] })
        async with aiohttp.ClientSession() as session:
            async with session.request(
                "POST",
                self.config["url"] + "/login-sessions",
                headers = { "Content-Type": "application/json",
                            "Accept": "application/json" },
                data=body,
                allow_redirects=False,
                ssl=False,
                timeout=self._get_aiohttp_timeout()
            ) as response:
                log.debug("%s" % requestsResponseDump(response))
                rdata = await response.json(content_type=None)
                cookie = rdata.get("cookie", None)
                if cookie is not None:
                    sessionId = cookie.split("=", 1)[1]
                    return { "cookies": { "sessionId": sessionId } }
        return None

    async def _basic_auth_tokenRelease(self):
        # Be a good citizen and logout
        if self._currentSession is not None:
            async with self._currentSession.request(
                "DELETE",
                self.config["url"] + "/login-sessions",
                headers = { "Content-Type": "application/json",
                            "Accept": "application/json" },
                data=None,
                allow_redirects=False,
                ssl=False,
                timeout=self._get_aiohttp_timeout()
            ) as response:
                log.debug("logout %s" % requestsResponseDump(response))
                return response.status == 204
        return False

    async def _basic_auth_sessionNew(self):
        return aiohttp.ClientSession(cookies=self._currentToken["cookies"])

    async def _sessionOpenHook(self, restContext):
        session = await self._basic_auth_sessionGet()
        restContext.session = session
        log.debug("restContext [%s], restSession [%s]" % (restContext, restContext.session))

    async def _sessionCloseHook(self, restContext):
        log.debug("restContext [%s], restSession [%s]" % (restContext, restContext.session))
        restContext.session = None

    def restContext(self):
        restContext = super(TargetAsw, self).restContext()
        restContext.sessionOpenHook = self._sessionOpenHook
        restContext.sessionCloseHook = self._sessionCloseHook
        return restContext

    async def close(self):
        await super(TargetAsw, self).close()
        try:
            await self._basic_auth_tokenRelease()
            await self._sessionClose()
        except Exception:
            # Swallow
            pass

    async def handle4xx(self, code4xx):
        log.debug("%s %s" % (self.platform, code4xx))
        self._currentToken = None
        return True
