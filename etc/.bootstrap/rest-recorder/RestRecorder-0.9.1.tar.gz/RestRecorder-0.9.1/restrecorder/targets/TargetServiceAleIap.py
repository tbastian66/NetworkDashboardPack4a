#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: targets processing.
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
'''
#
'''

import logging
import os
from .Target import Target, TargetConfigError


# Logger
log = logging.getLogger(__name__)


'''
# TargetServiceAleIap is the concrete implementation for platform "service-ale-iap".
# Understands following YAML
# -
#   platform: service-ale-iap # MANDATORY
#   name: <name>              # MANDATORY
#   port: <port>              # MANDATORY, port number (1-65535) service listens
#   certificate_file: <path>  # OPTIONAL, [SSL] specify path to certificate file (PEM encoded)
#   certificate_key: <path>   # OPTIONAL, [SSL] specify path to certificate key file (PEM encoded)
#
'''
class TargetServiceAleIap(Target):
    def __init__(self, config, state, targetOptions):
        # Check for mandatory parameters
        if "port" not in config:
            raise TargetConfigError("port parameter is missing")
        # Check for optional parameters
        if "certificate_file" in config:
            if not os.path.exists(config["certificate_file"]):
                raise TargetConfigError("certificate_file %s does not exist" % config["certificate_file"])
        if "certificate_key" in config:
            if not os.path.exists(config["certificate_key"]):
                raise TargetConfigError("certificate_key %s does not exist" % config["certificate_key"])
        if "port" in config:
            try:
                p = int(config["port"])
                if (p <= 0) or (p > 65535):
                    raise TargetConfigError("port parameter %d out of range [1 - 65535]" % p)
            except ValueError:
                raise TargetConfigError("port parameter %s MUST be numeric" % config["port"])
        Target.__init__(self, "service-ale-iap", config, targetOptions)
        self.config["port"] = int(config["port"])
