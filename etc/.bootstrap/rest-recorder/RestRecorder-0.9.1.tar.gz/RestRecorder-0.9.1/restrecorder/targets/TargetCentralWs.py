#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: targets processing.
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
'''
#
'''

import aiohttp
import asyncio
import json
import logging
import sys
import time
from .Target import Target, TargetAuthenticationError, TargetConfigError, TargetError
from ..Commons import requestsResponseDump
from ..WsClientContext import WsClientContext
from urllib.parse import urlparse


# Logger
log = logging.getLogger(__name__)


'''
# TargetCentralWs is the concrete implementation for platform "central-ws".
# Understands following YAML
# -
#   platform: central-ws      # MANDATORY
#   name: <name>              # OPTIONAL, default <url> host part
#   url: <URL>                # MANDATORY
#   - url: "wss://app-prod2-ui.central.arubanetworks.com"
#   username: <username>      # MANDATORY
#   key: <key>                # MANDATORY
#
'''
class TargetCentralWs(Target):
    def __init__(self, config, state, targetOptions):
        # Check for mandatory parameters
        if "url" not in config:
            raise TargetConfigError("url parameter is missing", target=self)
        if "username" not in config:
            raise TargetConfigError("username parameter is missing", target=self)
        if "key" not in config:
            raise TargetConfigError("key parameter is missing", target=self)
        self.setupParamTimeout(config)
        # Initialize
        Target.__init__(self, "central-ws", config, targetOptions)
        self._wsAuthzKey = None
        self._updatedAt = time.time()
        self._aggressiveRestart = self.config.get("aggressive_restart", 0)
        self._setup(state)

    def _setup(self, state):
        log.debug("from state [%s]" % (state))
        if "wsAuthzKey" in state:
            wsAuthzKey = state['wsAuthzKey']
            if wsAuthzKey is not None:
                self._wsAuthzKey = wsAuthzKey

    async def open(self):
        await super(TargetCentralWs, self).open()
        # We are validating the two available keys in order
        # - self.config['key'] => user configured key
        # - state['wsAuthzKey'] => last key saved
        wsAuthzKey = await self._validate_ws_authz_key(self.config['key'])
        if wsAuthzKey is None and self._wsAuthzKey is not None:
            # Configured key is probably out of date, fallback to saved one
            wsAuthzKey = await self._validate_ws_authz_key(self._wsAuthzKey)
        if wsAuthzKey is None:
            # Houston we have a problem
            raise TargetAuthenticationError("FATAL: no web-socket authorization token available to work with", target=self)
        self._wsAuthzKey = wsAuthzKey
        self._updatedAt = time.time()
        log.debug("using wsAuthzKey [%s]" % (self._wsAuthzKey))

    async def close(self):
        await super(TargetCentralWs, self).close()

    async def handle4xx(self, code4xx):
        log.debug("%s %s" % (self.platform, code4xx))
        async with self.lock:
            # Avoid a race for token refresh after a bunch of handle4xx()
            dt = time.time() - self._updatedAt
            # Anything less than 60 seconds reuse same key
            if dt > 60:
                wsAuthzKey = await self._validate_ws_authz_key(self._wsAuthzKey)
                if wsAuthzKey is None:
                    # Could be a transient condition, try again
                    await asyncio.sleep(60)
                    wsAuthzKey = await self._validate_ws_authz_key(self._wsAuthzKey)
                self._wsAuthzKey = wsAuthzKey
                self._updatedAt = time.time()
                log.debug("target [%s] wsAuthzKey [%s]" % (self, self._wsAuthzKey))

    async def _wsClientOpenHook(self, wsClientContext):
        log.debug("wsClientContext [%s]" % (wsClientContext))
        if self._wsAuthzKey is None:
            raise TargetAuthenticationError("FATAL: no web-socket authorization token available to work with", target=self)
        # Always release session, before getting new one
        wsClientContext.session = aiohttp.ClientSession()
        # Prepare final headers
        headers = dict()
        headers['UserName'] = self.config['username']
        headers['Authorization'] = self._wsAuthzKey
        headers.update(wsClientContext.headers)
        log.debug("headers [%s]" % (headers))
        # TODO: need to review options
        timeout = self.config["timeout"]
        try:
            wsClientContext.websocket = await wsClientContext.session.ws_connect(
                wsClientContext.baseURL + wsClientContext.url,
                method=wsClientContext.method,
                protocols=(), timeout=timeout[0],
                receive_timeout=None, auth=None,
                autoclose=True, autoping=True,
                heartbeat=None, origin=None,
                headers=headers, proxy=None, proxy_auth=None,
                ssl=None, verify_ssl=False,
                fingerprint=None, ssl_context=None,
                proxy_headers=None, compress=0, max_msg_size=4194304)
        except aiohttp.ClientResponseError as e:
            if e.code >= 400 and e.code <= 499:
                # Got a 4xx code, try revalidating the token
                log.debug(f"[{self.name}] Encountered ClientResponseError while attempting to open websocket: ({e})")
                if e.code == 400:
                    log.error(f"[{self.name}] Got HTTP code 400 while attempting to open websocket. "
                              f"Please ensure that streaming API is enabled for the requested topic: "
                              f"'{headers.get('Topic', 'Unknown')}'")
                await self.handle4xx(e.code)
            else:
                raise TargetError(f"[{self.name}] Unknown ClientResponseError", target=self, e=e)
        log.debug("wsClientContext [%s], websocket [%s]" % (wsClientContext, wsClientContext.websocket))

    async def _wsClientCloseHook(self, wsClientContext):
        log.debug("wsClientContext [%s], websocket [%s]" % (wsClientContext, wsClientContext.websocket))
        try:
            if wsClientContext.websocket is not None:
                await wsClientContext.websocket.close()
                log.debug("wsClientContext [%s], websocket [%s] closed" % (wsClientContext, wsClientContext.websocket))
        except Exception as e:
            log.error("wsClientContext [%s], websocket [%s] close exception [%s]" % \
                      (wsClientContext, wsClientContext.websocket, e))
        wsClientContext.websocket = None
        try:
            if wsClientContext.session is not None:
                await wsClientContext.session.close()
                log.debug("wsClientContext [%s], session [%s] closed" % (wsClientContext, wsClientContext.session))
        except Exception as e:
            log.error("wsClientContext [%s], session [%s] close exception" % \
                      (wsClientContext, wsClientContext.session, e))
        wsClientContext.session = None

    def restContext(self):
        return None

    def wsClientContext(self, method=None, url=None, headers=None):
        #restContext = super(TargetCentralWs, self).restContext()
        wsClientContext = WsClientContext(userContext=self.targetOptions.userContext,
                                          baseURL=self.config["url"],
                                          target=self,
                                          method=method,
                                          url=url,
                                          headers=headers)
        wsClientContext.wsClientOpenHook = self._wsClientOpenHook
        wsClientContext.wsClientCloseHook = self._wsClientCloseHook
        return wsClientContext

    def state(self):
        return { "wsAuthzKey": self._wsAuthzKey }

    async def _validate_ws_authz_key(self, wsAuthzKey):
        """
        This function is to validate WebSocket Key. A HTTP request to Aruba Central
        is made to validate and fetch the current WebSocket key.
        Input:
            hostname: Base URL from Endpoint in Streaming API page of Aruba Central.
            oldtok: Streaming API WebSocket Key.
        Returns:
            token (str): The function returns the unexpired token. It might be same
                         as the provided token if its unexpired.
            None: If unable to fetch the token
        """
        log.debug(f"[{self.name}] validating wsAuthzKey [{wsAuthzKey}]")
        headers = { "Authorization" : wsAuthzKey }
        parsed_url = urlparse(self.config['url'])
        if parsed_url.scheme == "wss":
            url = "https://{}/streaming/token/validate".format(parsed_url.netloc)
        elif parsed_url.scheme == "ws":
            url = "http://{}/streaming/token/validate".format(parsed_url.netloc)
        else:
            raise TargetConfigError(f"[{self.name}] Error in URL format: {url}", target=self)
        try:
            async with aiohttp.ClientSession() as session:
                async with session.request(
                    "GET",
                    url,
                    headers=headers,
                    allow_redirects=False,
                    ssl=False,
                    timeout=self._get_aiohttp_timeout()
                ) as response:
                    log.debug(f"[{self.name}] requestsResponseDump: {requestsResponseDump(response)}")
                    if response.status == 200:
                        rjson = await response.json()
                        wsAuthzKey = rjson['token']
                        log.debug(f"[{self.name}] new wsAuthzKey : {wsAuthzKey}")
                        return wsAuthzKey
                    else:
                        rtext = await response.text()
                        r = response
                        log.error(f"[{self.name}] unspecified error: status={r.status} text={str(rtext).strip()}")
        except aiohttp.client_exceptions.ClientConnectorError as e:
            log.error("[%s] ClientConnectorError [%s]" % (self.name, e))
        except Exception as e:
            log.error("[%s] exception [%s]" % (self.name, e))
        return None

    @property
    def aggressiveRestart(self):
        return self._aggressiveRestart
