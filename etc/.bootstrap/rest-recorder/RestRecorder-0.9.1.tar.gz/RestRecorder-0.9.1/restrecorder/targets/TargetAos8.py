#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: targets processing.
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
'''
#
'''

import aiohttp
import logging
from .Target import Target, TargetConfigError
from ..Commons import requestsResponseDump


# Logger
log = logging.getLogger(__name__)


'''
# TargetAos8 is the concrete implementation for platform "aos8".
# Understands following YAML
# -
#   platform: aos8            # MANDATORY
#   name: <name>              # OPTIONAL, default <url> host part
#   auth: basic               # OPTIONAL, default basic
#   username: <username>      # MANDATORY
#   password: <password>      # MANDATORY
#   url: <URL>                # MANDATORY
#   refresh: <interval>       # OPTIONAL, default 15m
#   timeout: <connect and read timeout> | [ <connect timeout>, <read timeout> ] # OPTIONAL, default [60, 60]
#
'''
class TargetAos8(Target):
    def __init__(self, config, state, targetOptions):
        # Check for mandatory parameters
        if "username" not in config:
            raise TargetConfigError("username parameter is missing")
        if "password" not in config:
            raise TargetConfigError("password parameter is missing")
        if "url" not in config:
            raise TargetConfigError("url parameter is missing")
        # Check for optional parameters
        if "auth" not in config:
            config["auth"] = "basic"
        if config["auth"] != "basic":
            raise TargetConfigError("auth parameter must be basic")
        self.setupParamRefresh(config)
        self.setupParamTimeout(config)
        Target.__init__(self, "aos8", config, targetOptions)
        self._currentToken = None
        self._currentSession = None
        self._defaultParams = None

    async def _basic_auth(self):
        log.debug("basic")
        async with aiohttp.ClientSession() as session:
            async with session.request(
                "POST",
                self.config["url"] + "/screens/wms/wms.login",
                data={ "needxml": 0, "opcode": "login",
                       "uid": self.config["username"],
                       "passwd": self.config["password"],
                       "url": "/login.html" },
                allow_redirects=False,
                ssl=False,
                timeout=self._get_aiohttp_timeout()
            ) as response:
                log.debug("%s" % requestsResponseDump(response))
                return { "cookies": response.cookies }
        return None

    async def _basic_auth_sessionNew(self):
        self._defaultParams = {"UIDARUBA": self._currentToken["cookies"]["SESSION"].value}
        return aiohttp.ClientSession(cookies=self._currentToken["cookies"])
        # X-CSRF-TOKEN CODE
        # if self._xml:
        #    # Get X-CSRF-TOKEN
        #    self._defaultHeaders = {}
        #    async with session.request(
        #        "GET",
        #        self.config["url"] + "/screens/cmnutil/serveCSRFToken.xml",
        #        allow_redirects=False,
        #        ssl=False,
        #        timeout=self._get_aiohttp_timeout()
        #    ) as response:
        #        log.debug("%s" % requestsResponseDump(response))
        #        self._defaultHeaders["X-CSRF-TOKEN"] = response.headers["X-CSRF-TOKEN"]

    async def _sessionOpenHook(self, restContext):
        session = await self._basic_auth_sessionGet()
        restContext.session = session
        restContext.defaultParams = self._defaultParams
        log.debug("restContext [%s], restSession [%s]" % (restContext, restContext.session))

    async def _sessionCloseHook(self, restContext):
        log.debug("restContext [%s], restSession [%s]" % (restContext, restContext.session))
        restContext.session = None
        restContext.defaultParams = None

    def restContext(self):
        restContext = super(TargetAos8, self).restContext()
        restContext.sessionOpenHook = self._sessionOpenHook
        restContext.sessionCloseHook = self._sessionCloseHook
        return restContext

    async def close(self):
        await super(TargetAos8, self).close()
        try:
            await self._sessionClose()
        except Exception:
            # Swallow
            pass

    async def handle4xx(self, code4xx):
        log.debug("%s %s" % (self.platform, code4xx))
        self._currentToken = None
        return True

