#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: targets processing.
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
DEFAULT_RATE_LIMIT_SECOND = 7  # As of 2.5.4, ACP enforce a rate limit of 7 API calls per second
DEFAULT_THROTTLE = True
DEFAULT_RATE_LIMIT_RETRIES = 10  # Number of retries if per second rate limit is exceeded (0 to disable)
'''
#
'''

import aiohttp
import asyncio
import json
import logging
import time
from .Target import Target, TargetAuthenticationError, TargetConfigError
from ..Commons import loadJsonContentProvider, requestsResponseDump

from true_or_false import true_or_false

# Logger
log = logging.getLogger(__name__)


'''
# TargetCentral is the concrete implementation for platform "central".
# Understands following YAML
# -
#   platform: central         # MANDATORY
#   name: <name>              # OPTIONAL, default <url> host part
#   auth: oauth2_token        # OPTIONAL, default to oauth2 if username present, else oauth2_token
#   token: "token.json"       # OPTIONAL, file that holds authentication token from central, default token.json
#   client_id: <client_id>    # MANDATORY, client ID from central APP
#   client_secret: <client_secret> # MANDATORY, client secret from central APP
#   url: <URL>                # MANDATORY
#   rate_limit: <limit>       # OPTIONAL: Number of calls per second (can be less than 1). Default: 0 (i.e. disable)
#   retries: <int>            # OPTIONAL: Number of times to retries if rate-limit exceeded
#   throttle: yes | no        # OPTIONAL: If enabled, add arbitrary delay based on the rate_limit parameter
#   - url: "https://internal-apigw.central.arubanetworks.com"
#
#   -OR-
#
# -
#   platform: central         # MANDATORY
#   name: <name>              # OPTIONAL, default <url> host part
#   auth: oauth2              # OPTIONAL, default to oauth2 if username present, else oauth2_token
#   username: <username>      # MANDATORY
#   password: <password>      # MANDATORY
#   client_id: <client_id>    # MANDATORY, client ID from central APP
#   client_secret: <client_secret> # MANDATORY, client secret from central APP
#   customerid: <customerid>  # OPTIONAL?
#   url: <URL>                # MANDATORY
#   - url: "https://internal-apigw.central.arubanetworks.com"
#   rate_limit: <limit>       # OPTIONAL: Number of calls per second (can be less than 1). Default: 0 (i.e. disable)
#   retries: <int>            # OPTIONAL: Number of times to retries if rate-limit exceeded
#   throttle: yes | no        # OPTIONAL: If enabled, add arbitrary delay based on the rate_limit parameter
#
# http://community.arubanetworks.com/t5/Cloud-Managed-Networks/Need-some-help-with-the-Central-API/td-p/403585
#
# Aruba Central Authentication Procedure.
#
# 1.  Use userid/password to obtain'csrftoken' and the 'session' (HPE SSO credential do not work)
# 2.  With csrftoken + session + client_id + customer_id, to get 'auth_code'
# 3a. With 'auth_code' + 'client_id' + 'client_secret', you get a token.
#     From the UI, which has an expiry of 7200 seconds. The token contains  'access_token' and 'refresh_token'.
# 3b. Download a seed token from the UI manually
# 4.  With the 'access_token', you use it for regular API calls.
# 5.  With 'client_id', 'client_secret' + 'refresh_token', you get a new set of 'access_token' and 'refresh_token'.
#
# So as long as you do Step #5 within 7200 seconds, you don't have to go through steps 1 to 3 again.
#
# Steps 1, 2 and 3a are optional. However, you need to download a seed token manually from the UI.
# This is not practical for production deployment.
#
'''
class TargetCentral(Target):
    def __init__(self, config, state, targetOptions):
        # Check for mandatory parameters
        if "client_id" not in config:
            raise TargetConfigError("client_id parameter is missing")
        if "client_secret" not in config:
            raise TargetConfigError("client_secret parameter is missing")
        if "url" not in config:
            raise TargetConfigError("url parameter is missing")
        # Check for optional parameters
        if "auth" not in config:
            if "username" in config:
                config["auth"] = "oauth2"
            else:
                config["auth"] = "oauth2_token"
        if "token" not in config:
            config["token"] = "token.json"
        # Validate config
        if config["auth"] == "oauth2_token":
            pass
        elif config["auth"] == "oauth2":
            if not config["username"] or \
               not config["password"]:
                raise TargetConfigError("username, password, client_id, client_secret required for oauth2")
        else:
            raise TargetConfigError("auth parameter must be oauth2 or oauth2_token")
        self.setupParamTimeout(config)

        config["rate_limit"] = float(config.get("rate_limit", DEFAULT_RATE_LIMIT_SECOND))
        config["throttle"] = true_or_false(config.get("throttle", DEFAULT_THROTTLE))
        config["retries"] = config.get("retries", DEFAULT_RATE_LIMIT_RETRIES)
        # Initialize
        Target.__init__(self, "central", config, targetOptions)
        self._currentToken = None
        self._currentSession = None
        self._defaultParams = None
        self._timer = None
        self._safetyDelay = 60
        self._forceRefresh = False
        self._setup(state)

    def _setup(self, state):
        log.debug("from state [%s]" % (state))
        # Load state token
        state_token = None
        state_is_valid = False
        if "token" in state:
            # Use token from state
            token = state["token"]
            (v, e) = self._validateToken(token)
            if e is None:
                state_token = token
                state_is_valid = v
        if self.config["auth"] == "oauth2_token":
            # oauth2_token: load content provider token
            cp_token = None
            cp_is_valid = False
            (token, e) = loadJsonContentProvider(self, self.targetOptions, self.config["token"])
            if e is not None:
                raise e
            (v, e) = self._validateToken(token)
            if e is None:
                cp_token = token
                cp_is_valid = v
            # Decide which token to use
            if state_is_valid and cp_is_valid:
                # Youngest token is used
                if state_token["created_at"] > cp_token["created_at"]:
                    self._currentToken = state_token
                    log.debug("using youngest token from state [%s]" % (state_token))
                else:
                    self._currentToken = cp_token
                    log.debug("using youngest token from [%s]" % (cp_token))
            elif state_is_valid:
                # Use state token
                self._currentToken = state_token
                log.debug("using token from state [%s]" % (state_token))
            elif cp_is_valid:
                # Use content provider token
                self._currentToken = cp_token
                log.debug("using token from [%s]" % (cp_token))
            else:
                # State and content provider tokens expired
                if state_token is not None and cp_token is not None:
                    # Youngest token is used
                    if state_token["created_at"] > cp_token["created_at"]:
                        self._currentToken = state_token
                        log.debug("using youngest expired token from state [%s]" % (state_token))
                    else:
                        self._currentToken = cp_token
                        log.debug("using youngest expired token from [%s]" % (cp_token))
                elif state_token is not None:
                    self._currentToken = state_token
                    log.debug("using expired token from state [%s]" % (state_token))
                elif cp_token is not None:
                    self._currentToken = cp_token
                    log.debug("using expired token from [%s]" % (cp_token))
                else:
                    raise TargetConfigError("no oauth2 token available")
                # Token must be refreshed on open()
                self._forceRefresh = True
        else:
            # oauth2
            if state_is_valid:
                # Use state token
                self._currentToken = state_token
                log.debug("using token from state [%s]" % (state_token))

    def _stopTimer(self):
        log.debug("[%s]" % (self._timer))
        if self._timer is not None:
            self._timer.cancel()
            self._timer = None

    def _startTimer(self, delay):
        self._stopTimer()
        loop = asyncio.get_running_loop()
        self._timer = loop.call_later(delay, timerCallback, self)
        log.debug("[%s] [%d]" % (self._timer, delay))

    def _validateToken(self, token):
        # Ensure token is sane and check if it has expired
        log.debug("[%s]" % (token))
        if token is None:
            return (False, None)
        e = None
        if "created_at" not in token:
            e = Exception("created_at missing")
        if "expires_in" not in token:
            e = Exception("expires_in missing")
        if "access_token" not in token:
            e = Exception("access_token missing")
        if "refresh_token" not in token:
            e = Exception("refresh_token missing")
        try:
            now = time.time()
            created_at = float(token["created_at"]) / 1000.0
            expires_in = float(token["expires_in"])
            expires_at = created_at + expires_in - self._safetyDelay
            if now >= expires_at:
                # Token has expired/about to expire
                return (False, e)
            else:
                # Token is valid
                return (True, e)
        except Exception as _e:
            return (False, _e)

    def _setupExpiration(self, token, now):
        expiresAt = float(token["created_at"]) / 1000.0 + \
            float(token["expires_in"]) - self._safetyDelay
        d = expiresAt - now
        log.debug("[%s] [%s] [%s]" % (token, now, d))
        if d > 0:
            self._startTimer(d)
        else:
            # TODO: what to do?
            log.error("_setupExpiration: expired token")

    async def _oauth2_login(self):
        '''
        Central OAuth Token Generation API Guide
        Step 1:
        Login to Aruba Central with username (e-mail) and password.
        Get back:
            csrftoken
            session
        in cookie
        '''
        log.info("logging in with userid [%s]" % (self.config["username"]))
        headers = { "Content-type": "application/json" }
        params = { "client_id": self.config["client_id"] }
        body = json.dumps({ "username": self.config["username"],
                            "password": self.config["password"] })
        async with aiohttp.ClientSession() as session:
            async with session.request(
                "POST",
                self.config["url"] + "/oauth2/authorize/central/api/login",
                headers=headers,
                params=params,
                data=body,
                allow_redirects=False,
                ssl=False,
                timeout=self._get_aiohttp_timeout()
            ) as response:
                log.debug("%s" % requestsResponseDump(response))
                if response.status == 200:
                    log.debug("cookies: [%s]" % (response.cookies))
                    return { "cookies": response.cookies }
                elif response.status == 401:
                    rtext = await response.text()
                    log.error("authentication with [%s] failed, reason [%s]" % (self.config["username"], rtext))
                else:
                    rtext = await response.text()
                    log.error("unspecified error [%s]" % (rtext))
        return False

    async def _oauth2_authorization_code(self, oauth2_cookies):
        '''
        Central OAuth Token Generation API Guide
        Step 2 (optional): Not implemented. MSP not supported
        Step 3: Generate Authorization Token
        Input:
            csrftoken (obtained from Step 1)
            session (obtained from Step 1)
            client_id
            customer_id (contrary to documentation, this is actually not needed)
        Output:
            auth_code
        '''
        csrftoken = oauth2_cookies['cookies']['csrftoken'].value
        session_cookie = oauth2_cookies['cookies']['session'].value
        log.debug("csrf [%s], session_cookie [%s]" % (csrftoken, session_cookie))
        headers = { "Content-Type": "application/json",
                    "X-CSRF-Token": csrftoken,
                    "Cookie":"session=" + session_cookie }
        params = {
            "client_id": self.config["client_id"],
            "response_type": "code",
            "scope": "all"
        }
        body = { }
        if "customer_id" in self.config:
            body = { "customer_id": self.config["customer_id"] }
        async with aiohttp.ClientSession() as session:
            async with session.request(
                "POST",
                self.config["url"] + "/oauth2/authorize/central/api",
                headers=headers,
                params=params,
                data=body,
                allow_redirects=False,
                ssl=False,
                timeout=self._get_aiohttp_timeout()
            ) as response:
                log.debug("%s" % requestsResponseDump(response))
                if response.status == 200:
                    rjson = await response.json()
                    auth_code = rjson['auth_code']
                    log.debug("got auth_code [%s]" % (auth_code))
                    return auth_code
                else:
                    rtext = await response.text()
                    log.error("no auth_code. status [%d], message [%s]" % (response.status, rtext))
                    return None
        return None

    async def _oauth2_code_token(self, auth_code):
        '''
        Central OAuth Token Generation API Guide
        Step 4: Exchange auth code for a token
        Input:
            auth_code (obtained in Step 3)
            client_id
            client_secret
        Output:
            access_token
                {
                    "refresh_token": "xxxx",
                    "token_type": "bearer",
                    "access_token": "xxxx",
                    "expires_in": 7200
                }
        '''
        headers = { "Content-Type": "application/json" }
        params = {
            "client_id": self.config["client_id"],
            "client_secret": self.config["client_secret"],
            "grant_type": "authorization_code",
            "code": auth_code
        }
        async with aiohttp.ClientSession() as session:
            async with session.request(
                "POST",
                self.config["url"] + "/oauth2/token",
                headers=headers,
                params=params,
                allow_redirects=False,
                ssl=False,
                timeout=self._get_aiohttp_timeout()
            ) as response:
                log.debug("%s" % requestsResponseDump(response))
                if response.status == 200:
                    new_token = await response.json()
                    new_token["created_at"] = int(time.time() * 1000.0)
                    log.debug("successfully obtained access_token [%s]" % (new_token))
                    return new_token
                else:
                    rtext = await response.text()
                    log.error("unable to exchange auth_code for a token, status [%d], message [%s]" % \
                        (response.status, rtext))
        return None

    async def _oauth2(self):
        '''
        Reference: Central OAuth Token Generation API Guide

        Attempt to perform a full authentication if access token is invalid (not present/expired)
        Input:
            username (e-mail)
            password
            client_id
            client_secret
        All 4 parameters must be present for full authentication to work
        According to documentation,
            customer_id
        is also required.  But test has shown that this actually not needed.
        '''
        log.debug("target [%s] attempting oauth2", (self))
        try:
            oauth2_cookies = await self._oauth2_login()
        except Exception as e:
            log.error(f"target {self.name} failed to authenticate ({e})")
            raise TargetAuthenticationError(f"target {self.name} failed to authenticate ({e})", target=self, e=e)
        if oauth2_cookies is not None:
            auth_code = await self._oauth2_authorization_code(oauth2_cookies)
            if auth_code is not None:
                new_token = await self._oauth2_code_token(auth_code)
                return new_token
        return None

    async def _oauth2_token_expires(self):
        async with self.lock:
            log.debug("target [%s] token [%s]" % (self, self._currentToken))
            # Avoid a race for token refresh after a bunch of handle4xx()
            if self._timer is not None:
                expiresIn = self._timer.when() - asyncio.get_running_loop().time()
                if expiresIn > self._safetyDelay:
                    # Recently refreshed, use current token
                    log.debug("target [%s] token [%s] expires [%s]" % (self, self._currentToken, expiresIn))
                    return self._currentToken
            self._stopTimer()
            if self._currentToken is None:
                if self.config["auth"] == "oauth2":
                    new_token = await self._oauth2()
                    if new_token is not None:
                        self._currentToken = new_token
                        self._setupExpiration(self._currentToken, time.time())
                        self._sessionUpdate()
                        log.debug("using token [%s]" % (self._currentToken))
                    return new_token
                else:
                    log.debug("no token and auth [%s]" % (self.config["auth"]))
                return None
            else:
                new_token = await self._oauth2_token_refresh(self._currentToken)
                if new_token is not None:
                    self._currentToken["refresh_token"] = new_token["refresh_token"]
                    self._currentToken["access_token"] = new_token["access_token"]
                    self._currentToken["created_at"] = int(time.time() * 1000.0)
                    self._currentToken["expires_in"] = new_token["expires_in"]
                    self._setupExpiration(self._currentToken, time.time())
                    self._sessionUpdate()
                    log.debug("using token [%s]" % (self._currentToken))
                return new_token

    async def _oauth2_token_refresh(self, token):
        '''
        Central OAuth Token Generation API Guide
        Step 5: Refreshing a Token
        Input:
            client_id
            client_secret
            refresh_token (seeded in a file or obtained in Step 4)
        '''
        log.debug("refresh [%s]" % (token))
        params = {
            "client_id": self.config["client_id"],
            "client_secret": self.config["client_secret"],
            "grant_type": "refresh_token",
            "refresh_token": token["refresh_token"]
        }
        async with aiohttp.ClientSession() as session:
            async with session.request(
                "POST",
                self.config["url"] + "/oauth2/token",
                params=params,
                allow_redirects=False,
                ssl=False,
                timeout=self._get_aiohttp_timeout()
            ) as response:
                if response.status == 200:
                    # Token was refreshed, extract new information
                    new_token = await response.json()
                    log.debug("refreshed [%s]" % (new_token))
                    return new_token
                else:
                    # Something happened
                    log.debug("failed [%s]" % requestsResponseDump(response))
                    return None

    async def open(self):
        await super(TargetCentral, self).open()
        if self._currentToken is None:
            try:
                new_token = await self._oauth2()
            except Exception as e:
                log.error(f"target {self.name} failed to authenticate ({e})")
                raise TargetAuthenticationError(f"target {self.name} failed to authenticate ({e})", target=self, e=e)
            if new_token is not None:
                self._currentToken = new_token
                self._forceRefresh = False
                log.debug("oauth2 [%s]" % self._currentToken)
            else:
                log.error(f"target {self.name} no oauth2 token available to work with")
                raise TargetAuthenticationError(f"target {self.name} no oauth2 token available to work with", target=self)
        if self._forceRefresh:
            # Current token has expired, need to refresh
            self._forceRefresh = False
            self._currentToken["access_token"] = self._currentToken["refresh_token"]
            if await self._oauth2_token_expires() is None:
                # First refresh attempt failed, try once more
                if await self._oauth2_token_expires() is None:
                    log.error(f"target {self.name} no oauth2 token available")
                    raise TargetAuthenticationError(f"target {self.name} no oauth2 token available", target=self)
        else:
            # Current token is OK, need to schedule refreshing
            self._setupExpiration(self._currentToken, time.time())

    async def close(self):
        self._stopTimer()
        await self._sessionClose()
        await super(TargetCentral, self).close()

    async def handle4xx(self, code4xx):
        log.debug("%s %s" % (self.platform, code4xx))
        # Got 4xx code, try to recover by getting a new token
        return await self._oauth2_token_expires() is not None

    async def _sessionGet(self):
        async with self.lock:
            if self._currentToken is not None:
                # Valid token
                if self._currentSession is None:
                    self._currentSession = \
                        aiohttp.ClientSession(headers={"Accept": "application/json"})
                    self._sessionUpdate()
                return self._currentSession
            else:
                # Invalid token, close any open session
                await self._sessionClose()
                return None

    def _sessionUpdate(self):
        self._defaultParams = {"access_token": self._currentToken["access_token"]}

    async def _sessionOpenHook(self, restContext):
        session = await self._sessionGet()
        restContext.session = session
        restContext.defaultParams = self._defaultParams
        log.debug("restContext [%s], restSession [%s]" % (restContext, restContext.session))

    async def _sessionCloseHook(self, restContext):
        log.debug("restContext [%s], restSession [%s]" % (restContext, restContext.session))
        restContext.session = None
        restContext.defaultParams = None

    def restContext(self):
        restContext = super(TargetCentral, self).restContext()
        restContext.sessionOpenHook = self._sessionOpenHook
        restContext.sessionCloseHook = self._sessionCloseHook
        return restContext

    def state(self):
        return { "token": self._currentToken }


def timerCallback(target):
    log.debug("timer callback for target [%s]" % (target))
    t = asyncio.create_task(target._oauth2_token_expires())
    log.debug("future timer task [%s]" % (str(t)))
