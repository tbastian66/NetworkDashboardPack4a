#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: context.
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
'''
#
'''

import asyncio
import logging


# Logger
log = logging.getLogger(__name__)


'''
# Context object for holding state across invocations
# - requests.Session - session
'''
class WsClientContext():
    def __init__(self, userContext=None, baseURL=None, target=None, method=None, url=None, headers=None):
        log.debug("creating wsclient context with userContext [%s], baseURL [%s], target [%s], method [%s], url [%s], headers [%s]" %
                  (userContext, baseURL, target, method, url, headers))
        self.userContext = userContext
        self.baseURL = baseURL
        self.target = target
        self.method = method
        self.url = url
        self.headers = headers
        self.session = None
        self.websocket = None
        self.wsClientOpenHook = None
        self.wsClientCloseHook = None

    def __enter__(self):
        log.debug("__enter__ called")
        try:
            self.wsClientOpenHook(self)

        except Exception as e:
            log.error("failed to open websocket client [%s]" % (e))
            return None

        return self

    def __exit__(self, exc_type, exc_value, traceback):
        log.debug("__exit__ called [%s] [%s] [%s]" % (exc_type, exc_value, traceback))
        try:
            self.wsClientCloseHook(self)

        except Exception as e:
            log.error("failed to close websocket client [%s]" % (e))

        return False

    async def __aenter__(self):
        log.debug("__aenter__ called")
        try:
            await self.wsClientOpenHook(self)

        except asyncio.CancelledError as e:
            raise e

        except Exception as e:
            log.error("failed to open websocket client [%s]" % (e))
            return None

        return self

    async def __aexit__(self, exc_type, exc_value, traceback):
        log.debug("__aexit__ called [%s] [%s] [%s]" % (exc_type, exc_value, traceback))
        try:
            await self.wsClientCloseHook(self)

        except asyncio.CancelledError as e:
            raise e

        except Exception as e:
            log.error("failed to close websocket client [%s]" % (e))

        return False
