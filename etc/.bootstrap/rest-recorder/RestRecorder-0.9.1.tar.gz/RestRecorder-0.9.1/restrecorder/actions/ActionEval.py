#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: action eval: python expression evaluation
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
'''
#
'''

import logging
from .Action import Action
from ..RestRecorder import RestRecorder


# Logger
log = logging.getLogger(__name__)


'''
# Understands following YAML
# - action: eval
#   eval: <python eval expression>
#
'''
class ActionEval(Action):
    def __init__(self, rcommand, actionConfig, actionPipeline):
        Action.__init__(self, rcommand, actionConfig, actionPipeline)
        code = actionConfig["eval"]
        self.code = compile(code, code, 'eval')

    def __str__(self):
        return "ActionEval: %s" % (self.code)

    @staticmethod
    async def process(actionData, action, actionContext):
        # The expression argument is parsed and evaluated as a python expression
        # (technically speaking, a condition list) using the globals and locals
        # dictionaries as global and local namespace. If the globals dictionary
        # is present and lacks '__builtins__', the current globals are copied
        # into globals before expression is parsed. This means that expression
        # normally has full access to the standard __builtin__ module and
        # restricted environments are propagated. If the locals dictionary is
        # omitted it defaults to the globals dictionary. If both dictionaries
        # are omitted, the expression is executed in the environment where eval()
        # is called. The return value is the result of the evaluated expression.
        # eval(expression[, globals[, locals]])
        try:
            rr_globals = RestRecorder.get_rr_context().get_rr_globals()
            output = eval(action.code, rr_globals, vars(actionContext))

        except KeyError as e:
            log.warning("KeyError exception [%s] for eval [%s]" % \
                        (e, action.actionConfig))
        return output
