#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: action csv-write: write CSV file.
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
'''
#
'''

import logging
from .Action import Action
from ..Commons import writeCsvFile


# Logger
log = logging.getLogger(__name__)


'''
# Understands following YAML
# - action: csv-write
#   path: <path to CSV file>          # MANDATORY
#   fields:                           # OPTIONAL
#    - field1
#    - field2
#
'''
class ActionCsvWrite(Action):
    def __init__(self, rcommand, actionConfig, actionPipeline):
        Action.__init__(self, rcommand, actionConfig, actionPipeline)
        self.csvPath = actionConfig["path"]
        #self.csvDelimiter = actionConfig.get("delimiter", ",")
        #self.csvQuotechar = actionConfig.get("quotechar", "\"")
        self.csvFields = actionConfig.get("fields", None)

    def __str__(self):
        return "ActionCsvWrite: %s/%s" % \
            (self.csvPath, self.csvFields)

    @staticmethod
    async def process(actionData, action, actionContext):
        writeCsvFile(actionData, action.csvPath, fields=action.csvFields)
        log.debug("[%s] wrote [%s] rows to [%s]" % (action, len(actionData), action.csvPath))
        return actionData
