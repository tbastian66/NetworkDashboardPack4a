#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: action csv-read: read CSV file.
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
'''
#
'''

import logging
from .Action import Action
from ..Commons import loadCsvFile


# Logger
log = logging.getLogger(__name__)


'''
# Understands following YAML
# - action: csv-read
#   path: <path to CSV file>          # MANDATORY
#   delimiter: ","                    # OPTIONAL, default is ","
#   quotechar: '"'                    # OPTIONAL, default is '"'
#   fields:                           # OPTIONAL, default is first line of file
#    - field1
#    - field2
#    ...
#   key: <field name for key>         # OPTIONAL, default is array of dict,
#                                                 otherwise dict of dict
#
'''
class ActionCsvRead(Action):
    def __init__(self, rcommand, actionConfig, actionPipeline):
        Action.__init__(self, rcommand, actionConfig, actionPipeline)
        self.csvPath = actionConfig["path"]
        self.csvDelimiter = actionConfig.get("delimiter", ",")
        self.csvQuotechar = actionConfig.get("quotechar", "\"")
        self.csvKey = actionConfig.get("key", None)
        self.csvFields = actionConfig.get("fields", None)

    def __str__(self):
        return "ActionCsvRead: %s/%s/%s/%s/%s" % \
            (self.csvPath, self.csvDelimiter, self.csvQuotechar, self.csvKey, self.csvFields)

    @staticmethod
    async def process(actionData, action, actionContext):
        csvRows = loadCsvFile(action.csvPath, action.csvDelimiter,
                              action.csvQuotechar, fields=action.csvFields)
        log.debug("[%s] loaded [%s] rows from [%s]" % (action, len(csvRows), action.csvPath))
        if action.csvKey is not None:
            _csvRows = {}
            for csvRow in csvRows:
                csvKeyValue = csvRow.get(action.csvKey, None)
                if csvKeyValue is not None:
                    _csvRows[csvKeyValue] = csvRow
            csvRows = _csvRows
            log.debug("[%s] loaded [%s] keys from [%s]" % (action, len(csvRows), action.csvPath))

        actionData = csvRows
        return actionData
