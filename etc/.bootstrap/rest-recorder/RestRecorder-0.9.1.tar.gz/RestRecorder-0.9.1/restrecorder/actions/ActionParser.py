#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: action parsing.
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
'''
#
'''

import logging
from .ActionAleIapDecoder import ActionAleIapDecoder
from .ActionCentralStreamingDecoder import ActionCentralStreamingDecoder
from .ActionCsvRead import ActionCsvRead
from .ActionCsvWrite import ActionCsvWrite
from .ActionDebug import ActionDebug
from .ActionEval import ActionEval
from .ActionJFilter import ActionJFilter
from .ActionKWrite import ActionKWrite
from .ActionPrint import ActionPrint
from .ActionRCommand import ActionRCommand
from .ActionSetVar import ActionSetVar
from .ActionSipS3Upload import ActionSipS3Upload
from .ActionTableParser import ActionTableParser
from .ActionWait import ActionWait


# Logger
log = logging.getLogger(__name__)


'''
# ActionConfigError.
'''
class ActionConfigError(Exception):
    def __init__(self, *args, **kwargs):
        Exception.__init__(self, *args, **kwargs)


'''
# Encapsulates an action, an item in a processing pipeline
'''
class ActionParser(object):
    @staticmethod
    def parse(rcommand, actionConfig, actionPipeline):
        if "action" not in actionConfig:
            raise ActionConfigError("invalid action, no action keyword found")
        actionName = actionConfig["action"]
        action = None
        if actionName == "ale-iap-decoder":
            action = ActionAleIapDecoder(rcommand, actionConfig, actionPipeline)
        elif actionName == "central-streaming-decoder":
            action = ActionCentralStreamingDecoder(rcommand, actionConfig, actionPipeline)
        elif actionName == "csv-read":
            action = ActionCsvRead(rcommand, actionConfig, actionPipeline)
        elif actionName == "csv-write":
            action = ActionCsvWrite(rcommand, actionConfig, actionPipeline)
        elif actionName == "debug":
            action = ActionDebug(rcommand, actionConfig, actionPipeline)
        elif actionName == "eval":
            action = ActionEval(rcommand, actionConfig, actionPipeline)
        elif actionName == "jfilter":
            action = ActionJFilter(rcommand, actionConfig, actionPipeline)
        elif actionName == "kwrite":
            action = ActionKWrite(rcommand, actionConfig, actionPipeline)
        elif actionName == "print":
            action = ActionPrint(rcommand, actionConfig, actionPipeline)
        elif actionName == "rcommand":
            action = ActionRCommand(rcommand, actionConfig, actionPipeline)
        elif actionName == "s3upload":
            action = ActionSipS3Upload(rcommand, actionConfig, actionPipeline)
        elif actionName == "setvar":
            action = ActionSetVar(rcommand, actionConfig, actionPipeline)
        elif actionName == "table-parser":
            action = ActionTableParser(rcommand, actionConfig, actionPipeline)
        elif actionName == "wait":
            action = ActionWait(rcommand, actionConfig, actionPipeline)
        else:
            log.error("invalid action name [%s]" % actionName)
            raise ActionConfigError("invalid action name [%s]" % actionName)
        return action
