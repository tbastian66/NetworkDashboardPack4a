#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: action print: print pipeline input data to stdout.
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
'''
#
'''

import logging
import pprint
from .Action import Action
from ..RestRecorder import RestRecorder
from io import StringIO


# Logger
log = logging.getLogger(__name__)


'''
# Understands following YAML
# - action: print
#   options: [string-in|pprint]     # OPTIONAL
#   output: [user-log|console]      # OPTIONAL, default user-log
#
'''
class ActionPrint(Action):
    OPTIONS_PPRINT = "pprint"
    OPTIONS_STR_IN = "string-in"
    OPTIONS_STR_OUT = "string-out"
    OUTPUT_USER_LOG = "user-log"
    OUTPUT_CONSOLE = "console"

    def __init__(self, rcommand, actionConfig, actionPipeline):
        Action.__init__(self, rcommand, actionConfig, actionPipeline)
        rr_context = RestRecorder.get_rr_context()
        self.printStream = rr_context.userLog
        self.output = actionConfig.get("output", None)
        if self.output == ActionPrint.OUTPUT_CONSOLE:
            self.printStream = rr_context.printStream
        self.options = actionConfig.get("options", None)
        if self.options == ActionPrint.OPTIONS_PPRINT:
            self.prettyPrinter = pprint.PrettyPrinter(indent=4, stream=self.printStream)

    def __str__(self):
        return "ActionPrint: %s/%s" % (self.output, self.options)

    def print_output(self, text):
        print(text, file=self.printStream)
        self.printStream.flush()

    @staticmethod
    async def process(actionData, action, actionContext):
        # TODO: ActionPrint.OPTIONS_STR_OUT
        if action.options == ActionPrint.OPTIONS_PPRINT:
            action.prettyPrinter.pprint(actionData)
            action.printStream.flush()
        elif action.options == ActionPrint.OPTIONS_STR_IN:
            text = ""
            buf = StringIO.StringIO(actionData)
            while True:
                t = buf.read(8192)
                if len(t) == 0:
                    break
                text += str(t)
            buf.close()
            action.print_output(text)
        else:
            action.print_output(actionData)
        return actionData
