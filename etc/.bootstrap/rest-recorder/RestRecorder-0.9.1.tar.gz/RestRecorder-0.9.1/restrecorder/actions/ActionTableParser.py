#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: action table-parser: parse table data out of text.
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
'''
#
'''

import logging
from .Action import Action
from aacommons.dataparser.cli.RowColumnTableParser import RowColumnTableParser


# Logger
log = logging.getLogger(__name__)


'''
#
# Parse content as list
#
'''
def contentAsList(content, marker=None, headerList=None, tableOptions=None):
    if tableOptions is not None:
        marker = tableOptions.get('marker', marker)
    if tableOptions is not None and 'json.lines' in tableOptions:
        # Lines are already in an array
        source = content[tableOptions['json.lines']]
    else:
        # Assume text
        source = content
    parser = RowColumnTableParser(source, marker=marker, tableOptions=tableOptions)
    parser.process()
    parsedTable = parser.getTables()[0]
    # Data trim, default true
    if (tableOptions is None) or ('data.trim' in tableOptions and tableOptions['data.trim']) or ('data.trim' not in tableOptions):
        # Header
        chi = 1
        for header in parsedTable['header']:
            header['title'] = header['title'].strip()
            # Provide numbered title instead of empty one
            if header['title'] == '':
                header['title'] = 'Column #' + str(chi)
            chi += 1
        # Data
        for row in parsedTable['rows']:
            i = 0
            for value in row:
                row[i] = value.strip()
                i += 1
    return parsedTable


'''
# Understands following YAML
# - action: table-parser
#   tables:
#     - <table options>
#     - ...
#
# <table options> is a dictionary of the form:
# {
#   "parser": "aos-std|aos-dp-std|generic-regex"
#   [, "begin": "<begin>" ]
#   [, "data.trim": false|true ]
#   [, "end": "<end>" ]
#   [, "json.lines": "<key>" ]
#   [, "marker": "<marker>" ]
# }

For full reference, please refer to the aacommons documentation.

'''
class ActionTableParser(Action):
    def __init__(self, rcommand, actionConfig, actionPipeline):
        Action.__init__(self, rcommand, actionConfig, actionPipeline)
        self.tables = actionConfig.get("tables", None)
        if self.tables is None:
            raise Exception("no tables")
        for table in self.tables:
            # Basic validation
            parser = table.get('parser', None)
            if parser is None:
                raise Exception(table + " defines no parser")

    def __str__(self):
        return "ActionTableParser: %s" % (self.tables)

    @staticmethod
    async def process(actionData, action, actionContext):
        tables = []
        for table in action.tables:
            parsed_table = contentAsList(actionData, marker=table.get('marker', None), tableOptions=table)
            tables.append(parsed_table)
        return tables
