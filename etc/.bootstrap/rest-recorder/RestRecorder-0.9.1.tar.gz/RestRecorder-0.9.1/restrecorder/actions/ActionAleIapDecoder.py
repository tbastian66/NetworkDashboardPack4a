#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: action ale-iap-decoder: decode ALE IAP message.
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
'''
#
'''

import base64
import logging
import struct
from .Action import Action
from ..dataparser.protobuf.ale.iap.v1.iap_pb2 import iap_post, iap_event, uplink_bandwidth
from ..dataparser.protobuf.ale.iap.v1.iap_messages_pb2 import IapStat, IapState, IapAppRF, IapClientURL
from ..dataparser.protobuf.ProtobufHelpers import ProtobufHelpers, ip2str
from google.protobuf.json_format import MessageToDict


# Logger
log = logging.getLogger(__name__)


# Converters
def ale_mac2str(v):
    try:
        return "%02x:%02x:%02x:%02x:%02x:%02x" % struct.unpack("BBBBBB", base64.b64decode(v['addr']))
    except Exception:
        return ""


# Post-processors


# Root objects
rootObjects = {
    'event': { 
        'root': iap_event(),
        'fields': None,
        'messages': {
            "<class 'iap_pb2.ip_address'>": ip2str,
            "<class 'iap_base_pb2.IpAddress'>": ip2str,
            "<class 'iap_pb2.mac_address'>": ale_mac2str,
            "<class 'iap_base_pb2.MacAddress'>": ale_mac2str
        }
    },
    'apprf': { 
        'root': IapAppRF(),
        'fields': None,
        'messages': {
            "<class 'iap_pb2.ip_address'>": ip2str,
            "<class 'iap_base_pb2.IpAddress'>": ip2str,
            "<class 'iap_pb2.mac_address'>": ale_mac2str,
            "<class 'iap_base_pb2.MacAddress'>": ale_mac2str
        }
    },
    'state': { 
        'root': IapState(),
        'fields': None,
        'messages': {
            "<class 'iap_pb2.ip_address'>": ip2str,
            "<class 'iap_base_pb2.IpAddress'>": ip2str,
            "<class 'iap_pb2.mac_address'>": ale_mac2str,
            "<class 'iap_base_pb2.MacAddress'>": ale_mac2str
        }
    },
    'stat': { 
        'root': IapStat(),
        'fields': None,
        'messages': {
            "<class 'iap_pb2.ip_address'>": ip2str,
            "<class 'iap_base_pb2.IpAddress'>": ip2str,
            "<class 'iap_pb2.mac_address'>": ale_mac2str,
            "<class 'iap_base_pb2.MacAddress'>": ale_mac2str
        }
    },
    'uplink_bandwidth': { 
        'root': uplink_bandwidth(),
        'fields': None,
        'messages': {
            "<class 'iap_pb2.ip_address'>": ip2str,
            "<class 'iap_base_pb2.IpAddress'>": ip2str,
            "<class 'iap_pb2.mac_address'>": ale_mac2str,
            "<class 'iap_base_pb2.MacAddress'>": ale_mac2str
        }
    },
    'client_url': { 
        'root': IapClientURL(),
        'fields': None,
        'messages': {
            "<class 'iap_pb2.ip_address'>": ip2str,
            "<class 'iap_base_pb2.IpAddress'>": ip2str,
            "<class 'iap_pb2.mac_address'>": ale_mac2str,
            "<class 'iap_base_pb2.MacAddress'>": ale_mac2str
        }
    }
}


'''
# Understands following YAML
# - action: ale-iap-decoder
#   version: 1.0.0                       # OPTIONAL (protobuf)
#
'''
class ActionAleIapDecoder(Action):
    OPTIONS_VERSION = "version"

    def __init__(self, rcommand, actionConfig, actionPipeline):
        Action.__init__(self, rcommand, actionConfig, actionPipeline)
        self.version = actionConfig.get("version", None)
        ProtobufHelpers.processObjects(rootObjects)

    def __str__(self):
        return "ActionAleIapDecoder: %s" % (self.version)

    @staticmethod
    async def process(actionData, action, actionContext):
        # actionData { "request": request, "body": pdata }
        # From iap.proto
        pbd = iap_post()
        pbd.ParseFromString(actionData["body"])
        pbdDict = MessageToDict(pbd)
        if 'iapEventMsg' in pbdDict:
            # repeated iap_event iap_event_msg = 1;
            nbEventMsg = pbdDict['iapEventMsg']
            for nbEvent in nbEventMsg:
                log.debug("%s" % nbEvent.keys())
                # Optional "bytes" secondary messages
                nbEventExtras = dict()
                decodedData = None
                try:
                    if 'IapAppRFData' in nbEvent:
                        decodedData = base64.b64decode(nbEvent['IapAppRFData'])
                        appRfData = IapAppRF()
                        appRfData.ParseFromString(decodedData)
                        appRfDataDict = MessageToDict(appRfData)
                        nbEventExtras['apprf'] = appRfDataDict
                        del nbEvent['IapAppRFData']
                        ProtobufHelpers.convertFields(rootObjects['apprf'], appRfDataDict)
                    if 'uplink_bandwidth' in nbEvent:
                        decodedData = base64.b64decode(nbEvent['uplink_bandwidth'])
                        uplinkBandwidth = uplink_bandwidth()
                        uplinkBandwidth.ParseFromString(decodedData)
                        uplinkBandwidthDict = MessageToDict(uplinkBandwidth)
                        nbEventExtras['uplink_bandwidth'] = uplinkBandwidthDict
                        del nbEvent['uplink_bandwidth']
                        ProtobufHelpers.convertFields(rootObjects['uplink_bandwidth'], uplinkBandwidthDict)
                    if 'IapClientURLData' in nbEvent:
                        decodedData = base64.b64decode(nbEvent['IapClientURLData'])
                        clientUrl = IapClientURL()
                        clientUrl.ParseFromString(decodedData)
                        clientUrlDict = MessageToDict(clientUrl)
                        nbEventExtras['client_url'] = clientUrlDict
                        del nbEvent['IapClientURLData']
                        ProtobufHelpers.convertFields(rootObjects['client_url'], clientUrlDict)
                    if 'IapStateData' in nbEvent:
                        decodedData = base64.b64decode(nbEvent['IapStateData'])
                        stateData = IapState()
                        stateData.ParseFromString(decodedData)
                        stateDataDict = MessageToDict(stateData)
                        nbEventExtras['state'] = stateDataDict
                        del nbEvent['IapStateData']
                        ProtobufHelpers.convertFields(rootObjects['state'], stateDataDict)
                    if 'IapStatData' in nbEvent:
                        decodedData = base64.b64decode(nbEvent['IapStatData'])
                        statData = IapStat()
                        statData.ParseFromString(decodedData)
                        statDataDict = MessageToDict(statData)
                        nbEventExtras['stat'] = statDataDict
                        del nbEvent['IapStatData']
                        ProtobufHelpers.convertFields(rootObjects['stat'], statDataDict)
                except Exception as e:
                    ddhex = ""
                    if decodedData is not None:
                        ddhex = decodedData.hex()
                    log.error("%s [%s]" % (nbEvent.keys(), ddhex), exc_info=True)
                    continue
                # Main object without extras
                ProtobufHelpers.convertFields(rootObjects['event'], nbEvent)
                nbEvent.update(nbEventExtras)
                # Other fixes
                nbEvent['timestamp'] = float(nbEvent['timestamp'])
            # Rename iapEventMsg to event
            pbdDict['event'] = pbdDict['iapEventMsg']
            del pbdDict['iapEventMsg']
        return pbdDict
