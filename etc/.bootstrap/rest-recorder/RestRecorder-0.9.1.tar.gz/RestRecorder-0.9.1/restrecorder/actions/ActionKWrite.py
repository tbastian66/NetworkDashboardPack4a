#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: action kwrite: output to kafka
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
'''
#
'''

import logging
import time
from .Action import Action
from ..RestRecorder import RestRecorder
from ..RestResult import RestResult


# Logger
log = logging.getLogger(__name__)


'''
# Understands following YAML
# - action: kwrite
#   topic: <topic>
#   ouput: raw | standard
#   label: <label>
#   keys: {'<key>': {'name': '<prefix>',
#                    'etags': { '<key>': <eval expression> } },
#          ...
#         }
#
# Able to process following action data
#
# { '<key>': { ... } }
# { '<key>': [ { ... } ] }
#
# or take everything if output == raw
#
# When key is '' then process all keys and use 'name' as a format string to set the kafka message key based on the upper case of original key.
# i.e. keys: {'': {'name': 'CENTRAL_STREAMING_{}_MESSAGE', 'etags': { '.name': "self.IFLIST[self.INTF['#']]" }}}
#
'''
class ActionKWrite(Action):
    def __init__(self, rcommand, actionConfig, actionPipeline):
        Action.__init__(self, rcommand, actionConfig, actionPipeline)
        self.topic = actionConfig['topic']
        self.keys = dict()
        self.raw = actionConfig.get('output', None) == 'raw'
        self.label = actionConfig.get('label', None)
        if 'keys' in actionConfig:
            for k, v in actionConfig['keys'].items():
                self.keys[k] = { 'name': v['name'] }
                if 'etags' in v:
                    self.keys[k]['etags'] = dict()
                    for ek, ev in v['etags'].items():
                        self.keys[k]['etags'][ek] = (ev, compile(ev, ev, 'eval'))

    def __str__(self):
        return "ActionKWrite: %s %s" % (self.topic, self.keys)

    @staticmethod
    async def process(actionData, action, actionContext):
        # Do nothing if no Kafka JSON writer
        rr_context = RestRecorder.get_rr_context()
        if rr_context.kafkaJSONWriter is None:
            return actionData
        # RR meta-information from current call
        # TODO: what if current_rr_result is None?
        current_rr_result = actionContext.rr_result
        current_rr_header = current_rr_result.headerAsDict(label=action.label)
        if action.raw:
            await action.process_kdata(vars(actionContext), action.topic,
                                       current_rr_result, current_rr_header,
                                       {}, actionData, raw=True)
        else:
            # Loop over all configured keys
            for k, kinfo in action.keys.items():
                if k == '':
                    # Wildcard key, i.e. process all keys
                    _kinfo = dict()
                    _kinfo.update(kinfo)
                    for valuesKey, values in actionData.items():
                        # Format topic
                        _kinfo['topic'] = _kinfo['name'].format(valuesKey.upper())
                        _kinfo['name'] = valuesKey
                        await action.process_kdata_values(action, actionContext, current_rr_result, current_rr_header, _kinfo, values)
                else:
                    if k not in actionData:
                        continue
                    await action.process_kdata_values(action, actionContext, current_rr_result, current_rr_header, kinfo, actionData[k])
        return actionData

    @staticmethod
    async def process_kdata_values(action, actionContext, current_rr_result, current_rr_header, kinfo, values):
        if type(values) == list:
            # Send each array element as a separate Kafka message
            for value in values:
                await action.process_kdata(vars(actionContext), action.topic,
                                           current_rr_result, current_rr_header,
                                           kinfo, value)
        elif type(values) == dict:
            # Single message
            await action.process_kdata(vars(actionContext), action.topic,
                                       current_rr_result, current_rr_header,
                                       kinfo, values)
        else:
            # TODO
            log.error("unknown value type [%s]" % (type(values)))

    @staticmethod
    async def process_kdata(lscope, topic, restResult, rr_header, kinfo, value, raw=False):
        rr_context = RestRecorder.get_rr_context()
        rr_globals = rr_context.get_rr_globals()
        if raw:
            rr_stdout = value
        else:
            if 'etags' in kinfo:
                # Add user tags
                kother = dict()
                kvalue = dict()
                kvalue.update(value)
                for ek, _ev in kinfo['etags'].items():
                    (ev, code) = _ev
                    try:
                        output = eval(code, rr_globals, lscope)
                    except KeyError as e:
                        log.warning("KeyError exception [%s] for eval [%s]" % \
                                    (e, ev))
                    # If key starts with a . make it relative to the kinfo['name']
                    if ek.startswith('.'):
                        kvalue[ek[1:]] = output
                    else:
                        kother[ek] = output
                rr_stdout = { kinfo['name']: kvalue }
                rr_stdout.update(kother)
            else:
                rr_stdout = { kinfo['name']: value }
        topic = kinfo.get('topic', topic)
        kdata = restResult.asDict(rr_header, rr_stdout)
        # Use partition from restResult
        kpartition = restResult.getData(RestResult.DATA_KEY_PARTITION)
        if kpartition is None:
            # TODO: extract partition hint from action context as fallback
            kpartition = int(time.time()*1000)
        log.debug("kafka output [%s] [%s] [%d]" % (topic, kdata, kpartition))
        await rr_context.kafkaJSONWriter.processJSON(topic, kdata, partition=kpartition)
