#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: action jfilter: JSON path filtering.
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
'''
#
'''

import logging
from .Action import Action
#from jsonpath_rw import jsonpath, parse
from jsonpath_rw_ext import parse


# Logger
log = logging.getLogger(__name__)


'''
# TODO: unclear which JSON path library to use!
# https://github.com/kennknowles/python-jsonpath-rw
# https://goessner.net/articles/JsonPath/
#
# Understands following YAML
# - action: jfilter
#   jfilter: <JSON path expression>
#
'''
class ActionJFilter(Action):
    def __init__(self, rcommand, actionConfig, actionPipeline):
        Action.__init__(self, rcommand, actionConfig, actionPipeline)
        self.parsedJsonFilter = parse(actionConfig["jfilter"].strip())

    def __str__(self):
        return "ActionJFilter: %s" % (self.parsedJsonFilter)

    @staticmethod
    async def process(actionData, action, actionContext):
        m = action.parsedJsonFilter.find(actionData)
        output = []
        for match in m:
            output.append(match.value)
        return output
