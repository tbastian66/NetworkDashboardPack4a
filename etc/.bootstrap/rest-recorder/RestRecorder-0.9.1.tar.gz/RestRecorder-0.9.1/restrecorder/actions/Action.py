#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: action base class.
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
'''
#
'''

import asyncio
import logging
import sys
import traceback


# Logger
log = logging.getLogger(__name__)


'''
# Describes an action, an item in a processing pipeline
'''
class Action(object):
    PIPELINE_INPUT = "input"
    PIPELINE_OUTPUT = "output"

    def __init__(self, rcommand, actionConfig, actionPipeline):
        self.rcommand = rcommand
        self.actionConfig = actionConfig
        self.actionPipeline = actionPipeline

    def __str__(self):
        return "Action: %s/%s" % (self.actionConfig, self.actionPipeline)

    def open(self):
        log.debug("[%s]" % self)

    def close(self):
        log.debug("[%s]" % self)

    @staticmethod
    async def process(actionData, action, actionContext):
        log.debug("[%s] [%s]" % (action, actionContext))
        return actionData


'''
# An action context is the runtime context in which actions are run.
'''
class ActionContext(object):
    def __init__(self, lscope, target):
        # Update current variables with lscope
        vars(self).update(lscope)
        # Add reference to self
        self.self = self
        # A generator that delivers an endless stream of self. Useful for list-comprehension
        self.rr_self = self.generator_self()
        # Used by ActionRCommand
        self.rr_target = target
        # Ensure rr_tname is set to current target name
        if target is not None:
            self.rr_tname = target.config["name"]
        else:
            self.rr_tname = None

    def generator_self(self):
        while True:
            yield self

    async def process(self, actionData, action):
        log.debug("[%s] [%s]" % (action, self))
        try:
            self.rr_adata = actionData
            actionData = await action.process(actionData, action, self)
            return actionData
        except asyncio.CancelledError as e:
            raise e
        except Exception as e:
            # TODO
            print("ActionContext: exception1 >", actionData)
            print("ActionContext: exception2 >", vars(self))
            print("ActionContext: exception3 >", e)
            traceback.print_exc(file=sys.stdout)

    # Get local scope variable value: rr_adata, rr_result, rr_self, rr_tname
    def getLocalScopeVariable(self, name):
        return vars(self).get(name, None)
