#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: action central-streaming-decoder: decode Central streaming API message.
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
'''
#
'''

import base64
import logging
import socket
import struct
from .Action import Action
#from ..dataparser.protobuf.central.streaming.v250.apprf_pb2 import apprf_session as AppRFSession
#from ..dataparser.protobuf.central.streaming.v250.audit_pb2 import audit_message as AuditMessage
#from ..dataparser.protobuf.central.streaming.v250.location_pb2 import stream_location as Location
#from ..dataparser.protobuf.central.streaming.v250.monitoring_pb2 import MonitoringInformation
#from ..dataparser.protobuf.central.streaming.v250.presence_pb2 import presence_event as PresenceEvent
#from ..dataparser.protobuf.central.streaming.v250.security_pb2 import RapidsStreamingEvent
#from ..dataparser.protobuf.central.streaming.v250.streaming_pb2 import MsgProto
from ..dataparser.protobuf.central.streaming.v253.apprf_pb2 import apprf_session as AppRFSession
from ..dataparser.protobuf.central.streaming.v253.audit_pb2 import audit_message as AuditMessage
from ..dataparser.protobuf.central.streaming.v253.location_pb2 import stream_location as Location
from ..dataparser.protobuf.central.streaming.v253.monitoring_pb2 import MonitoringInformation
from ..dataparser.protobuf.central.streaming.v253.presence_pb2 import presence_event as PresenceEvent
from ..dataparser.protobuf.central.streaming.v253.security_pb2 import RapidsStreamingEvent
from ..dataparser.protobuf.central.streaming.v253.streaming_pb2 import MsgProto
from google.protobuf.descriptor import FieldDescriptor
from google.protobuf.json_format import MessageToDict
from google.protobuf.reflection import MakeClass


# Logger
log = logging.getLogger(__name__)


# Converters
def bytes2str(v):
    return base64.b64decode(v).decode('utf-8')

def str2uint64(v):
    return int(v)

def str2int64(v):
    return int(v)

def ip2str(v):
    if v['af'] == 'ADDR_FAMILY_INET':
        # IPv4
        addr = base64.b64decode(v['addr'])
        if len(addr) == 0:
            v = None
        else:
            #(ip) = struct.unpack("!I", b)
            try:
                v = socket.inet_ntop(socket.AF_INET, addr)
            except ValueError:
                v = addr.decode("utf-8")
    elif v['af'] == 'ADDR_FAMILY_INET6':
        # IPv6
        addr = base64.b64decode(v['addr'])
        if len(addr) == 0:
            v = None
        else:
            try:
                v = socket.inet_ntop(socket.AF_INET6, addr)
            except ValueError:
                v = addr.decode("utf-8")
    else:
        v = None
    return v

def mac2str(v):
    #v = base64.b64decode(v['addr']).hex()
    return "%02x:%02x:%02x:%02x:%02x:%02x" % struct.unpack("BBBBBB", base64.b64decode(v['addr']))

def presence_mac2str(v):
    mac_address = base64.b64decode(v['addr']).lower().decode('utf-8')
    return ':'.join(format(s, '02x') for s in bytes.fromhex(mac_address))

def uint642ip(v):
    b = struct.pack('!Q', v)
    return socket.inet_ntop(socket.AF_INET, b[-4:])


# Post-processors
def postProcessMonitoring(v):
    if 'uplinkProbeStats' in v:
        for uplinkProbeStats in v['uplinkProbeStats']:
            if 'probeIpAddr' in uplinkProbeStats:
                # probeIpAddr is encoded in an uint64!
                ev = uplinkProbeStats['probeIpAddr']
                dv = uint642ip(ev)
                uplinkProbeStats['probeIpAddr'] = dv
            if 'vpncIpAddr' in uplinkProbeStats:
                # vpncIpAddr is encoded in an uint64!
                ev = uplinkProbeStats['vpncIpAddr']
                dv = uint642ip(ev)
                uplinkProbeStats['vpncIpAddr'] = dv


# Root objects
rootObjects = {
    'apprf': { 'root': AppRFSession(),
               'fields': None,
               'messages': {
                   "<class 'apprf_pb2.ip_address'>": ip2str,
                   "<class 'apprf_pb2.mac_address'>": mac2str
               }
    },
    'audit': { 'root': AuditMessage(),
               'fields': None,
               'messages': {
                   "<class 'audit_pb2.ip_address'>": ip2str,
                   "<class 'audit_pb2.mac_address'>": mac2str
               }
    },
    'location': { 'root': Location(),
                  'fields': None,
                  'messages': {
                      "<class 'location_pb2.mac_address'>": mac2str
                  }
    },
    'monitoring': { 'root': MonitoringInformation(),
                    'fields': None,
                    'messages': {
                        "<class 'monitoring_pb2.IpAddress'>": ip2str,
                        "<class 'monitoring_pb2.MacAddress'>": mac2str
                    }
    },
    'presence': { 'root': PresenceEvent(),
                  'fields': None,
                  'messages': {
                      "<class 'presence_pb2.mac_address'>": presence_mac2str
                  }
    },
    'security': { 'root': RapidsStreamingEvent(),
                  'fields': None,
                  'messages': {
                      "<class 'security_pb2.MacAddress'>": mac2str
                  }
    }
}


'''
# Understands following YAML
# - action: central-streaming-decoder
#   version: 2.5.0                       # OPTIONAL (protobuf)
#
'''
class ActionCentralStreamingDecoder(Action):
    OPTIONS_VERSION = "version"

    def __init__(self, rcommand, actionConfig, actionPipeline):
        Action.__init__(self, rcommand, actionConfig, actionPipeline)
        self.version = actionConfig.get("version", None)
        self.processObjects()

    def processObjects(self):
        for k, v in rootObjects.items():
            fields = []
            log.debug("collecting fields for: %s, %s" % (v['root'], v['messages']))
            self.processObject(v['root'], v['messages'], fields, None)
            v['fields'] = fields
            log.debug('---')
            for field in fields:
                log.debug(field)
            log.debug('-')

    def processObject(self, messageObject, messages, fields, path):
        if path is None:
            path = []
        names = []
        clazz = str(messageObject)
        valueConverter = messages.get(clazz, None)
        if valueConverter is not None:
            log.debug("clazz match: %s" % (clazz))
            names.append((path[-1], valueConverter))
            fields.append((path[0:-1], names))
            return
        for field in messageObject.DESCRIPTOR.fields:
            if field.message_type is not None:
                # Another message
                childMessageObject = MakeClass(field.message_type)
                childPath = path.copy()
                childPath.append(field.json_name)
                self.processObject(childMessageObject, messages, fields, childPath)
            elif field.type == FieldDescriptor.TYPE_UINT64:
                # UINT64
                log.debug("uint64: %s, %s" % (field.json_name, path))
                names.append((field.json_name, str2uint64))
            elif field.type == FieldDescriptor.TYPE_INT64:
                # INT64
                log.debug("int64: %s, %s" % (field.json_name, path))
                names.append((field.json_name, str2int64))
            elif field.type == FieldDescriptor.TYPE_BYTES:
                # BYTES
                log.debug("bytes: %s, %s" % (field.json_name, path))
                names.append((field.json_name, bytes2str))
        if len(names) > 0:
            fields.append((path, names))

    def __str__(self):
        return "ActionCentralStreamingDecoder: %s" % (self.version)

    @staticmethod
    async def process(actionData, action, actionContext):
        # TODO: this decoder should probably resolve macAddr and ipAddr
        # https://github.com/protocolbuffers/protobuf/blob/master/python/google/protobuf/descriptor.py
        msgProto = MsgProto()
        msgProto.ParseFromString(actionData)
        msgProtoDict = MessageToDict(msgProto)
        if 'timestamp' in msgProtoDict:
            msgProtoDict['timestamp'] = float(msgProtoDict['timestamp']) / 1000000000.0
        if msgProto.subject == "apprf":
            appRFSession = AppRFSession()
            appRFSession.ParseFromString(msgProto.data)
            appRFSessionDict = MessageToDict(appRFSession)
            msgProtoDict['data'] = appRFSessionDict
            convertFields(rootObjects['apprf'], appRFSessionDict)
        elif msgProto.subject == "audit":
            audit_message = AuditMessage()
            audit_message.ParseFromString(msgProto.data)
            auditMessageDict = MessageToDict(audit_message)
            msgProtoDict['data'] = auditMessageDict
            convertFields(rootObjects['audit'], auditMessageDict)
        elif msgProto.subject == "location":
            location = Location()
            location.ParseFromString(msgProto.data)
            locationDict = MessageToDict(location)
            msgProtoDict['data'] = locationDict
            convertFields(rootObjects['location'], locationDict)
        elif msgProto.subject == "monitoring":
            # MonitoringInformation
            monitoringInformation = MonitoringInformation()
            monitoringInformation.ParseFromString(msgProto.data)
            monitoringInformationDict = MessageToDict(monitoringInformation)
            msgProtoDict['data'] = monitoringInformationDict
            convertFields(rootObjects['monitoring'], monitoringInformationDict)
            postProcessMonitoring(monitoringInformationDict)
        elif msgProto.subject == "presence":
            presenceEvent = PresenceEvent()
            presenceEvent.ParseFromString(msgProto.data)
            presenceEventDict = MessageToDict(presenceEvent)
            msgProtoDict['data'] = presenceEventDict
            convertFields(rootObjects['presence'], presenceEventDict)
        elif msgProto.subject == "security":
            rapidStreamingEvent = RapidsStreamingEvent()
            rapidStreamingEvent.ParseFromString(msgProto.data)
            rapidStreamingEventDict = MessageToDict(rapidStreamingEvent)
            msgProtoDict['data'] = rapidStreamingEventDict
            convertFields(rootObjects['security'], rapidStreamingEventDict)
        actionData = { msgProtoDict['subject']: msgProtoDict }
        return actionData


def convertFields(rootObject, messageDict):
    for field in rootObject['fields']:
        # Work on path
        (path, names) = field
        log.debug("processing field %s %s" % (path, names))
        convertField(path, messageDict, names)

def convertField(path, d, names):
    log.debug("recurse path: %s, d: %s, names: %s" % (path, d, names))
    if len(path) == 0:
        for name, converter in names:
            if not name in d:
                continue
            iv = d[name]
            d[name] = converter(iv)
            log.debug("converting name: %s, from: %s, to: %s", name, iv, d[name])
    else:
        p = path[0]
        if p in d:
            d = d[p]
            if isinstance(d, list):
                for _d in d:
                    convertField(path[1:], _d, names)
            else:
                convertField(path[1:], d, names)
