#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: action rcommand: run named rcommand.
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
'''
#
'''

import logging
from .Action import Action
from ..Execution import ExecutionFuture
from ..RestExecution import RestExecutionRunner
from ..RestRecorder import RestRecorder


# Logger
log = logging.getLogger(__name__)


'''
# Understands following YAML
# - action: rcommand
#   name: <rcommand name>
#
'''
class ActionRCommand(Action):
    def __init__(self, rcommand, actionConfig, actionPipeline):
        Action.__init__(self, rcommand, actionConfig, actionPipeline)

    def open(self):
        super(ActionRCommand, self).open()
        rr_context = RestRecorder.get_rr_context()
        self.target_rcommand = \
            rr_context.rcommands.getRCommandByName(self.actionConfig["name"])
        if self.target_rcommand is None:
            raise "rcommand [%s] not found" % (self.actionConfig["name"])

    def __str__(self):
        return "ActionRCommand: %s" % (self.rcommand)

    @staticmethod
    async def process(actionData, action, actionContext):
        target_rcommand = action.target_rcommand
        rr_context = RestRecorder.get_rr_context()
        # When running a named rcommand:
        # - when called from an ipipe, defaultTargets will be all targets of the platform
        # - when called from an opipe, defaultTargets will be the current target processed
        defaultTargets = \
            rr_context.targets.getTargetsByPlatform(target_rcommand.platform)
        if actionContext.rr_target is not None:
            defaultTargets = [ actionContext.rr_target ]
        restRunner = RestExecutionRunner(rr_context.restProcessor, target_rcommand,
                                         defaultTargets, adata_in=actionData)
        restFuture = ExecutionFuture(restRunner)
        actionData = await restFuture.get()
        return actionData
