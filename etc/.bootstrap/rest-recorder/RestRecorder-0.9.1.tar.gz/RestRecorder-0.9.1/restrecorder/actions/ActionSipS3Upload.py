#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: action s3upload: upload to S3.
#
# Authors: SIP dev. team.
#
'''

'''
# Parameters
'''
'''
#
'''

import base64
import json
import os
import time
from .Action import Action
from ..core.s3app import prep_output_dir,upload_file_to_s3,code_dir_path,cleanup_data_directory
from ..RestRecorder import RestRecorder
from datetime import datetime


rr_time = str(int(time.time()))

class ActionSipS3Upload(Action):
    def __init__(self, rcommand, actionConfig, actionPipeline):
        Action.__init__(self, rcommand, actionConfig, actionPipeline)
        self.platform = rcommand.platform

    def __str__(self):
        return "ActionS3Upload: %s" % (self.actionConfig["action"])

    @staticmethod
    async def process(actionData, action, actionContext):
        source = actionContext.getLocalScopeVariable('rr_tname')
        rr_context = RestRecorder.get_rr_context()
        print("Source",source)
        #time = str(datetime.utcnow().strftime("%Y%m%d%H%M%S"))
        #print(time)
        originTags = rr_context.origin.getOriginTags(source)
        config_values = originTags
        s3_details= rr_context.s3details
        if type(actionData) == list:

            actionData.append(config_values)
            fileContent = json.dumps(actionData)
            #fileContent = ' '.join(map(str, actionData))
        elif type(actionData) == dict:
            actionData.update(config_values)
            fileContent = json.dumps(actionData)
        print(actionData)

        customer_id = s3_details["account_id"]
        sub_account_id = config_values['nd.origin.sub_account_id'] #s3_details["sub_account_id"]
        bucket_name = s3_details["s3_bucket"]
        aws_region = s3_details["s3_region"]

        aws_secret = base64.b64decode(s3_details["aws_secret_access_key"]).decode("utf-8")
        aws_key = base64.b64decode(s3_details["aws_access_key_id"]).decode("utf-8")
        aws_role = s3_details["iam_role_name"]
        collector_id = s3_details["collector_id"]
        s3_directory = s3_details["customer_folder"]
        kms_key = s3_details["kms_key"]

        output_base_dir, timestamp = prep_output_dir(sub_account_id,collector_id, customer_id, aws_region)
        #print(output_base_dir)
        #filename = source+"_"+datetime.now().strftime("%Y%m%d%H%M%S") + '.log'
        filename =  rr_time + "_" +config_values['nd.origin.device_id'] + '.log'
        print("Content is getting written into",filename)
        file_path = os.path.join(output_base_dir,filename)
        #print(fileContent)
        with open(file_path , 'a+') as  f:
            f.write(fileContent+'\n.....\n')

        output_root_dir = os.path.join(code_dir_path, "..", "output_data")
        curr_dir = os.getcwd()
        os.chdir(output_root_dir)
        inner_folder_path = os.path.join("%s-%s" %(customer_id, aws_region), collector_id, "rest", "raw", timestamp)
        new_file_path = os.path.join(inner_folder_path, file_path.split("/")[-1])

        inner_folder_path = os.path.join("%s-%s" %(customer_id, aws_region), collector_id, "rest","raw", timestamp)
        upload_file_to_s3(new_file_path, bucket_name, aws_key, aws_secret, aws_role,s3_directory,kms_key)
        #cleanup_data_directory(inner_folder_path)

        return(actionData)
