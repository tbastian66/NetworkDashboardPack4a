#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: REST execution.
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
'''
#
'''

import asyncio
import json
import logging
import traceback
from .Commons import requestsResponseDumpOverview
from .Execution import Runnable, ExecutionTaskContext, ExecutionFuture
from .RestQuery import RestQuery
from .RestResult import RestResult
from .RestRecorder import RestRecorder


# Logger
log = logging.getLogger(__name__)


'''
# A RestExecutionRunner runs the rcommand
'''
class RestExecutionRunner(Runnable):
    def __init__(self, restProcessor, rcommand, defaultTargets, adata_in=None):
        log.debug("initializing")
        self.rr_restProcessor = restProcessor
        self.rr_rcommand = rcommand
        self.rr_defaultTargets = defaultTargets
        self.rr_adata_in = adata_in
        self.rr_adata_out = None

    def getExecutionSchedule(self):
        return self.rr_rcommand.config["schedule"]

    # Override
    async def run(self):
        # MUST catch all exceptions
        try:
            log.debug("execution run, rr_adata_in [%s]" % str(self.rr_adata_in))

            # run the input pipeline
            actionContext = Runnable.buildActionContext("action: ipipe", None,
                                                        self, pscope=None)
            self.rr_adata = await self.process_actions(actionContext,
                                                       self.rr_rcommand.iactions,
                                                       "ipipe",
                                                       self.rr_adata_in)

            # evaluate resulting targets
            targets = self.rr_defaultTargets
            if self.rr_rcommand.targets is not None:
                targets = await self.eval_targets(vars(actionContext))
                log.debug("using dynamic targets [%s]" % (targets))
            else:
                log.debug("using default targets [%s]" % (targets))

            # Per-target task are scheduled. Each task will merge its data with taskContext.merge()
            log.debug("running per-target tasks [%d]" % (len(targets)))
            targetTaskFutures = []
            cscope = Runnable.buildScope("target tasks", self, pscope=vars(actionContext))
            taskContext = ExecutionTaskContext(scope=cscope)
            for target in targets:
                try:
                    targetTaskRunnable = RestExecutionTargetTask(target, self.rr_restProcessor,
                                                                 self.rr_rcommand, taskContext)
                    targetTaskFuture = ExecutionFuture(targetTaskRunnable)
                    targetTaskFutures.append(targetTaskFuture)

                except asyncio.CancelledError as e:
                    raise e

                except Exception as e:
                    traceback.print_exc()
                    log.error("execution/task failed(e) [%s]" % (e))

                finally:
                    pass

            # Wait for tasks. Each task has already added its output to taskContext using merge()
            log.debug("waiting per-target tasks [%d]" % (len(targetTaskFutures)))
            for targetTaskFuture in targetTaskFutures:
                v = await targetTaskFuture.get()
                log.debug("per-target future get [%s]" % (v))

            # Collected outputs
            self.rr_adata_out = taskContext.get()

            log.debug("execution done, rr_adata_out [%s]" % self.rr_adata_out)

        except asyncio.CancelledError as e:
            # Task is being cancelled
            log.debug("execution cancelled [%s]" % (self))
            raise e

        except Exception as e:
            traceback.print_exc()
            log.error("execution failed(e) [%s]" % (e))

        finally:
            pass

        # Task return
        return self.rr_adata_out


'''
# A RestExecutionTargetTask exists per active target
'''
class RestExecutionTargetTask(Runnable):
    def __init__(self, target, restProcessor, rcommand, taskContext):
        # Setup local scope
        self.setupLocalScope(taskContext.scope)
        # Use the reserved namespace
        self.rr_target = target
        self.rr_restProcessor = restProcessor
        self.rr_rcommand = rcommand
        self.rr_taskContext = taskContext

    # Override
    async def run(self):
        # MUST catch all exceptions
        try:
            log.debug("task execution start [%s]" % (self.rr_target))
            rcommand_config = self.rr_rcommand.config

            # Get work URLs
            (urls, indexVariable) = self.get_urls(rcommand_config)
            self.rr_indexVariable = indexVariable
            self.rr_result = None

            urlIndex = 0
            for url in urls:
                try:
                    log.debug("processing URL [%s]" % (url))

                    # Set variable
                    self.set_variable(indexVariable, { "#": urlIndex, "url": url })

                    # Prepare final headers
                    headers = self.get_headers(rcommand_config)

                    # Prepare final params
                    params = self.get_params(rcommand_config)

                    # Prepare final body
                    body = self.get_body(rcommand_config)
                    if len(body) == 0:
                        body = None

                    if self.rr_rcommand.page is not None:
                        # Process page query
                        restResults = await self.process_query_page(rcommand_config, url,
                                                                    params, body, headers)
                        # Save results
                        if self.rr_target.messageWriter is not None:
                            for restResult in restResults:
                                resultText = str(restResult)
                                log.debug("file output [%s]" % (resultText))
                                self.rr_target.messageWriter.write(resultText)
                    else:
                        # Process standard query
                        restResult = await self.process_query_standard(rcommand_config, url,
                                                                       params, body, headers)
                        # Save result
                        if self.rr_target.messageWriter is not None:
                            resultText = str(restResult)
                            log.debug("file output [%s]" % (resultText))
                            self.rr_target.messageWriter.write(resultText)

                    urlIndex += 1

                except asyncio.CancelledError as e:
                    raise e

                except Exception as e:
                    traceback.print_exc()
                    log.error("url failed(e) [%s]" % (e))

                finally:
                    pass

            # Delete variable
            self.reset_variable(indexVariable)
            self.rr_result = None

            log.debug("task execution done")

        except asyncio.CancelledError as e:
            # Task is being cancelled
            log.debug("execution cancelled [%s]" % (self))
            raise e

        except Exception as e:
            traceback.print_exc()
            log.error("task execution failed(e) [%s]" % (e))

        finally:
            pass

    async def run_query(self, restQuery):
        rr_context = RestRecorder.get_rr_context()
        _processed4xx = False
        while True:
            self.rr_target.stats.increment(restQuery.url, group=restQuery.method)
            restContext = self.rr_target.restContext()
            async with restContext:
                restResult = await self.rr_restProcessor.process(restQuery, restContext)
            self.rr_result = restResult
            if restResult.response is not None:
                print(requestsResponseDumpOverview(restResult.response),
                      file=rr_context.printStream)
            if not _processed4xx and (restResult.status <= -401) and (restResult.status >= -499):
                # Got 4xx, let target handle it
                if await self.rr_target.handle4xx(restResult.status):
                    _processed4xx = True
                    continue
            if rr_context.cliOptions.label is not None:
                restResult.setData(RestResult.DATA_KEY_LABEL, rr_context.cliOptions.label)
            if rr_context.origin is not None:
                originTags = rr_context.origin.getOriginTags(restResult.source)
                if originTags is not None:
                    restResult.setData(RestResult.DATA_KEY_ORIGIN, originTags)
            return restResult

    async def process_result(self, restResult, page_end_kv=None):
        rr_context = RestRecorder.get_rr_context()
        if restResult.status >= 0:
            # Query was successful, keep processing
            # Default Content-Type: application/json
            contentType = 'application/json'
            if restResult.response is not None and restResult.response.headers is not None:
                if 'Content-Type' in restResult.response.headers:
                    _contentType = restResult.response.headers['Content-Type'].split(';')
                    if _contentType is not None and len(_contentType) >= 1:
                        contentType = _contentType[0]
            currentOutput = None
            # Some legacy CPPM API endpoints returns contentType as "application/hal+json"
            if contentType == 'application/json' or contentType == 'text/html' or \
                contentType == 'application/hal+json' or contentType == 'application/problem+json':
                # JSON data
                try:
                    currentOutput = json.loads(restResult.stdout)
                except Exception as e:
                    log.error("json.loads failed [%s]" % e)
                try:
                    if page_end_kv is not None:
                        # Evaluate end of paging
                        self.rr_page['_rr_pdata'] = currentOutput
                        self.eval_kv(page_end_kv, self.rr_page)
                        self.rr_page['_rr_pdata'] = None
                except Exception as e:
                    log.error("page end eval failed [%s]" % e)
            else:
                # TODO: Other: TBD
                log.error("unsupported Content-Type [%s]" % (contentType))
            if currentOutput is not None:
                actionContext = Runnable.buildActionContext("action: opipe", self.rr_target,
                                                            self, pscope=self.rr_taskContext.scope,
                                                            anames=[self.rr_indexVariable])
                currentOutput = await self.process_actions(actionContext,
                                                           self.rr_rcommand.oactions,
                                                           "opipe",
                                                           currentOutput)
            if currentOutput is not None:
                self.rr_taskContext.merge(currentOutput)
                # Attempt to dump as JSON, fallback to plain text
                try:
                    if rr_context.cliOptions.pretty_print:
                        restResult.stdout = json.dumps(currentOutput,
                                                       indent=2,
                                                       sort_keys=True)
                    else:
                        restResult.stdout = json.dumps(currentOutput)
                except Exception as e:
                    log.error("json.dumps failed [%s]" % e)
                    restResult.stdout = str(currentOutput)
            else:
                restResult.stdout = ""

    async def process_query_standard(self, rcommand_config, url, params, body, headers):
        # Generate query
        restQuery = RestQuery(rcommand_config["method"], url, params=params, body=body, headers=headers)
        # Run query
        restResult = await self.run_query(restQuery)
        # Process result
        await self.process_result(restResult)
        # Done
        return restResult

    async def process_query_page(self, rcommand_config, url, params, body, headers):
        log.debug("paging start [%s]" % (self.rr_rcommand.page))
        self.rr_page = {}
        self.rr_page['_rr_begin'] = self.rr_rcommand.page.get("begin", None)
        self.rr_page['_rr_next'] = self.rr_rcommand.page.get("next", None)
        self.rr_page['_rr_end'] = self.rr_rcommand.page.get("end", None)
        if self.rr_page['_rr_end'] is None:
            # Default end of paging
            v = 'self.rr_page["_rr_pdata"].get("count", 0) == 0'
            self.rr_page['_rr_end'] = (v, compile(v, v, 'eval'))
        self.rr_page['_rr_key_offset'] = self.rr_rcommand.page.get("offset", "offset")
        self.rr_page['_rr_key_limit'] = self.rr_rcommand.page.get("limit", "limit")
        self.rr_page['_rr_default_offset'] = 0
        self.rr_page['_rr_default_limit'] = self.rr_rcommand.page.get("size", 20)
        self.rr_page['_rr_pdata'] = None
        if self.rr_page["_rr_begin"] is not None:
            _rr_begin_kv = { "_rr_begin_kv": self.rr_page['_rr_begin'] }
            self.eval_kv(_rr_begin_kv, self.rr_page)
            self.rr_page.update(self.rr_page['_rr_begin_kv'])
        else:
            self.rr_page[self.rr_page['_rr_key_offset']] = self.rr_page['_rr_default_offset']
            self.rr_page[self.rr_page['_rr_key_limit']] = self.rr_page['_rr_default_limit']

        restResults = []
        while True:
            # Generate paged params, discard '_rr*' keys
            pparams = {}
            for k, v in self.rr_page.items():
                if k.startswith('_rr'):
                    continue
                pparams[k] = v
            pparams.update(params)
            log.debug("page pparams: [%s] rr_page: [%s]" % (pparams, self.rr_page))

            # Generate query
            restQuery = RestQuery(rcommand_config["method"], url, params=pparams, body=body, headers=headers)

            # Run query
            restResult = await self.run_query(restQuery)
            restResults.append(restResult)

            # Process result
            if restResult.status < 0:
                # Query failed, abort paging
                log.debug("paging abort on status < 0")
                break

            # Prepare page_end eval, output will be in self.rr_page
            page_end_kv = { "_rr_pstop": self.rr_page['_rr_end'] }
            await self.process_result(restResult, page_end_kv)
            page_stop = self.rr_page.get('_rr_pstop', None)
            if page_stop is not None:
                # Found an end of paging indication
                try:
                    if page_stop:
                        break
                except Exception as e:
                    log.debug("paging stop not boolean [%s]" % (page_stop))
                    break
            else:
                # Did not find an end of paging indication, stop
                log.debug("paging stop not found [%s]" % (self.rr_page))
                break

            # Next: advance offset
            if self.rr_page["_rr_next"] is not None:
                _rr_next_kv = { "_rr_next_kv": self.rr_page['_rr_next'] }
                self.eval_kv(_rr_next_kv, self.rr_page)
                self.rr_page.update(self.rr_page['_rr_next_kv'])
            else:
                self.rr_page[self.rr_page['_rr_key_offset']] = \
                    self.rr_page[self.rr_page['_rr_key_offset']] + self.rr_page[self.rr_page['_rr_key_limit']]
        log.debug("paging end [%s]" % (self.rr_rcommand.page))
        return restResults
