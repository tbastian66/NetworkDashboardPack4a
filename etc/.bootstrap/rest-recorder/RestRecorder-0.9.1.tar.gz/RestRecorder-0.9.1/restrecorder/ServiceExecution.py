#
# Copyright 2021 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: service execution.
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
'''
#
'''

import asyncio
import logging
import traceback
from .Execution import Runnable, ExecutionTaskContext, ExecutionFuture
from .RestQuery import RestQuery
from .RestResult import RestResult
from .ServiceExecutionTaskAleIap import ServiceExecutionTaskAleIap
from .ServiceExecutionTaskCentralWebhook import ServiceExecutionTaskCentralWebhook


# Logger
log = logging.getLogger(__name__)


# TODO: refactor
serviceExecutionTaskMap = {
    "service-ale-iap": ServiceExecutionTaskAleIap,
    "service-central-webhook": ServiceExecutionTaskCentralWebhook
}


'''
# A ServiceExecutionRunner runs the service tasks
'''
class ServiceExecutionRunner(Runnable):
    def __init__(self, restProcessor, rcommand, defaultTargets, adata_in=None):
        log.debug("initializing")
        self.rr_rcommand = rcommand
        self.rr_defaultTargets = defaultTargets
        self.rr_adata_in = adata_in
        self.rr_adata_out = None

    def getExecutionSchedule(self):
        return self.rr_rcommand.config["schedule"]

    # Override
    async def run(self):
        # MUST catch all exceptions
        try:
            log.debug("execution run, rr_adata_in [%s]" % str(self.rr_adata_in))

            # run the input pipeline
            actionContext = Runnable.buildActionContext("action: ipipe", None,
                                                        self, pscope=None)
            self.rr_adata = await self.process_actions(actionContext,
                                                       self.rr_rcommand.iactions,
                                                       "ipipe",
                                                       self.rr_adata_in)

            # evaluate resulting targets
            targets = self.rr_defaultTargets
            if self.rr_rcommand.targets is not None:
                targets = await self.eval_targets(vars(actionContext))
                log.debug("using dynamic targets [%s]" % (targets))
            else:
                log.debug("using default targets [%s]" % (targets))

            # Per-target task are scheduled
            log.debug("running per-target tasks [%d]" % (len(targets)))
            targetTaskFutures = []
            cscope = Runnable.buildScope("target tasks", self, pscope=vars(actionContext))
            taskContext = ExecutionTaskContext(scope=cscope)
            for target in targets:
                try:
                    targetTaskClazz = serviceExecutionTaskMap.get(target.platform, None)
                    if targetTaskClazz is None:
                        log.error("cannot find service task for [%s]" % (target.platform))
                        continue
                    targetTaskRunnable = targetTaskClazz(target, self.rr_rcommand, taskContext)
                    targetTaskFuture = ExecutionFuture(targetTaskRunnable)
                    targetTaskFutures.append(targetTaskFuture)

                except asyncio.CancelledError as e:
                    raise e

                except Exception as e:
                    traceback.print_exc()
                    log.error("execution/task failed(e) [%s]" % (e))

                finally:
                    pass

            # Wait for tasks
            log.debug("waiting per-target tasks [%d]" % (len(targetTaskFutures)))
            for targetTaskFuture in targetTaskFutures:
                v = await targetTaskFuture.get()
                log.debug("per-target future get [%s]" % (v))

            log.debug("execution done, rr_adata_out [%s]" % self.rr_adata_out)

        except asyncio.CancelledError as e:
            # Task is being cancelled
            log.debug("execution cancelled [%s]" % (self))
            raise e

        except Exception as e:
            traceback.print_exc()
            log.error("execution failed(e) [%s]" % (e))

        finally:
            pass

        # Task return
        return self.rr_adata_out
