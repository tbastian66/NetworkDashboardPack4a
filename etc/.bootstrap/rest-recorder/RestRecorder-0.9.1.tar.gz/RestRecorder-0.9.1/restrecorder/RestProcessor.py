#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: processor.
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
'''
#
'''
import logging
import random
import time

import asyncio
from multidict import MultiDict

from .Commons import requestsResponseDump
from .RestResult import RestResult

MIN_DELAY_FACTOR = 0
MAX_DELAY_FACTOR = 16

# Logger
log = logging.getLogger(__name__)


'''
# Processes all REST calls
'''
class RestProcessor():
    def __init__(self):
        log.debug("initializing")

    # Execute REST query within the REST context and return REST result
    async def process(self, restQuery, restContext):
        # http://docs.python-requests.org/en/latest/api/#sessionapi
        log.debug("process request [%s], context [%s]" % (restQuery, restContext))
        restResult = RestResult()
        restResult.query = restQuery
        restResult.localBeginTime = time.time()
        restResult.source = restContext.target.config['name']
        rate_limit = float(restContext.target.config['rate_limit'])
        if rate_limit <= 0:
            throttle = 0
        else:
            throttle = restContext.target.config['throttle']
        retries = int(restContext.target.config['retries'])
        rate_limit_exceeded_codes = restContext.target.config["rate_limit_exceeded_codes"]

        # Session OK?
        restSession = restContext.session
        if restSession is None:
            # 503 Service Unavailable
            log.debug("no session")
            restResult.status = -503
            restResult.localEndTime = time.time()
            return restResult

        # NULL method?
        if restQuery.method == "NULL":
            # NULL method always succeeds and returns {}
            log.debug("NULL method")
            restResult.status = 0
            restResult.stdout = "{}"
            restResult.localEndTime = time.time()
            return restResult

        # Derive URL
        baseURL = restContext.baseURL
        timeout = restContext.target._get_aiohttp_timeout()
        url = baseURL + restQuery.url
        log.debug("process url [%s]" % (url))
        # aiohttp does not support the concept of default params.
        # restQuery.params values may be lists for representing multi-valued query parameters.
        params = MultiDict()
        if restContext.defaultParams is not None:
            params.update(restContext.defaultParams)
        for (k, v) in restQuery.params.items():
            if type(v) == list:
                for _v in v:
                    params.add(k, _v)
            else:
                params.add(k, v)
        # aiohttp does not support the concept of default headers.
        headers = {}
        if restContext.defaultHeaders is not None:
            headers.update(restContext.defaultHeaders)
        headers.update(restQuery.headers)
        if retries > 0:
            more_tries = retries + 1  # How many more times to try
        else:
            more_tries = 1

        while more_tries > 0:
            more_tries -= 1
            attempts = retries - more_tries + 1
            try:
                if throttle:
                    # Preceed call with a random delay so as to minimise chance of rate-limit
                    # exceed. Useful for RR with multiple threads
                    rate = 1 / rate_limit
                    delay = random.uniform(rate * MIN_DELAY_FACTOR, rate * MAX_DELAY_FACTOR)
                    log.debug(f"Random throttling for {delay:.3f}s")
                    await asyncio.sleep(delay)
                async with restSession.request(restQuery.method,
                                               url,
                                               params=params,
                                               data=restQuery.body,
                                               headers=headers,
                                               allow_redirects=False,
                                               ssl=False,
                                               timeout=timeout) as response:
                    log.debug("response %s" % requestsResponseDump(response))

                    # Check result
                    restResult.localEndTime = time.time()
                    if response.status == 200:
                        rtext = await response.text()
                        restResult.status = len(rtext)
                        restResult.stdout = rtext
                        restResult.response = response
                        log.debug(f"SUCCESS in {attempts} tries")
                        more_tries = 0  # no need to retry if successful
                    elif response.status in rate_limit_exceeded_codes:
                        log.warning(f"Attempt {attempts}. Per second rate-limit exceeded. Will retry up to {more_tries} more times")
                        if more_tries <= 0:
                            rtext = await response.text()
                            log.error(f"Max retries exceeded. Giving up on {url} ({rtext})")
                    else:
                        log.warning(f"unexpected status code: {response.status} ({response.text})"
                                    f"Retry disabled.")
                        more_tries = 0
                        restResult.status = - response.status
                        restResult.response = response
                    # return restResult
            except asyncio.CancelledError as e:
                raise e
            except Exception as e:
                log.error("Attempt %s. unexpected exception for request [%s], context [%s], exception [%s]" %
                          (attempts, restQuery, restContext, e))
                return restResult
        else:
            return restResult
