#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder globals
#
# Authors: Thomas Bastian
#
# RestRecorder.__dict__ is used to store all global variables (RestRecorder.get_rr_globals())
# RestRecorder.get_rr_context() return global rr_context
#
# The namespace rr* is reserved for RestRecorder
#
'''

'''
# Parameters
'''
'''
#
'''

import asyncio
import contextvars
import logging
import sys
from .Commons import loadYmlContent


# Logger
log = logging.getLogger(__name__)


# RestRecorder context
class RestRecorder():
    def __init__(self, printStream):
        self.printStream = printStream
        self.userLog = printStream
        self.targets = None
        self.rcommands = None
        self.restProcessor = None
        self.scheduledExecutorService = None
        self.cliOptions = None
        self.origin = None
        self.s3details = None
        self.tasks = {}

    @staticmethod
    def getContextvarsVariable(name, defaultValue=None):
        ctx = contextvars.copy_context()
        for (ctx_var, ctx_value) in ctx.items():
            if ctx_var.name == name:
                return ctx_value
        return defaultValue

    @staticmethod
    def get_rr_context():
        return RestRecorder.getContextvarsVariable("rr_context")

    def get_rr_globals(self):
        return sys.modules[__name__].__dict__

    def loadUserVariables(self):
        print("Loading user variables from %s" % \
            self.cliOptions.user_variables, file=self.printStream)
        (_user, e) = loadYmlContent(self.cliOptions.user_variables)
        if e is not None:
            if isinstance(e, IOError):
                # Ignore FileNotFound and co
                log.debug("%s not found" % self.cliOptions.user_variables)
                return
            elif isinstance(e, AttributeError):
                # AttributeError
                log.debug("attribute %s not found" % self.cliOptions.user_variables)
                return
            else:
                raise RestRecorderException(e, 1)
        if type(_user) is dict:
            log.debug("adding user variables [%s]" % (_user))
            self.get_rr_globals().update(_user)
        else:
            print("user variables needs to be dictionary", file=self.printStream)
            raise RestRecorderException(Exception("user variables needs to be dictionary"), 1)

    def execUserCode(self):
        print("Loading user code from %s" % \
            self.cliOptions.user_code, file=self.printStream)
        try:
            content = self.cliOptions.user_code.getContent()
            if content is not None:
                exec(compile(content, str(self.cliOptions.user_code), 'exec'), self.get_rr_globals())
                print("Executed user code from %s" % str(self.cliOptions.user_code), \
                      file=self.printStream)
        except Exception as e:
            if isinstance(e, IOError):
                # Ignore FileNotFound and co
                log.debug("%s not found" % self.cliOptions.user_code)
                return
            else:
                raise RestRecorderException(e, 1)

    def taskAdd(self, task):
        self.tasks[task] = task

    def taskDel(self, task):
        del self.tasks[task]

    async def taskCancelAll(self):
        log.debug("cancel %d tasks" % len(self.tasks))
        for task in self.tasks:
            task.cancel()
        for task in self.tasks:
            try:
                await task
            except asyncio.CancelledError as e:
                pass
            except Exception as e:
                log.debug("cancel task exception %s" % e)
        self.tasks = {}

    def taskGetAll(self):
        return self.tasks

    async def reprJSON(self):
        data = {}
        data['targets'] = await self.targets.reprJSON()
        data['cliOptions'] = self.cliOptions.__dict__
        data['rcommands'] = await self.rcommands.reprJSON()
        data['origin'] = self.origin
        data['s3details'] = self.s3details
        if "kafka" in self.cliOptions.log_store:
            data['kafkaWriter'] = await self.kafkaWriter.reprJSON()
            data['kafkaJSONWriter'] = await self.kafkaJSONWriter.reprJSON()
        return data

    async def reprStats(self):
        '''
        report stats
        '''
        data = {}
        data['targets'] = await self.targets.reprStats()
        if "kafka" in self.cliOptions.log_store:
            data['kafka'] = await self.kafkaJSONWriter.reprStats()
        # TODO: Stats from other modules can be added here (e.g. rcommands, restProcessor, etc)
        return data

    async def reprStatsFormatted(self):
        '''
        report stats in a table
        '''
        output = []
        targets_output = await self.targets.reprStatsFormatted()
        output.append(targets_output)
        if "kafka" in self.cliOptions.log_store:
            kafka_output = await self.kafkaJSONWriter.reprStatsFormatted()
            output.append(kafka_output)
        # TODO: Stats from other modules can be added here (e.g. rcommands, restProcessor, etc)
        return '\n'.join(output)

class RestRecorderException(Exception):
    def __init__(self, e, exitCode):
        self.e = e
        self.exitCode = exitCode


#
# BEGIN OF GLOBAL NAMESPACE
#
