#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# Kafka services.
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
'''
#
'''

import asyncio
import json
import logging
import os
import platform
import time
import traceback

from aacommons.misc.Stats import CounterEvent
from aiokafka import AIOKafkaProducer
from kafka.codec import has_gzip, has_snappy, has_lz4


# Logger
log = logging.getLogger(__name__)
# Logger for JSON
logJson = logging.getLogger(__name__ + ".json")


'''
# Kafka Writer. This is a wrapper for a KafkaProducer.
# NOTE: as per Kafka documentation, a single writer should be used per process.
'''
class KafkaWriter():
    def __init__(self, customKafkaProps=None):
        self.customKafkaProps = customKafkaProps
        self.kafkaProducer = None
        try:
            # https://kafka-python.readthedocs.io/en/master/apidoc/KafkaProducer.html
            self.kafkaProps = dict()
            self.kafkaProps["bootstrap_servers"] = "localhost:9092"
            self.kafkaProps["client_id"] = \
                "RestRecorder-" + platform.node() + "-" + str(os.getpid())
            # User supplied
            if self.customKafkaProps is not None:
                self.kafkaProps.update(self.customKafkaProps)
            compression_type = self.kafkaProps.get("compression_type", None)
            if compression_type is not None:
                if compression_type == 'gzip' and has_gzip():
                    compression_type = 'gzip'
                elif compression_type == 'lz4' and has_lz4():
                    compression_type = 'lz4'
                elif compression_type == 'snappy' and has_snappy():
                    compression_type = 'snappy'
                else:
                    compression_type = None
            security_protocol = self.kafkaProps.get("security_protocol", "PLAINTEXT")
            ssl_context = self.kafkaProps.get("ssl_context", None)
            self.kafkaProducer = AIOKafkaProducer(loop=asyncio.get_running_loop(),
                                                  bootstrap_servers=self.kafkaProps["bootstrap_servers"],
                                                  security_protocol=security_protocol, ssl_context=ssl_context,
                                                  client_id=self.kafkaProps["client_id"],
                                                  acks=1, compression_type=compression_type)
            log.info("KafkaWriter: ready")

        except asyncio.CancelledError as e:
            raise e

        except Exception as e:
            log.error(e)

    def getProducer(self):
        return self.kafkaProducer

    async def reprJSON(self):
        return dict({"customKafkaProps" : self.customKafkaProps})

'''
# Abstract Kafka JSON writer. Not to be used directly.
'''
class KafkaAbstractJSONWriter():
    def __init__(self, kafkaWriter, kafkaTopic):
        self._kafkaWriter = kafkaWriter
        self._kafkaTopic = kafkaTopic
        self.kafkaProducer = kafkaWriter.getProducer()
        self.stats = CounterEvent(name="KafkaAbstractJSONWriter")

    async def start(self):
        self._kafkaPartitionCount = len(await self.kafkaProducer.partitions_for(self._kafkaTopic))
        log.info("%s: ready, topic: %s with %d partitions" % \
                 (self.__class__.__name__, self._kafkaTopic, self._kafkaPartitionCount))

    async def partitionFor(self, topic, jsonData, partition=None):
        # By default, use partition 0. Subclasses need to override.
        return 0

    async def processJSON(self, topic, jsonData, partition=None):
        try:
            t0 = time.perf_counter()
            partition = await self.partitionFor(topic, jsonData, partition=partition)
            # TODO: do we need to encode value in UTF-8?
            value = json.dumps(jsonData)
            if logJson.isEnabledFor(logging.DEBUG):
                logJson.debug('writing JSON topic: %s, json: %s' % (topic, value))
            fut = await self.kafkaProducer.send(self._kafkaTopic,
                                                key=bytes(topic, 'utf-8'), value=bytes(value, 'utf-8'),
                                                partition=partition)
            await fut
            self.stats.increment(topic, group=self._kafkaTopic)
            partition_stat_str = f"partition_{partition:02d}"
            self.stats.increment(partition_stat_str, group="all_partitions")
            try:
                # See RecordMetadata in aiokafka/structs.py
                recordMetaData = fut.result()
                self.on_send_success(recordMetaData)
            except asyncio.CancelledError as e:
                raise e
            except Exception as e:
                self.on_send_error(e)
            t1 = time.perf_counter()
            if log.isEnabledFor(logging.DEBUG):
                log.debug('producing: %s ms' % ((t1 - t0) * 1000))

        except asyncio.CancelledError as e:
            raise e

        except Exception as e:
            log.critical('-' * 60)
            traceback.print_exc()
            log.critical('-' * 60)

    # handle completion
    def on_send_success(self, recordMetaData):
        if log.isEnabledFor(logging.DEBUG):
            log.debug('written topic: %s, metadata: %s' % \
                      (recordMetaData.topic, str(recordMetaData)))
        #print(record_metadata.topic)
        #print(record_metadata.partition)
        #print(record_metadata.offset)

    # handle exception
    def on_send_error(self, e):
        log.error('kafka exception: %s' % (e))

    # report info
    async def reprJSON(self):
        return dict({"kafkaTopic": self._kafkaTopic})

    # report stats
    async def reprStats(self):
        stop_ts = time.time()
        return self.stats.snapshot(update_stats=True, stop_ts=stop_ts)

    async def reprStatsFormatted(self):
        stop_ts = time.time()
        return self.stats.snapshot_table(update_stats=True, stop_ts=stop_ts)


'''
# Generic Kafka JSON writer.
'''
class KafkaJSONWriter(KafkaAbstractJSONWriter):
    def __init__(self, kafkaWriter, kafkaTopic):
        KafkaAbstractJSONWriter.__init__(self, kafkaWriter, kafkaTopic)

    async def partitionFor(self, topic, jsonData, partition=None):
        if partition is None:
            partition = 0
        return partition % self._kafkaPartitionCount
