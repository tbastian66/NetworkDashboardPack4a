#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# Origin
#
# Authors: Albert Pang
#

'''
# pylint: disable=invalid-name

import base64
import json
import logging


# Logger
log = logging.getLogger(__name__)


class Origin():
    '''Construct origin object. Supports:
    1. A dict
    2. A string that contains a list of comma separated key-value pairs:
       key1=value1[,key2=value]
    3. A base64 encoded JSON string
    '''
    def __init__(self, origin):
        self.origin = self._processOrigin(origin)
        self.originTagCacheBySource = {}

    def __str__(self):
        return str(self.origin)

    def getOriginTags(self, source):
        # Origin object can be either:
        # - flat: { "customerid": "customerid" }
        # - keyed by source: { "<source1>": { "customerid": "customerid" }, ... }
        if self.origin is None:
            return None
        if source is None:
            return None
        tags = self.originTagCacheBySource.get(source, None)
        if tags is None:
            # Get tags from origin
            otags = self.origin
            tags = {}
            if source in otags:
                # Keyed by source
                otags = otags[source]
            for k in otags.keys():
                if not isinstance(otags[k], dict):
                    tags['nd.origin.' + k] = otags[k]
            self.originTagCacheBySource[source] = tags
        if len(tags) == 0:
            return None
        return tags

    def _processOrigin(self, origin):
        '''
        Convert origin to a dict
    
        Parameters:
        -----------
            origin :  Supported origin objects:
                - dict object
                - base64 encoded JSON
                - "key1=value1[,key2=value]"
    
        Returns:
        --------
            dict
        '''
        if isinstance(origin, dict):
            return origin
        if isinstance(origin, str) or isinstance(origin, unicode):
            # base64 encoded JSON or "key1=value1[,key2=value]"
            if (len(origin) % 4) == 0:
                # Possibly base64 encoded JSON
                try:
                    _origin = base64.b64decode(origin)
                    return json.loads(_origin)
                except TypeError:
                    log.debug('base64 decode failed: %s' % (origin))
                except Exception:
                    log.error('origin: [%s] not JSON' % (_origin))
            else:
                try:
                    kvps = origin.split(',')
                    _origin = {}
                    for _kvp in kvps:
                        kvp = _kvp.split('=', 1)
                        _origin[kvp[0]] = kvp[1]
                    return _origin
                except Exception:
                    log.error('unsupported origin type: ' + str(type(origin)))
