#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: S3 app.
#
# Authors: SIP dev. team.
#
'''

'''
# Parameters
'''
AWS_DEFAULT_REGION = 'us-east-1'
# The AWS account ID for the Aruba HTS AWS VPN
AWS_ACCOUNT_ID = '759896134434'
'''
#
'''

import boto3
import logging
import os
import shutil
import traceback
from boto3.session import Session
from datetime import datetime


# Logger
log = logging.getLogger(__name__)
code_dir_path = os.path.dirname(os.path.realpath(__file__))


def prep_output_dir(sub_account, collector_id, customer_id, aws_region):
    ts_folder_path = None
    timestamp = None
    try:
        
            log.info("Creating the output folder structure for current execution")
            output_root_dir = os.path.join(code_dir_path, "..", "output_data")
            if not os.path.exists(output_root_dir):
                os.mkdir(output_root_dir)

            customer_id_region_path = os.path.join(output_root_dir, "%s-%s" %(customer_id, aws_region))
            if not os.path.exists(customer_id_region_path):
                os.mkdir(customer_id_region_path)

            collector_id_path = os.path.join(customer_id_region_path, collector_id)
            if not os.path.exists(collector_id_path):
                os.mkdir(collector_id_path)

            cli_folder_path = os.path.join(collector_id_path, "rest")
            if not os.path.exists(cli_folder_path):
                os.mkdir(cli_folder_path)

            raw_folder_path = os.path.join(cli_folder_path, "raw")
            if not os.path.exists(raw_folder_path):
                os.mkdir(raw_folder_path)


            timestamp = datetime.utcnow().strftime("%Y%m%d")
            ts_folder_path = os.path.join(raw_folder_path, timestamp)
            if not os.path.exists(ts_folder_path):
                os.mkdir(ts_folder_path)
    except:
        log.error("There was an issue while creating the base directory for current execution")
        log.info(traceback.format_exc())

    return ts_folder_path, timestamp


def upload_file_to_s3(file_name, bucket, access_key, aws_secret, aws_role,s3_directory, kms_key):
    """
        Function to upload a file to an S3 bucket
    """
    response = False
    try:
        log.info("Uploading %s file to Customer's S3 bucket" % file_name)

        sts_client = boto3.client('sts', aws_access_key_id=access_key, aws_secret_access_key=aws_secret)
        role_arn = 'arn:aws:iam::%s:role/%s' % (AWS_ACCOUNT_ID, aws_role)
        role_session = '%s-session' % aws_role

        sts_response = sts_client.assume_role(
            RoleArn=role_arn,
            RoleSessionName=role_session,
            DurationSeconds=900
        )

        session = Session(
            aws_access_key_id=sts_response['Credentials']['AccessKeyId'],
            aws_secret_access_key=sts_response['Credentials']['SecretAccessKey'],
            aws_session_token=sts_response['Credentials']['SessionToken']
        )

        s3_client = session.client('s3')
        object_name = f'{s3_directory}/{file_name}'
        response = s3_client.upload_file(file_name, bucket, object_name,
                   ExtraArgs={"ServerSideEncryption": "aws:kms", "SSEKMSKeyId": kms_key})
        response = True
        log.info("Done uploading %s file to customer's S3 bucket" % file_name)
    except:
        response = False
        log.error("There was an error while uploading customer data to S3 bucket")
        log.error(traceback.format_exc())
    return response

def cleanup_data_directory(file_path):
    try:
        print(file_path)
        shutil.rmtree(file_path)
    except OSError as e:
        print ("Error: %s - %s." % (e.filename, e.strerror))
