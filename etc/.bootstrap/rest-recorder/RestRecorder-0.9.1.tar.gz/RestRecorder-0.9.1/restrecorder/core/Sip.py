#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# Sip
#
# This module contains code specific to the Service Insight Platform project
#
# Authors: Albert Pang
#
'''
# pylint: disable=invalid-name

import logging
from aacommons.helpers.get_my_ip import get_my_ip, get_my_external_ip


module_log = logging.getLogger(__name__)


# The following fields are to be extracted from the SIP config server to be included
# in all Kafka messages
ORIGIN_FIELDS_FOR_KAFKA_MESSAGE = ["central_customer_id", "sub_account_id"]
FIELDS_FOR_S3 = ["sub_account_id", "s3_bucket", "s3_region", "account_id",
                "aws_secret_access_key", "aws_access_key_id", "iam_role_name", 
                "collector_id","customer_folder","kms_key"]

def generateOriginFromSipConfig(sipDeviceMapping):
    '''Extract configuration information from SIP config server API to be included in the
    origin field in all Kafka messages.

    When SIP related information is retrieved from the SIP config server, certain attributes
    such as credentials are not to be included in Kafka messages.

    Parameters:
    -----------
    sipConfig : dict
        A dictionary containing attributes returned from the SIP config server

    Returns:
    --------
    dict
        A dictionary containing fiedls that are to be included in Kafka messages.
    '''

    temp_origin_values = {'collector_internal_ip': get_my_ip(), 'collector_external_ip': get_my_external_ip()}
    # for f in ORIGIN_FIELDS_FOR_KAFKA_MESSAGE:
    for each_key, each_value in sipDeviceMapping.items():
        #print(each_key, each_value)
        each_value.update(temp_origin_values)

    return sipDeviceMapping


def getS3DetailsFromSipConfig(sipConfig):
    '''Extract S3 details SIP config server API

    Parameters:
    -----------
    sipConfig : dict
        A dictionary containing attributes returned from the SIP config server

    Returns:
    --------
    dict
        A dictionary containing fiedls that are to be included in Kafka messages.
    '''

    s3_values = {}

    for f in FIELDS_FOR_S3:
        if f in sipConfig.keys():
            s3_values[f] = sipConfig[f]

    return  s3_values

if __name__ == '__main__':
    pass
