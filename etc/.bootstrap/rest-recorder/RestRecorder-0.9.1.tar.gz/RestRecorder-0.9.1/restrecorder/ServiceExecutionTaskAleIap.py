#
# Copyright 2021 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: service execution task for service-ale-iap.
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
'''
#
'''

import asyncio
import logging
import ssl
import time
import traceback
import uuid
from .Execution import Runnable, ExecutionTaskContext, ExecutionFuture
from .RestQuery import RestQuery
from .RestResult import RestResult
from aiohttp import web, MultipartReader


# Logger
log = logging.getLogger(__name__)


'''
# A ServiceExecutionTask* exists per active target
'''
class ServiceExecutionTaskAleIap(Runnable):
    def __init__(self, target, rcommand, taskContext):
        # Setup local scope
        self.setupLocalScope(taskContext.scope)
        # Use the reserved namespace
        self.rr_target = target
        self.rr_rcommand = rcommand
        self.rr_taskContext = taskContext

    # Override
    async def run(self):
        # MUST catch all exceptions
        try:
            log.debug("task execution start [%s]" % (self.rr_target.name))
            target_config = self.rr_target.config

            # By default SSL is disabled
            ssl_context = None
            if "certificate_file" in target_config and "certificate_key" in target_config:
                ssl_context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
                ssl_context.load_cert_chain(target_config["certificate_file"], target_config["certificate_key"])
            app = web.Application()
            app['_rr_task'] = self
            app.add_routes([
                web.post('/', handle_message),
                web.post('/{name}', handle_swarm)
            ])
            runner = web.AppRunner(app)
            await runner.setup()
            site = web.TCPSite(runner, port=target_config["port"], ssl_context=ssl_context)
            await site.start()
            log.debug("runner up [%s]" % (self.rr_target.name))
            while True:
                await asyncio.sleep(30)
            await runner.cleanup()

        except asyncio.CancelledError as e:
            # Task is being cancelled
            log.debug("[%s] execution cancelled [%s]" % (self.rr_target.name, self))
            raise e

        except Exception as e:
            traceback.print_exc()
            log.error("[%s] task execution failed(e) [%s]" % (self.rr_target.name, e))

        finally:
            pass


# TODO: refactor
bySessionMap = {
}

byGuidMap = {
}


'''
# Handler for /{name}
'''
async def handle_swarm(request):
    log.info("request: [%s] headers: [%s]" % (request, request.headers))
    guid = request.headers.get("X-Guid", None)
    if guid is None:
        log.error("no X-Guid found. Dropping request.")
        return web.Response(text="no X-Guid found. Dropping request.", status=400)
    # Lookup
    swarm_info = byGuidMap.get(guid, None)
    if swarm_info is None:
        # Not seen before
        sessionid = str(uuid.uuid4()).replace("-", "")
        swarm_info = dict()
        swarm_info['_createdAt'] = time.time()
        swarm_info['_sessionid'] = sessionid
        swarm_info['_guid'] = guid
        for k, v in request.headers.items():
            swarm_info[k] = v
        byGuidMap[guid] = swarm_info
        bySessionMap[sessionid] = swarm_info
        log.info("new swarm guid: [%s] sessionid: [%s] info: [%s]" % (guid, sessionid, swarm_info))
    else:
        sessionid = swarm_info['_sessionid']
        log.info("existing swarm guid: [%s] sessionid: [%s] info: [%s]" % (guid, sessionid, swarm_info))
    rheaders = { 'X-Session-Id': sessionid, 'X-Type': 'login', 'X-Status-Code': 'success' }
    return web.Response(text="OK", headers=rheaders)


'''
# Handler for /
'''
async def handle_message(request):
    log.debug("request: [%s] headers: [%s]" % (request, request.headers))
    # Validate sessionid
    sessionid = request.headers.get("X-Session-Id", None)
    if sessionid is None:
        log.error("no X-Session-Id found. Dropping request.")
        return web.Response(text="no X-Session-Id found. Dropping request.", status=400)
    swarm_info = bySessionMap.get(sessionid, None)
    if swarm_info is None:
        log.error("Unknown X-Session-Id [%s] found. Dropping request." % (sessionid))
        return web.Response(text="Unknown X-Session-Id found. Dropping request.", status=400)
    rr_task = request.app['_rr_task']
    t0 = time.perf_counter()
    reader = MultipartReader(request.headers, request.content)
    while True:
        part = await reader.next()
        if part is None:
            break
        pdata = await part.read()
        adata = { "request": request, "body": pdata }

        # Here we generate a pseudo RestResult
        restResult = RestResult()
        restResult.localBeginTime = restResult.localEndTime = time.time()
        restResult.source = rr_task.rr_target.config["name"]
        restResult.status = len(pdata)
        rr_task.rr_result = restResult

        actionContext = Runnable.buildActionContext("action: opipe", rr_task.rr_target,
                                                    rr_task, pscope=rr_task.rr_taskContext.scope)
        currentOutput = await rr_task.process_actions(actionContext,
                                                      rr_task.rr_rcommand.oactions,
                                                      "opipe",
                                                      adata)
    t1 = time.perf_counter()
    log.debug("processed in %d ms" % ((t1 - t0) * 1000))
    rheaders = { 'X-Session-Id': sessionid, 'X-Status-Code': 'success' }
    return web.Response(text="OK", headers=rheaders)
