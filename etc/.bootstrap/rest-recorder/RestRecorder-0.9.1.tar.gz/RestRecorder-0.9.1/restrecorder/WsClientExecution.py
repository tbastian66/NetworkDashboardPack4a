#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: WebSocket client execution.
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
'''
#
'''

import aiohttp
import asyncio
import logging
import time
import traceback
from .Execution import Runnable, ExecutionTaskContext, ExecutionFuture
from .RestQuery import RestQuery
from .RestResult import RestResult


# Logger
log = logging.getLogger(__name__)


'''
# A WsClientExecutionRunner runs the rcommand
'''
class WsClientExecutionRunner(Runnable):
    def __init__(self, restProcessor, rcommand, defaultTargets, adata_in=None):
        log.debug("initializing")
        self.rr_rcommand = rcommand
        self.rr_defaultTargets = defaultTargets
        self.rr_adata_in = adata_in
        self.rr_adata_out = None

    def getExecutionSchedule(self):
        return self.rr_rcommand.config["schedule"]

    # Override
    async def run(self):
        # MUST catch all exceptions
        try:
            log.debug("execution run, rr_adata_in [%s]" % str(self.rr_adata_in))

            # run the input pipeline
            actionContext = Runnable.buildActionContext("action: ipipe", None,
                                                        self, pscope=None)
            self.rr_adata = await self.process_actions(actionContext,
                                                       self.rr_rcommand.iactions,
                                                       "ipipe",
                                                       self.rr_adata_in)

            # evaluate resulting targets
            targets = self.rr_defaultTargets
            if self.rr_rcommand.targets is not None:
                targets = await self.eval_targets(vars(actionContext))
                log.debug("using dynamic targets [%s]" % (targets))
            else:
                log.debug("using default targets [%s]" % (targets))

            # Per-target task are scheduled
            log.debug("running per-target tasks [%d]" % (len(targets)))
            targetTaskFutures = []
            cscope = Runnable.buildScope("target tasks", self, pscope=vars(actionContext))
            taskContext = ExecutionTaskContext(scope=cscope)
            for target in targets:
                try:
                    targetTaskRunnable = WsClientExecutionTargetTask(target, self.rr_rcommand, taskContext)
                    targetTaskFuture = ExecutionFuture(targetTaskRunnable)
                    targetTaskFutures.append(targetTaskFuture)

                except asyncio.CancelledError as e:
                    raise e

                except Exception as e:
                    traceback.print_exc()
                    log.error("execution/task failed(e) [%s]" % (e))

                finally:
                    pass

            # Wait for tasks
            log.debug("waiting per-target tasks [%d]" % (len(targetTaskFutures)))
            for targetTaskFuture in targetTaskFutures:
                v = await targetTaskFuture.get()
                log.debug("per-target future get [%s]" % (v))

            log.debug("execution done, rr_adata_out [%s]" % self.rr_adata_out)

        except asyncio.CancelledError as e:
            # Task is being cancelled
            log.debug("execution cancelled [%s]" % (self))
            raise e

        except Exception as e:
            traceback.print_exc()
            log.error("execution failed(e) [%s]" % (e))

        finally:
            pass

        # Task return
        return self.rr_adata_out


'''
# A WsClientExecutionTargetTask exists per active target
'''
class WsClientExecutionTargetTask(Runnable):
    def __init__(self, target, rcommand, taskContext):
        # Setup local scope
        self.setupLocalScope(taskContext.scope)
        # Use the reserved namespace
        self.rr_target = target
        self.rr_rcommand = rcommand
        self.rr_taskContext = taskContext

    # Override
    async def run(self):
        # MUST catch all exceptions
        try:
            log.debug("task execution start [%s]" % (self.rr_target.name))
            rcommand_config = self.rr_rcommand.config

            # Get work URLs
            (urls, indexVariable) = self.get_urls(rcommand_config)
            self.rr_result = None

            # Per-URL task are scheduled
            urlTaskFutures = []
            cscope = Runnable.buildScope("target url tasks", self, pscope=self.rr_taskContext.scope)
            taskContext = ExecutionTaskContext(scope=cscope)
            urlIndex = 0
            for url in urls:
                try:
                    log.debug("running per-URL task URL [%s], urlIndex [%d], indexVariable [%s]" % \
                              (url, urlIndex, indexVariable))
                    urlTaskRunnable = WsClientExecutionUrlTask(self.rr_target, self.rr_rcommand, taskContext,
                                                               url, urlIndex, indexVariable)
                    urlTaskFuture = ExecutionFuture(urlTaskRunnable)
                    urlTaskFutures.append(urlTaskFuture)

                except asyncio.CancelledError as e:
                    raise e

                except Exception as e:
                    traceback.print_exc()
                    log.error("[%s] url failed(e) [%s]" % (self.rr_target.name, e))

                finally:
                    pass

                urlIndex += 1

            # Wait for tasks
            log.debug("[%s] waiting per-URL tasks [%d]" % (self.rr_target.name, len(urlTaskFutures)))
            for urlTaskFuture in urlTaskFutures:
                v = await urlTaskFuture.get()
                log.debug("[%s] per-URL future get [%s]" % (self.rr_target.name, v))

            log.debug("[%s] task execution done" % (self.rr_target.name))

        except asyncio.CancelledError as e:
            # Task is being cancelled
            log.debug("[%s] execution cancelled [%s]" % (self.rr_target.name, self))
            raise e

        except Exception as e:
            traceback.print_exc()
            log.error("[%s] task execution failed(e) [%s]" % (self.rr_target.name, e))

        finally:
            pass


'''
# A WsClientExecutionUrlTask exists per URL
'''
class WsClientExecutionUrlTask(Runnable):
    def __init__(self, target, rcommand, taskContext, url, urlIndex, indexVariable):
        # Setup local scope
        self.setupLocalScope(taskContext.scope)
        # Use the reserved namespace
        self.rr_target = target
        self.rr_rcommand = rcommand
        self.rr_taskContext = taskContext
        self.rr_url = url
        self.rr_urlIndex = urlIndex
        self.rr_indexVariable = indexVariable
        self.rr_timeoutCount = 0

    # Override
    async def run(self):
        # MUST catch all exceptions
        try:
            log.debug("task execution start [%s], url [%s], urlIndex [%d], indexVariable [%s]" % \
                      (self.rr_target.name, self.rr_url, self.rr_urlIndex, self.rr_indexVariable))
            rcommand_config = self.rr_rcommand.config

            self.rr_result = None

            # Set variable
            self.set_variable(self.rr_indexVariable, { "#": self.rr_urlIndex, "url": self.rr_url })

            # Prepare final headers
            headers = self.get_headers(rcommand_config)

            # Prepare final params
            params = self.get_params(rcommand_config)

            # Prepare final body
            body = self.get_body(rcommand_config)
            if len(body) == 0:
                body = None

            restQuery = RestQuery(rcommand_config["method"], self.rr_url, params=params, body=body, headers=headers)

            while True:
                try:
                    wsClientContext = self.rr_target.wsClientContext(method=rcommand_config["method"], url=self.rr_url, headers=headers)
                    async with wsClientContext:
                        log.debug("[%s][%d] starting websocket processing [%s] [%s]" % (self.rr_target.name, self.rr_urlIndex,
                            wsClientContext.websocket, restQuery))
                        rc = await self.run_websocket(wsClientContext.websocket, restQuery)
                        log.debug("[%s][%d] ending websocket processing [%s], rc [%d]" % (self.rr_target.name, self.rr_urlIndex,
                            wsClientContext.websocket, rc))

                except asyncio.CancelledError as e:
                    # Raise to outer
                    raise e

                except Exception as e:
                    log.error("[%s] exception: %s" % (self.rr_target.name,e))
                    traceback.print_exc()

                finally:
                    # Avoid cycling too quickly in case of errors
                    await asyncio.sleep(30)

            log.debug("[%s] task execution done" % (self.rr_target.name))

        except asyncio.CancelledError as e:
            # Task is being cancelled
            log.debug("[%s] task cancelled [%s]" % (self.rr_target.name, self))
            raise e

        except Exception as e:
            traceback.print_exc()
            log.error("[%s] url failed(e) [%s]" % (self.rr_target.name, e))

        finally:
            pass

    async def run_websocket(self, websocket, restQuery):
        if websocket is None:
            log.debug("[%s] no websocket" % (self.rr_target.name))
            return -1
        while True:
            # aiohttp.WSMessage
            log.debug("[%s][%d] waiting for websocket %s restQuery %s" % (self.rr_target.name, self.rr_urlIndex, websocket, restQuery))
            self.rr_result = None
            # Be paranoid and check for closed and exceptions before waiting
            if websocket.closed:
                log.debug("[%s] websocket closed: %s" % (self.rr_target.name, websocket))
                return 0
            e = websocket.exception()
            if e is not None:
                log.debug("[%s] websocket %s exception: %s" % (self.rr_target.name, websocket, e))
                return -1
            wsMessage = None
            try:
                # Don't block indefinitely, use readTimeout
                start_wait_ts = time.time()
                wsMessage = await websocket.receive(self.rr_target.timeout[1])
                stop_wait_ts = time.time()
                self.rr_timeoutCount = 0
                log.debug("[%s][%d] finished waiting for packet. Waited for [%.3f]" % (self.rr_target.name, self.rr_urlIndex,
                    stop_wait_ts - start_wait_ts))
            except asyncio.TimeoutError as e:
                self.rr_timeoutCount += 1
                counter_name = f"count_timeout_{self.rr_urlIndex}"
                self.rr_target.stats.increment(counter_name, 'count_timeout_all', increment=1)
                log.debug("[%s][%d] timeout (> %.1f) waiting for packet. Consecutive timeout count: %d. error:[%s]" % (self.rr_target.name, self.rr_urlIndex,
                    self.rr_target.timeout[1] , self.rr_timeoutCount, e))
                # Automatic websocket ping on timeout
                await websocket.ping()
                if (self.rr_target.aggressiveRestart > 0) and (self.rr_timeoutCount >= self.rr_target.aggressiveRestart):
                    log.error("[%s][%d] aggressive restart. reset websocket" % (self.rr_target.name, self.rr_urlIndex))
                    counter_name = f"count_aggressive_restart_{self.rr_urlIndex}"
                    self.rr_target.stats.increment(counter_name, 'count_aggressive_restart_all', increment=1)
                    self.rr_timeoutCount = 0
                    return -2
                else:
                    continue
            except Exception as e:
                raise e
            wsMessageType = wsMessage.type
            if wsMessageType == aiohttp.WSMsgType.TEXT:
                log.debug("[%s][%s] text: %d" % (self.rr_target.name, self.rr_urlIndex, len(wsMessage.data)))

            elif wsMessageType == aiohttp.WSMsgType.BINARY:
                self.rr_target.stats.increment(f'count_binary_{self.rr_urlIndex}', 'count_all', increment=1)
                self.rr_target.stats.increment(f'bytes_binary_{self.rr_urlIndex}', 'bytes_all', increment=len(wsMessage.data))
                log.debug("[%s][%d] binary: %d" % (self.rr_target.name, self.rr_urlIndex, len(wsMessage.data)))

            elif wsMessageType == aiohttp.WSMsgType.PING:
                log.debug("[%s][%s] ping" % (self.rr_target.name, self.rr_urlIndex))
                continue

            elif wsMessageType == aiohttp.WSMsgType.PONG:
                log.debug("[%s][%s] pong" % (self.rr_target.name, self.rr_urlIndex))
                continue

            elif wsMessageType == aiohttp.WSMsgType.CLOSE:
                self.rr_target.stats.increment(f'count_close_{self.rr_urlIndex}', 'count_all', increment=1)
                log.debug("[%s][%s] close" % (self.rr_target.name, self.rr_urlIndex))
                return 0

            elif wsMessageType == aiohttp.WSMsgType.CLOSED:
                self.rr_target.stats.increment(f'count_closed_{self.rr_urlIndex}', 'count_all', increment=1)
                log.debug("[%s][%s] closed frame" % (self.rr_target.name, self.rr_urlIndex))
                return 0

            elif wsMessageType == aiohttp.WSMsgType.ERROR:
                log.debug("[%s][%s] error" % (self.rr_target.name, self.rr_urlIndex))
                return -1

            else:
                log.debug("[%s][%s] other" % (self.rr_target.name, self.rr_urlIndex))
                return -1

            # Here we generate a pseudo RestResult
            restResult = RestResult()
            restResult.query = restQuery
            restResult.localBeginTime = restResult.localEndTime = time.time()
            restResult.source = self.rr_target.config["name"]
            restResult.status = len(wsMessage.data)
            restResult.stdout = str(wsMessage.data)
            self.rr_result = restResult

            actionContext = Runnable.buildActionContext("action: opipe", self.rr_target,
                                                        self, pscope=self.rr_taskContext.scope,
                                                        anames=[self.rr_indexVariable])
            currentOutput = await self.process_actions(actionContext,
                                                       self.rr_rcommand.oactions,
                                                       "opipe",
                                                       wsMessage.data)
            # TODO: is it worth saving the output?

        # Default to error
        return -1
