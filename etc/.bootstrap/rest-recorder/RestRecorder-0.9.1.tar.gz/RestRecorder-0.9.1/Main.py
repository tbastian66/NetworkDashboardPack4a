#
# Copyright 2020 Thomas Bastian, Jeffrey Goff, Albert Pang
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

'''
#
# RestRecorder: main.
#
# Authors: Thomas Bastian
#
'''

'''
# Parameters
'''
HEADLINE="RestRecorder version 0.9.1"
DESCRIPTION="\
Sends REST commands against REST enabled targets and records output.\n\
The output is saved in a file named \"rr-<target>-<date>-<time>-<id>.log\".\
"
RRSTATE_FILENAME=".rrstate.json"
DEFAULT_KAFKA_TOPIC="RR_OUT_JSON"
DEFAULT_KAFKA_TOPIC_AP_STATS="AP_STATS"
DEFAULT_KAFKA_TOPIC_AP_STATE="AP_STATE"
DEFAULT_KAFKA_TOPIC_SWITCH_STATS="SWITCH_STATS"
DEFAULT_KAFKA_TOPIC_SWITCH_STATE="SWITCH_STATE"
DEFAULT_KAFKA_TOPIC_GW_STATS="GW_STATS"
DEFAULT_KAFKA_TOPIC_GW_STATE="GW_STATE"
DEFAULT_KAFKA_TOPIC_UNCLASSIFIED="UNCLASSIFIED"
# File or Redis key for loading default configurations
DEFAULT_USER_VARIABLES_FILE="user.yml"
DEFAULT_USER_VARIABLES_KEY="nd.config.rr.user-variables"
DEFAULT_USER_VARIABLES_API_ENDPOINT="rest-user-variables"

DEFAULT_USER_CODE_FILE="user.py"
DEFAULT_USER_CODE_KEY="nd.config.rr.user-code"
DEFAULT_USER_CODE_API_ENDPOINT="rest-user-code"

DEFAULT_TARGETS_FILE="targets.yml"
DEFAULT_TARGETS_KEY="nd.config.rr.targets"
DEFAULT_TARGETS_API_ENDPOINT="rest-targets"

# The following define the prefix and the complete filename/redis key/API end point
# The actual filename will be: <prefix>-<device_type>.yml. e.g. rcommands-central.yml
DEFAULT_RCOMMAND_PREFIX_FILE="rcommands"
# The actual filename will be: <prefix>-<device_type>.yml. e.g. rcommands-central.yml
DEFAULT_RCOMMAND_PREFIX_KEY="nd.config.rr.rcommands"
# The actual endpoit will be <prefix>/<device_type>, e.g. /rest-rcommands/central
DEFAULT_RCOMMAND_PREFIX_API_ENDPOINT="rest-rcommands"

DEFAULT_SIP_CONFIG_API_ENDPOINT="config-upload"
DEFAULT_SIP_DEVICE_MAPPING_ENDPOINT="device-mapping-for-collection"

DEFAULT_WEB_SERVER_PORT=9988

'''
#
'''
import argparse
import asyncio
import contextvars
import json
import logging
import logging.config
import os
import platform
import signal
import ssl
import sys
import time
import traceback
from aacommons.contentprovider.ContentProvider import ApiContentProvider, RedisStoreContentProvider, FileContentProvider
from restrecorder.core.Origin import Origin
from restrecorder.core.Sip import generateOriginFromSipConfig, getS3DetailsFromSipConfig
from restrecorder.Kafka import KafkaWriter, KafkaJSONWriter
from restrecorder.MiscHelper import loadContext, saveContext, loadTargets, loadRCommands
from restrecorder.RCommands import RCommandSchedule
from restrecorder.RestExecution import RestExecutionRunner
from restrecorder.RestProcessor import RestProcessor
from restrecorder.RestRecorder import RestRecorder, RestRecorderException
from restrecorder.ScheduledExecutorService import ScheduledExecutorService, TimeUnit
from restrecorder.ServiceExecution import ServiceExecutionRunner
from restrecorder.WebServer import startWebServer
from restrecorder.WsClientExecution import WsClientExecutionRunner

KAFKA_TOPIC = os.environ.get('KAFKA_TOPIC', DEFAULT_KAFKA_TOPIC)
KAFKA_TOPIC_AP_STATS = os.environ.get('KAFKA_TOPIC_AP_STATS', DEFAULT_KAFKA_TOPIC_AP_STATS)
KAFKA_TOPIC_AP_STATE = os.environ.get('KAFKA_TOPIC_AP_STATE', DEFAULT_KAFKA_TOPIC_AP_STATE)
KAFKA_TOPIC_SWITCH_STATS = os.environ.get('KAFKA_TOPIC_SWITCH_STATS', DEFAULT_KAFKA_TOPIC_SWITCH_STATS)
KAFKA_TOPIC_SWITCH_STATE = os.environ.get('KAFKA_TOPIC_SWITCH_STATE', DEFAULT_KAFKA_TOPIC_SWITCH_STATE)
KAFKA_TOPIC_GW_STATS = os.environ.get('KAFKA_TOPIC_GW_STATS', DEFAULT_KAFKA_TOPIC_GW_STATS)
KAFKA_TOPIC_GW_STATE = os.environ.get('KAFKA_TOPIC_GW_STATE', DEFAULT_KAFKA_TOPIC_GW_STATE)
KAFKA_TOPIC_UNCLASSIFIED = os.environ.get('KAFKA_TOPIC_UNCLASSIFIED', DEFAULT_KAFKA_TOPIC_UNCLASSIFIED)

# Logger
log = logging.getLogger(__name__)
# Flag for exiting
rr_exit = False
# Global state
rr_state = {}
# Global rr_context made available via contextvars
rr_context = RestRecorder(sys.stdout)
ctxvar_rr_context = contextvars.ContextVar("rr_context", default=None)
ctxvar_rr_context.set(rr_context)
# Map of logging levels by logger
rr_log_levels_by_logger = { }
rr_log_levels_toggle = None


def sigShutdown(signum, frame):
    # Try to save current context
    global rr_exit
    print("Ctrl-C received, saving context. Please be patient.", file=sys.stdout)
    rr_exit = True


def setLoggingLevels(level):
    for logger, elevel in rr_log_levels_by_logger.items():
        if level is None:
            # Factory default
            logger.setLevel(elevel)
        else:
            # Other
            logger.setLevel(level)
    global rr_log_levels_toggle
    rr_log_levels_toggle = level


def sigDebug(signum, frame):
    # Enable/disable logging
    global rr_log_levels_toggle
    if rr_log_levels_toggle is None:
        # At factory default, turn on DEBUG
        setLoggingLevels(logging.DEBUG)
    else:
        # At debug level, revert to factory default
        setLoggingLevels(None)


def sigTask(signum, frame):
    # Dump task list
    runningTasks = asyncio.all_tasks()
    print("---")
    print("%d tasks running" % (len(runningTasks)))
    for runningTask in runningTasks:
        print("  %s" % (runningTask))
    print("---")


def getAvailableProcessors():
    availableProcessors = os.cpu_count()
    print('Detected %d processors' % availableProcessors, file=rr_context.printStream)
    return availableProcessors


async def awaitTermination(scheduledExecutorService, oneShot=False):
    while True:
        try:
            terminated = await scheduledExecutorService.awaitTermination(1, TimeUnit.SECONDS)
            jobs = scheduledExecutorService.getActiveCount()
            log.debug("jobs [%d] [%s] tasks [%s]" % (jobs, terminated, len(rr_context.taskGetAll())))
            if jobs == 0:
                break
            if terminated:
                break
            if oneShot:
                break
        except Exception as e:
            log.debug("exception [%s]" % (e))
    return jobs


def prepareRCommands():
    # Prepare scheduling
    count_named = 0
    count_ws = 0
    count_service = 0
    count_begin = 0
    count_regular = 0
    count_end = 0
    restExecutions = []
    for rcommand in rr_context.rcommands.getRCommands():
        log.info("processing rcommand [%s]" % (rcommand))
        if rcommand.config["schedule"].interval == RCommandSchedule.SCHEDULE_NAME:
            # A named rcommand does not get scheduled
            count_named += 1
            log.info("processing named rcommand [%s]" % (rcommand))
            continue
        # By default: an RCommand is run against all targets (of same platform)
        defaultTargets = rr_context.targets.getTargetsByPlatform(rcommand.platform)
        if len(defaultTargets) == 0:
            log.debug("not scheduling rcommand since no default targets available")
            continue
        log.info("default targets [%s]" % (defaultTargets))
        if rcommand.config["schedule"].interval == RCommandSchedule.SCHEDULE_WS:
            # A websocket rcommand does get scheduled once and remains alive
            restExecution = WsClientExecutionRunner(rr_context.restProcessor, rcommand, defaultTargets)
            count_ws += 1
            log.info("processing websocket rcommand [%s]" % (rcommand))
        elif rcommand.config["schedule"].interval == RCommandSchedule.SCHEDULE_SERVICE:
            # A service rcommand does get scheduled once and remains alive
            restExecution = ServiceExecutionRunner(rr_context.restProcessor, rcommand, defaultTargets)
            count_service += 1
            log.info("processing service rcommand [%s]" % (rcommand))
        elif rcommand.config["schedule"].interval == RCommandSchedule.SCHEDULE_BEGIN:
            restExecution = RestExecutionRunner(rr_context.restProcessor, rcommand, defaultTargets)
            count_begin += 1
        elif rcommand.config["schedule"].interval == RCommandSchedule.SCHEDULE_END:
            restExecution = RestExecutionRunner(rr_context.restProcessor, rcommand, defaultTargets)
            count_end += 1
        else:
            restExecution = RestExecutionRunner(rr_context.restProcessor, rcommand, defaultTargets)
            count_regular += 1
        restExecutions.append(restExecution)
    print("Found %d begin, %d regular, %d end, %d named, %d websocket and %d service rcommands" % \
        (count_begin, count_regular, count_end, count_named, count_ws, count_service), file=rr_context.printStream)
    return restExecutions


async def scheduleRCommandsBegin(restExecutions):
    # Schedule begin
    print("Running begin rcommands...", file=rr_context.printStream)
    for restExecution in restExecutions:
        executionSchedule = restExecution.getExecutionSchedule()
        if executionSchedule.interval == RCommandSchedule.SCHEDULE_BEGIN:
            rr_context.scheduledExecutorService.schedule(
                restExecution, 0, TimeUnit.SECONDS)
    await awaitTermination(rr_context.scheduledExecutorService)


async def scheduleRCommands(restExecutions):
    # Schedule regular
    print("Running regular rcommands...", file=rr_context.printStream)
    for restExecution in restExecutions:
        executionSchedule = restExecution.getExecutionSchedule()
        if executionSchedule.interval == 0 or \
           executionSchedule.interval == RCommandSchedule.SCHEDULE_WS or \
           executionSchedule.interval == RCommandSchedule.SCHEDULE_SERVICE:
            # Run once
            rr_context.scheduledExecutorService.schedule(
                restExecution, 0, TimeUnit.SECONDS)
        elif executionSchedule.interval > 0:
            if executionSchedule.cycleInterval is not None and \
               executionSchedule.cycleInterval > 0:
                # Run cycle
                pass
#                    CycleWrapper cycleWrapper = new CycleWrapper(
#                            scheduledExecutorService, scheduledExecution);
#                    scheduledExecutorService.scheduleAtFixedRate(
#                            cycleWrapper,
#                            0,
#                            executionSchedule.getCycleInterval(), TimeUnit.SECONDS);
            else:
                # Run fixed rate
                rr_context.scheduledExecutorService.scheduleAtFixedRate(
                    restExecution, 0,
                    int(executionSchedule.interval * 1000.0), TimeUnit.MILLISECONDS)


async def scheduleRCommandsEnd(restExecutions):
    # Schedule end
    print("Running end rcommands...", file=rr_context.printStream)

    for restExecution in restExecutions:
        executionSchedule = restExecution.getExecutionSchedule()
        if executionSchedule.interval == RCommandSchedule.SCHEDULE_END:
            rr_context.scheduledExecutorService.schedule(
                restExecution, 0, TimeUnit.SECONDS)
    await awaitTermination(rr_context.scheduledExecutorService)


async def awaitExit(restExecutions):
    global rr_state, rr_exit
    print("All rcommands scheduled...", file=rr_context.printStream)
    animation = ['|', '/', '-', '\\']
    ai = 0
    queueSizeZero = 0
    while True:
        rr_context.printStream.write(animation[ai])
        rr_context.printStream.write('\b')
        rr_context.printStream.flush()
        ai += 1
        if ai >= len(animation):
            ai = 0
        await asyncio.sleep(1)
        if rr_exit is True:
            # Shutdown executor services
            log.debug("exiting (1): %f" % time.time())
            await rr_context.scheduledExecutorService.shutdownNow()
            rr_context.scheduledExecutorService = None
            # Cancel remaining tasks
            log.debug("exiting (2): %f" % time.time())
            await rr_context.taskCancelAll()
            log.debug("exiting (3): %f" % time.time())
            # Schedule end
            rr_context.scheduledExecutorService = ScheduledExecutorService()
            await scheduleRCommandsEnd(restExecutions)
            await rr_context.scheduledExecutorService.shutdownNow()
            rr_context.scheduledExecutorService = None
            # Cancel remaining tasks
            log.debug("exiting (4): %f" % time.time())
            await rr_context.taskCancelAll()
            log.debug("exiting (5): %f" % time.time())
            # Shutdown Kafka
            if rr_context.kafkaWriter is not None:
                await rr_context.kafkaWriter.getProducer().flush()
                await rr_context.kafkaWriter.getProducer().stop()
                log.debug("exiting (6): %f" % time.time())
            # Save context
            await saveContext(rr_state)
            break
        if await awaitTermination(rr_context.scheduledExecutorService, oneShot=True) == 0:
            queueSizeZero += 1
        if queueSizeZero > 10:
            rr_exit = True


async def _main():
    global rr_state
    try:
        # Load saved state from .rrstate
        _rr_state = loadContext()
        if _rr_state is not None:
            rr_state = _rr_state

        # Create executor service for scheduled rcommands
        rr_context.scheduledExecutorService = ScheduledExecutorService()
        log.info("scheduled executor service [%s]" % \
                 (rr_context.scheduledExecutorService))

        # Create global REST processor
        rr_context.restProcessor = RestProcessor()
        log.debug("restProcessor [%s]" % (rr_context.restProcessor))

        # Create global Kafka
        rr_context.kafkaWriter = None
        rr_context.kafkaJSONWriter = None
        if "kafka" in rr_context.cliOptions.log_store:
            customKafkaProps = dict()
            customKafkaProps["bootstrap_servers"] = "localhost:9092"
            # Enable producer compression: gzip, snappy, lz4
            customKafkaProps["compression_type"] = "gzip"
            if rr_context.cliOptions.kafka_properties is not None:
                # TODO: load kafka properies and add to dict()
                pass
            if rr_context.cliOptions.kafka_bootstrap_servers is not None:
                customKafkaProps["bootstrap_servers"] = \
                    rr_context.cliOptions.kafka_bootstrap_servers
            # Kafka security: default plaintext
            #security_protocol (str) – Protocol used to communicate with brokers. Valid values are: PLAINTEXT, SSL, SASL_PLAINTEXT, SASL_SSL. Default: PLAINTEXT.
            #ssl_context (ssl.SSLContext) – pre-configured SSLContext for wrapping socket connections.
            ksecurity = rr_context.cliOptions.kafka_security.lower()
            kssl_context = None
            if ksecurity == 'ssl':
                kssl_context = ssl.SSLContext()
                kssl_context.verify_mode = ssl.CERT_NONE
                kssl_context.check_hostname = False
            customKafkaProps["security_protocol"] = rr_context.cliOptions.kafka_security.upper()
            customKafkaProps["ssl_context"] = kssl_context
            kafkaWriter = KafkaWriter(customKafkaProps=customKafkaProps)
            if kafkaWriter is not None and kafkaWriter.getProducer() is not None:
                await kafkaWriter.getProducer().start()
                rr_context.kafkaWriter = kafkaWriter
                rr_context.kafkaJSONWriter = KafkaJSONWriter(kafkaWriter, rr_context.cliOptions.kafka_topic)
                '''
                rr_context.kafkaJSONWriterCentralStreaming = dict()
                if KAFKA_TOPIC_AP_STATS.lower() == 'drop':
                    rr_context.kafkaJSONWriterCentralStreaming['ap.stats'] = None
                else:
                    rr_context.kafkaJSONWriterCentralStreaming['ap.stats'] = KafkaJSONWriter(kafkaWriter, KAFKA_TOPIC_AP_STATS)
                if KAFKA_TOPIC_AP_STATE.lower() == 'drop':
                    rr_context.kafkaJSONWriterCentralStreaming['ap.state'] = None
                else:
                    rr_context.kafkaJSONWriterCentralStreaming['ap.state'] = KafkaJSONWriter(kafkaWriter, KAFKA_TOPIC_AP_STATE)
                if KAFKA_TOPIC_SWITCH_STATS.lower() == 'drop':
                    rr_context.kafkaJSONWriterCentralStreaming['switch.stats'] = None
                else:
                    rr_context.kafkaJSONWriterCentralStreaming['switch.stats'] = KafkaJSONWriter(kafkaWriter, KAFKA_TOPIC_SWITCH_STATS)
                if KAFKA_TOPIC_SWITCH_STATE.lower() == 'drop':
                    rr_context.kafkaJSONWriterCentralStreaming['switch.state'] = None
                else:
                    rr_context.kafkaJSONWriterCentralStreaming['switch.state'] = KafkaJSONWriter(kafkaWriter, KAFKA_TOPIC_SWITCH_STATE)
                if KAFKA_TOPIC_GW_STATS.lower() == 'drop':
                    rr_context.kafkaJSONWriterCentralStreaming['gw.stats'] = None
                else:
                    rr_context.kafkaJSONWriterCentralStreaming['gw.stats'] = KafkaJSONWriter(kafkaWriter, KAFKA_TOPIC_GW_STATS)
                if KAFKA_TOPIC_GW_STATE.lower() == 'drop':
                    rr_context.kafkaJSONWriterCentralStreaming['gw.state'] = None
                else:
                    rr_context.kafkaJSONWriterCentralStreaming['gw.state'] = KafkaJSONWriter(kafkaWriter, KAFKA_TOPIC_GW_STATE)
                rr_context.kafkaJSONWriterCentralStreaming['unclassified'] = KafkaJSONWriter(kafkaWriter, KAFKA_TOPIC_UNCLASSIFIED)
                '''

                await rr_context.kafkaJSONWriter.start()
                print("Kafka bootstrap servers %s. Topic is %s. Security is %s" % \
                      (customKafkaProps["bootstrap_servers"], rr_context.cliOptions.kafka_topic, ksecurity),
                      file=rr_context.printStream)
                '''
                for label, kwriter in rr_context.kafkaJSONWriterCentralStreaming.items():
                    if kwriter is not None:
                        await kwriter.start()
                        print("Kafka bootstrap servers %s. Topic is %s. Security is %s" % \
                              (customKafkaProps["bootstrap_servers"], kwriter._kafkaTopic, ksecurity),
                              file=rr_context.printStream)
                '''
            else:
                print("Kafka NOT available. Please check setup.",
                      file=rr_context.printStream)

        if rr_context.cliOptions.redisUrl:
            print("Configuration to be loaded from %s" % \
                  rr_context.cliOptions.redisUrl, file=rr_context.printStream)
        elif rr_context.cliOptions.apiUrl:
            print("Configuration to be loaded from %s" % \
                  rr_context.cliOptions.apiUrl, file=rr_context.printStream)
        else:
            print("Configuration to be loaded from files", \
                  file=rr_context.printStream)

        # Load user.yml
        rr_context.loadUserVariables()

        # Execute user.py
        rr_context.execUserCode()

        # Load targets
        await loadTargets(rr_state)

        # Load rcommands
        platforms = dict()
        for platform in rr_context.targets.getPlatforms():
            if rr_context.cliOptions.redisUrl is not None:
                # REDIS
                rcommands_key = rr_context.cliOptions.rcommands + "-" + platform
                platforms[platform] = RedisStoreContentProvider(rr_context.cliOptions.redisUrl, rcommands_key)
            else:
                # File
                rcommands_file = rr_context.cliOptions.rcommands + "-" + platform + ".yml"
                platforms[platform] = FileContentProvider(rcommands_file)
        loadRCommands(platforms)

        # Prepare RCommands
        restExecutions = prepareRCommands()

        # Open rcommands
        rr_context.rcommands.open()

        if rr_context.cliOptions.webServerPort > 0:
            await startWebServer(port=rr_context.cliOptions.webServerPort)

        # Schedule begin and regular
        await scheduleRCommandsBegin(restExecutions)
        await scheduleRCommands(restExecutions)

        # Wait for exit
        await awaitExit(restExecutions)

    except RestRecorderException as e:
        # TODO save context anyways?
        sys.exit(e.exitCode)


# TODO move to configuration or provide command line option for alternative configuration
LOGGING_CONFIG = {
    'version': 1,
    'disable_existing_loggers': True,
    'formatters': {
        'standard': {
            'format': '%(asctime)s <%(module)s> %(funcName)s | %(message)s'
        },
    },
    'handlers': {
        'console': {
            'level': 'WARNING',
            'formatter': 'standard',
            'class': 'logging.StreamHandler',
            'stream': 'ext://sys.stdout', # Default is stderr
        },
        'file': {
            'level': 'DEBUG',
            'formatter': 'standard',
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': os.getenv("RR_DEBUG_LOG", "rr_debug.log"),
            'maxBytes': 1024 * 1024 * 10, # 10MB
            'backupCount': 10
        }
    },
    'loggers': {
        '': { # root logger
            'handlers': ['console'],
            'level': 'WARNING',
            'propagate': False
        },
        'restrecorder': {
            'handlers': ['console','file'],
            'level': 'INFO',
            'propagate': False
        },
        '__main__': {
            'handlers': ['console','file'],
            'level': 'INFO',
            'propagate': False
        },
    }
}
logging.config.dictConfig(LOGGING_CONFIG)
print(HEADLINE, file=rr_context.printStream)
if __name__ == '__main__':
    parser = argparse.ArgumentParser(prog='RestRecorder', description=DESCRIPTION)
    # Keep ordered
    parser.add_argument("--api-config-endpoint", dest="apiConfigEndpoint",
                        help="Endpoint for retrieving SIP base configuration",
                        default=DEFAULT_SIP_CONFIG_API_ENDPOINT)
    parser.add_argument("--api-device-mapping-endpoint", dest="apiDeviceMappingEndpoint",
                        help="Endpoint for retrieving SIP device mapping",
                        default=DEFAULT_SIP_DEVICE_MAPPING_ENDPOINT)
    parser.add_argument("--api-url", dest="apiUrl",
                        help="read configuration from config api",
                        default=None)
    parser.add_argument("-d", "--debug",
                        action='store_true',
                        default=False,
                        help="enable debugging")
    parser.add_argument("--kafka-bootstrap-servers",
                        default=None,
                        help="kafka bootstrap servers (default: localhost:9092)")
    parser.add_argument("--kafka-properties",
                        default=None,
                        help="kafka custom properties")
    parser.add_argument("--kafka-security",
                        default="plaintext",
                        choices=['plaintext', 'ssl'],
                        help="kafka security (default: plaintext)")
    parser.add_argument("--kafka-topic",
                        default=KAFKA_TOPIC,
                        help=f"kafka topic to write. Current default: {KAFKA_TOPIC}")
    parser.add_argument("--label",
                        default="default/default",
                        help="label")
    parser.add_argument("--log-store",
                        default="file",
                        help="log store (file and/or kafka)")
    parser.add_argument("--origin",
                        default=None,
                        help="origin")
    parser.add_argument("--pretty-print",
                        action='store_true',
                        default=False,
                        help="pretty print")
    parser.add_argument("-r", "--rcommands",
                        default=None,
                        help="rcommands prefix")
    parser.add_argument("--redis-url", dest="redisUrl", default=None,
                        help="read configuration from redis. default: None, i.e. read from file")
    parser.add_argument("--rrstate",
                        default=RRSTATE_FILENAME,
                        help=".rrstate.json file")
    parser.add_argument("-t", "--targets",
                        default=None,
                        help="targets file")
    parser.add_argument("--user-code",
                        default=None,
                        help="user code file")
    parser.add_argument("--user-log",
                        default=None,
                        help="user log file")
    parser.add_argument("--user-variables",
                        default=None,
                        help="user variables file")
    parser.add_argument("--web-server-port", dest="webServerPort", type=int,
                      help=f"listening port of management server. Default: {DEFAULT_WEB_SERVER_PORT}. Set to 0 to disable",
                      default=DEFAULT_WEB_SERVER_PORT)

    rr_context.cliOptions = parser.parse_args()

    # If args.apiUrl is set, that mean we are interacting with the SIP system
    # Load SIP specific configurations
    if rr_context.cliOptions.apiUrl:
        sipContentProvider = ApiContentProvider(rr_context.cliOptions.apiUrl, rr_context.cliOptions.apiConfigEndpoint)
        print("Loading SIP configuration from API Server: %s" % (sipContentProvider), file=rr_context.printStream)
        sipConfig = sipContentProvider.getContent()
        sipDeviceMappingProvider = ApiContentProvider(rr_context.cliOptions.apiUrl, rr_context.cliOptions.apiDeviceMappingEndpoint)
        sipDeviceMapping = sipDeviceMappingProvider.getContent()

    if rr_context.cliOptions.origin:
        # value specified on CLI takes precedence
        rr_context.origin = Origin(rr_context.cliOptions.origin)
    elif rr_context.cliOptions.apiUrl:
        rr_context.origin = Origin(generateOriginFromSipConfig(json.loads(sipDeviceMapping)))
        rr_context.s3details = getS3DetailsFromSipConfig(json.loads(sipConfig))
        print("S3 Details: {}".format(rr_context.s3details), file=rr_context.printStream)
        print("Derived Origin: {}".format(rr_context.origin), file=rr_context.printStream)

    # set default options depending on whether config is read from file, redis or api server
    if rr_context.cliOptions.redisUrl is not None:
        # REDIS
        if rr_context.cliOptions.user_variables is None:
            rr_context.cliOptions.user_variables = \
                RedisStoreContentProvider(rr_context.cliOptions.redisUrl, DEFAULT_USER_VARIABLES_KEY)
        else:
            rr_context.cliOptions.user_variables = \
                RedisStoreContentProvider(rr_context.cliOptions.redisUrl, rr_context.cliOptions.user_variables)
        if rr_context.cliOptions.user_code is None:
            rr_context.cliOptions.user_code = \
                RedisStoreContentProvider(rr_context.cliOptions.redisUrl, DEFAULT_USER_CODE_KEY)
        else:
            rr_context.cliOptions.user_code = \
                RedisStoreContentProvider(rr_context.cliOptions.redisUrl, rr_context.cliOptions.user_code)
        if rr_context.cliOptions.targets is None:
            rr_context.cliOptions.targets = \
                RedisStoreContentProvider(rr_context.cliOptions.redisUrl, DEFAULT_TARGETS_KEY)
        else:
            rr_context.cliOptions.targets = \
                RedisStoreContentProvider(rr_context.cliOptions.redisUrl, rr_context.cliOptions.targets)
        if rr_context.cliOptions.rcommands is None:
            rr_context.cliOptions.rcommands = DEFAULT_RCOMMAND_PREFIX_KEY
    else:
        # FILES
        if rr_context.cliOptions.user_variables is None:
            rr_context.cliOptions.user_variables = FileContentProvider(DEFAULT_USER_VARIABLES_FILE)
        else:
            rr_context.cliOptions.user_variables = FileContentProvider(rr_context.cliOptions.user_variables)
        if rr_context.cliOptions.user_code is None:
            rr_context.cliOptions.user_code = FileContentProvider(DEFAULT_USER_CODE_FILE)
        else:
            rr_context.cliOptions.user_code = FileContentProvider(rr_context.cliOptions.user_code)
        if rr_context.cliOptions.targets is None:
            rr_context.cliOptions.targets = FileContentProvider(DEFAULT_TARGETS_FILE)
        else:
            rr_context.cliOptions.targets = FileContentProvider(rr_context.cliOptions.targets)
        if rr_context.cliOptions.rcommands is None:
            rr_context.cliOptions.rcommands = DEFAULT_RCOMMAND_PREFIX_FILE

    # Record current log levels
    for name, _ in logging.root.manager.loggerDict.items():
        if name.startswith('restrecorder'):
            logger = logging.getLogger(name)
            rr_log_levels_by_logger[logger] = logger.getEffectiveLevel()

    # Set debug levels
    if rr_context.cliOptions.debug:
        # TODO: allow for individual setting
        setLoggingLevels(logging.DEBUG)

    # Setup user-log
    if rr_context.cliOptions.user_log:
        print("User log in %s" % (rr_context.cliOptions.user_log), file=rr_context.printStream)
        rr_context.userLog = open(rr_context.cliOptions.user_log, 'a+')

    # Catch Ctrl-C
    signal.signal(signal.SIGINT, sigShutdown)

    # Catch USR1: toggle debug on/off
    if not 'Windows' in platform.platform():
        signal.signal(signal.SIGUSR1, sigDebug)

    # Catch USR2: dump task list
    if not 'Windows' in platform.platform():
        signal.signal(signal.SIGUSR2, sigTask)

    try:
        asyncio.run(_main())
    except Exception as e:
        traceback.print_exc()

    # Exit
    print("Exiting", file=rr_context.printStream)
    os._exit(0)
