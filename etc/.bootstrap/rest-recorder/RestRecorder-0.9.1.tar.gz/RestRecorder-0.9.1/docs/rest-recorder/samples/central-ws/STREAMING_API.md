# Notes on Aruba Central Streaming API

## Resources

Description of the Aruba Central Streaming API can be found at the following link.

- https://developer.arubanetworks.com/aruba-central/docs/getting-started-with-streaming-api

## Getting access to Streaming API

Streaming API must be enabled/white-listed for a particular Customer ID.  Please contact PLM.

## Topics

The following is a list of topics available from the ACP streaming API.

### apprf

This topic is for application visibility (apprf). Deep packet inspection must be enabled for the
IAP group.

- (Maintain -> Organization)
- select Group, press 'config'
- click 'Show Advanced'
- Services -> AppRF(tm) -> All

### audit

Sent when configuration is synced from ACP to swarm (IAP VC).

### location

Client location service.  To get this topic, IAP's must be placed in VisualRF.  Even placing 1 AP
is enough to get a reading, although not very accurate.

### monitoring

This is the most basic topic.  Will get states and stats about APs and gateways

### presence

Should be available for all.

### security

These are events for RAPIDS (IDS/IPS).  This feature (IDS/IPS) must be whitelisted by TAC.

## Additional implementation notes

### monitoring

1.  Telemetry for monitoring devices are part of the ‘monitoring’ streaming API topic.
2.  KPI related to licensing are not available from the streaming API.  Recommend using the Rest API
3.  There is no ‘Client Health’ attribute.  However, this can easily be implied using ‘snr’, ‘speed’, Tx/Rx Througput. ‘signalInDb’
3.  There are two main types of messages ‘STATE_XXXXX’ and ‘STAT_XXXX’.
4.  Each streaming API message can contain one of more ‘STATE’ or ‘STAT’ messages (e.g. STAT_VAP, STAT_CLIENT, STAT_DEVICE).  However, ‘STATE’ and ‘STAT’ messages will not be mixed together in the same message.
5.  STATE_XXXX messages are only sent whenever there is a change (Add, Update, Delete) in the state of any component (AP up/down, Link up/down, client add/delete, etc). The latency seems to be within ‘seconds’.
6.  STAT_XXXX messages are sent every 5minutes for all devices/clients monitored.
7.  Unless there is any change in the network (reboot, add, configuration change etc), we won’t get information about a network component.  Recommend periodically use the REST API to refresh/initialize the our state DB about each component.
