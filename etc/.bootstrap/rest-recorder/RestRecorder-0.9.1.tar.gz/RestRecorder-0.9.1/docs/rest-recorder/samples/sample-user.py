#
# Global code that is loaded on startup.
# Can be directly referenced in rcommands-<platform>.yml.
#
def MyUrlSequencer():
    return [1, 2]
