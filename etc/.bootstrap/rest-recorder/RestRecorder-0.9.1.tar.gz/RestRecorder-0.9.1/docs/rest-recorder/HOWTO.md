# RestRecorder (0.9.1)
A Python3 (3.8 or higher) based tool that will run arbitrary REST calls against selected targets.

## 1. SUPPORTED PLATFORMS
RestRecorder supports following target platforms:
- ArubaOS 8 [use platform name aos8]
- Aruba Central [use platform name central or central-ws]
- ArubaOS Switch [use platform name asw]
- ArubaOS-CX [use platform name acx]
- Clearpass [use platform cppm]
- Service for ALE (IAP) [use platform service-ale-iap]
- Service for Aruba Central Webhook [use platform service-central-webhook]


## 2. INSTALLATION
Unpack the RestRecorder distribution TAR.GZ/ZIP file to a directory or folder of choice.

Create a python3 virtual environment: python3 -m venv venv
Activate virtual environment: source venv/bin/activate (Linux)
Install dependencies: pip install -r requirements.txt
Run RestRecorder: python3 Main.py

Please note that "samples" is a folder that contains sample files organized by platform.


## 3. OVERVIEW AND CONCEPTS
A platform identifies a class of targets and is called out by a platform name such as "aos8", "central", etc...

A target is the recipient of REST calls. A target is of a given platform.

An rcommand describes a REST command. An rcommand will ultimately result in one or more REST calls against one or more targets.
Essentially, an rcommand represents a scheduled unit of work that will perform following steps (in order):
- execute input pipeline ("ipipe") if any [once per schedule]
- compute the targets the rcommand will work with [once per schedule]
- for each target
  - execute the REST call(s) [per target]
  - execute output pipeline ("opipe") if any [per target]

An rcommand can be either scheduled, named, web-socket or service:
- scheduled rcommands are executed at fixed intervals or at the beginning or at the end.
- named rcommands are executed when the action "rcommand" triggers them.
- web-socket and service rcommands are executed as background tasks.

All configuration files are written in YAML language. Please refer to <http://yaml.org/spec/1.2/spec.html> for reference.


## 4. COMMAND-LINE OPTIONS AND ARGUMENTS

### 4.1 FILES
- targets.yml: lists all targets. Use option "-t" to use an alternate name (default targets.yml).
- rcommands-<platform>.yml: lists rcommands for the specified platform, i.e. rcommands-aos8.yml defines the list of rcommands to run against AOS8 targets. Use the option "-r" to use an alternative prefix (default rcommands).
- user.yml: optional data file for defining global values. Values defined here are available in the global scope. Use the option "--user-variables" to use an alternative file (Default: user.yml).
- user.py: optional Python code file. Code fragments defined here are available in the global scope. Use the option "--user-code" to use an alternative file (Default: user.py).

### 4.2 REDIS KEYS
The above configuration files can also be loaded from *redis* by specifying the
  --redis-url REDISURL
command line option. When that option is specified, the configurations will be loaded from the following redis keys:
- nd.config.rr.targets: Use option "-t" to use an alternate key.
- nd.config.rr.rcommands-<platform>: (e.g. nd.conf.rr.rcommands-aos8). Use the option "-r" to use and alternative prefix (e.g -r nd.config.rr.test will translate to nd.config.rr.test-aos, etc).
- nd.config.rr.user-variables: Optional key for defining global values. Override with --user-variables
- nd.config.rr.user-code: Optional key for defining optional user code. Override with --user-code


## 5. TARGETS
The file *targets.yml* defines the list of targets.

All targets understand following keywords:

For 'boolean' keywords, use 'yes', 'y', 't', 1 for affirmative value or 'no', 'y', 'f', 0 for negative value.

```yaml
  platform: <platform type>       # MANDATORY
  disable: yes | no               # OPTIONAL, Default: no
  critical: yes | no              # OPTIONAL, Default: no
  throttle: yes | no              # OPTIONAL, Default: yes for 'central' platform, no for everything else.
  rate_limit: <int>               # OPTIONAL, Per-second rate-limit. Default: 7 (per s)
  retries: <int>                  # OPTIONAL, Default: 10
  rate_limit_exceeded_codes:      # OPTIONAL, Default: [423, 503]
```
The keyword "platform" identifies the target platform.

The "disable" keyword can be used to disable the configured target without removing it from the configuration file. Any
disabled target is ignored.

When a target is marked "critical", if any error (connectivity, authentication) is encountered during the set-up
phase, the entire RestRecorder process is terminated. If a target is not marked 'critical', if error is encountered
during the set-up phase, that target will be ignored and processing for other targets (if any) will continue.
This keyword has no effect after the set-up phase of the process.

The "throttle" enables the rate-limit/retry mechnism.  Used in conjunction with the "rate_limit", "retries"
and "rate_limit_exceeded_codes" keywords. For example,
with the following parameters:
```yaml
  throttle: yes
  rate_limit: 7
  retries: 10
  rate_limit_exceeded_codes:
    - 423
    - 503
```
RestRecorder will aim to issue REST API calls at an average rate of 5 per second. When the returned HTTP status_code
is one of the codes in the list "rate_limit_exceed_codes", RR will wait (on average) 0.14s (1/7) before retrying
the same call. This will be retried up to 10 times.

Please note that at the moment, only the "central" platform enables rate-limit at 7 calls per-second, with
an HTTP status_code of 423 to indicates that rate-limit is exceeded.
Therefore, the rate-limit mechnism is only enabled for the "central" target type and disabled for all others.


### 5.1 AOS8 TARGETS
The platform *aos8* identifies ArubaOS 8 systems.

YAML fragment:
```yaml
- # AOS8
  platform: aos8                  # MANDATORY
  name: <name>                    # OPTIONAL, default <URL> host part
  auth: basic                     # OPTIONAL, default basic
  username: <username>            # MANDATORY
  password: <password>            # MANDATORY
  url: <URL>                      # MANDATORY
  refresh: <interval>             # OPTIONAL, default 15m
  timeout: <timeout>              # OPTIONAL, default 60s
```

Sample AOS8 YAML fragment:
```yaml
- # AOS8
  platform: aos8
  username: admin
  password: admin1
  url: "https://192.168.12.201:4343"
```


### 5.2 CENTRAL TARGETS
The platform *central* identifies Aruba Central. Central targets support two authentication methods: oauth2 with username/password and oauth2_token with downloaded central token.

#### 5.2.1 OAUTH2 AUTHENTICATION
Please note that HPE SSO credential do not work for central username and password authentication.

YAML fragment:
```yaml
- # Central
  platform: central                   # MANDATORY
  name: <name>                        # OPTIONAL, default <URL> host part
  auth: oauth2                        # OPTIONAL, default oauth2 if username is specified
  username: <username>                # MANDATORY, username for central
  password: <password>                # MANDATORY, password for central
  client_id: <client_id>              # MANDATORY, client ID from central APP
  client_secret: <client_secret>      # MANDATORY, client secret from central APP
  customerid: <customerid>            # OPTIONAL, customerid from central APP
  url: <URL>                          # MANDATORY
```

Sample Central YAML fragment:
```yaml
- # Internal Central
  platform: central
  username: "username"
  password: "password"
  client_id: "myclientid"
  client_secret: "myclientsecret"
  customer_id: "customerid"
  url: "https://eu-apigw.central.arubanetworks.com"
```

#### 5.2.2 OAUTH2_TOKEN AUTHENTICATION
Step by step instructions to obtain a valid token.json file from Central:

- Login into Central.
- On the Account Home page, under Global Settings, click API gateway.
- On the TAB System Apps & Tokens, click on "Add Apps & Tokens" (right top corner).
- Choose an application name (such as "RR"), hit "Generate".
- Once the token is created it should appear in the list, click on the link "Download Token".
- Copy the JSON content as-is into a file called "token.json" and put that file in the same directory where you run RestRecorder.
- Note the CLIENT ID and CLIENT SECRET values of the newly generated APP. They will be needed for the YAML client_id and client_secret keys.

With the *token.json* file, RestRecorder is able to talk to Central and it will automatically renew the token as needed.

YAML fragment:
```yaml
- # Central
  platform: central                   # MANDATORY
  name: <name>                        # OPTIONAL, default <URL> host part
  auth: oauth2_token                  # OPTIONAL, default oauth2_token if username is not specified
  token: <token.json>                 # OPTIONAL, file that holds authentication token from central, default token.json
  client_id: <client_id>              # MANDATORY, client ID from central APP
  client_secret: <client_secret>      # MANDATORY, client secret from central APP
  url: <URL>                          # MANDATORY
```

Sample Central YAML fragment:
```yaml
- # Internal Central
  platform: central
  client_id: "myclientid"
  client_secret: "myclientsecret"
  url: "https://eu-apigw.central.arubanetworks.com"
```

### 5.3 ASW TARGETS
The platform *asw* identifies ArubaOS switches (formerly HP Procurve).

YAML fragment:
```yaml
- # ASW
  platform: asw           # MANDATORY
  name: <name>            # OPTIONAL, default <URL> host part
  auth: basic             # OPTIONAL, default basic
  username: <username>    # MANDATORY
  password: <password>    # MANDATORY
  url: <URL>              # MANDATORY
  refresh: <interval>     # OPTIONAL, default 10m
  timeout: <timeout>      # OPTIONAL, default 60s
```

Sample ASW YAML fragment:
```yaml
- # ASW
  platform: asw
  username: manager
  password: admin1
  url: "http://10.1.1.246/rest/v3"
```

NOTE: URL includes the */rest/v<version>* part since the Aruba Switch offers multiple versions.

Hence URL specified in *rcommands-asw.yml* file should be relative, i.e. /acls or /ports
NOTE: the CLI command "show session-list" will show currently active sessions.

### 5.4 ACX TARGETS
The platform *acx* identifies ArubaOS-CX switches.

YAML fragment:
```yaml
- # ACX
  platform: acx           # MANDATORY
  name: <name>            # OPTIONAL, default <URL> host part
  auth: basic             # OPTIONAL, default basic
  username: <username>    # MANDATORY
  password: <password>    # MANDATORY
  url: <URL>              # MANDATORY
  refresh: <interval>     # OPTIONAL, default 20m
  timeout: <timeout>      # OPTIONAL, default 60s
```

Sample ACX YAML fragment:
```yaml
- # ACX
  platform: acx
  username: admin
  password: admin1
  url: "https://10.136.40.239/rest/v1"
```

NOTE: URL includes the */rest/v<version>* part since the ArubaOS-CX Switch offers multiple versions.

Hence URL specified in *rcommands-acx.yml* file should be relative, i.e. /system/interfaces
NOTE: the switch sessions limit is set to 5 simultaneous sessions, and it can’t be changed. Use the command:
"https-server session close all" to clear active sessions.

### 5.5 CPPM TARGETS
The platform *cppm* identifies Clearpass systems.

CPPM targets support three authentication methods:

1. grant_type = client_credentials
   required parameters: client_id, client_secret
2. grant_type = password
   required parameters: client_id, client_secret, username, password
3. grant_type = password (Public Client)
   required parameters: client_id, username, password

API Clients can be configured in ClearPass Guest -> Administration -> API Services -> API Clients

#### 5.5.1 GRANT_TYPE CLIENT_CREDENTIALS

YAML fragment:
```yaml
-
  platform: cppm                    # MANDATORY
  name: <name>                      # OPTIONAL, default <URL> host part
  grant_type: client_credentials    # OPTIONAL, default to client_credentials if no username present, password otherwise
  client_id: <client_id>            # MANDATORY, client ID from ClearPass Guest API configuration
  client_secret: <client_secret>    # MANDATORY, client secret from ClearPass Guest
  url: <URL>                        # MANDATORY, "https://clearpass_fqdn" or "https://ip_address"
```

Sample CPPM YAML fragment:
```yaml
- # CPPM
  platform: cppm
  client_id: "myclientid"
  client_secret: "myclientsecret"
  url: "https://192.168.0.178"
```

#### 5.5.2 GRANT_TYPE PASSWORD AUTHENTICATION

YAML fragment:
```yaml
-
  platform: cppm                    # MANDATORY
  name: <name>                      # OPTIONAL, default <URL> host part
  grant_type: password              # OPTIONAL, default to client_credentials if no username present, password otherwise
  username: <username>              # MANDATORY, username
  password: <password>              # MANDATORY, password
  client_id: <client_id>            # MANDATORY, client ID from ClearPass Guest API configuration
  client_secret: <client_secret>    # OPTIONAL, if API client is configured as public client, client_secret can be omitted
  url: <URL>                        # MANDATORY, "https://clearpass_fqdn" or "https://ip_address"
```

Sample CPPM YAML fragment:
```yaml
- # CPPM
  platform: cppm
  username: "myusername"
  password: "mypassword"
  client_id: "myclientid"
  client_secret: "myclientsecret"
  url: "https://192.168.0.178"
```

### 5.6 CENTRAL-WS TARGETS
The platform *central-ws* identifies Aruba Central using web-socket as protocol.

YAML fragment:
```yaml
- # Central
  platform: central-ws                # MANDATORY
  name: <name>                        # OPTIONAL, default <URL> host part
  username: <username>                # MANDATORY, username from central APP
  key: <web-socket key>               # MANDATORY, web-socket key from central APP
  url: <URL>                          # MANDATORY
  aggressive_restart: <count>         # OPTIONAL, default 0
  timeout: <timeout>                  # OPTIONAL, default 60s
```
With *aggressive_restart* > 0, when nothing is received in a websocket (for each topic) for more than *aggressive_restart* multiplied by *timeout* seconds,
the websocket will be closed and re-opened.

Sample Central YAML fragment:
```yaml
- # Central
  platform: central-ws
  url: "wss://internal-ui.central.arubanetworks.com"
  username: "username@email"
  key: "<your key here>"
  ```


### 5.7 SERVICE-ALE-IAP TARGETS
The platform *service-ale-iap* identifies the ALE service for IAP.

YAML fragment:
```yaml
# - # ALE service
#   platform: service-ale-iap # MANDATORY
#   name: <name>              # MANDATORY
#   port: <port>              # MANDATORY, port number (1-65535) service listens
#   certificate_file: <path>  # OPTIONAL, [SSL] specify path to certificate file (PEM encoded)
#   certificate_key: <path>   # OPTIONAL, [SSL] specify path to certificate key file (PEM encoded)
```

Sample service-ale-iap YAML fragment:
```yaml
- # ALE service
  platform: service-ale-iap
  name: iap-ale
  port: 443
  certificate_file: cert.pem
  certificate_key: cert.pkey
```


### 5.8 SERVICE-CENTRAL-WEBHOOK TARGETS
The platform *service-central-webhook* identifies the Aruba Central Webhook service.

YAML fragment:
```yaml
# - # Aruba Central Webhook service
#   platform: service-central-webhook # MANDATORY
#   name: <name>                      # MANDATORY
#   port: <port>                      # MANDATORY, port number (1-65535) service listens
#   certificate_file: <path>          # OPTIONAL, [SSL] specify path to certificate file (PEM encoded)
#   certificate_key: <path>           # OPTIONAL, [SSL] specify path to certificate key file (PEM encoded)
```

Sample service-ale-iap YAML fragment:
```yaml
- # Aruba Central Webhook service
  platform: service-central-webhook
  name: central-webhook
  port: 443
  certificate_file: cert.pem
  certificate_key: cert.pkey
```


## 6. RCOMMANDS
The file *rcommands-<platform>.yml* defines the list of rcommands to run against the designated platform.

Use the rcommand *schedule* parameter to select its behavior.

1. schedule: time-based or begin or end. Scheduled rcommands are executed at fixed intervals or at the beginning or at the end.
2. schedule: name:... Named rcommands are executed when the action "rcommand" triggers them. They act like named tasks that can be called from other rcommands. Named rcommands always return an *array* of results, whether they have been run against a single target or multiple targets (i.e. self.rr_adata is an array on return of action "rcommand").
3. schedule: ws:client. Web-socket client rcommands are background tasks that are started after all "begin" rcommands have been run. At least one task exists per target. If the rcommand calls out multiple web-socket client requests, additional tasks are created, such as each web-socket client request is run in its own task.

YAML fragment:
```yaml
- # rcommand
  schedule: <schedule>[s|m|h|d] | begin | end | name:<name> | ws:client      # MANDATORY
  request: [<variable>] <method> <URL>                                       # MANDATORY
  headers: <static dictionary>                                               # OPTIONAL
  eheaders: <eval dictionary>                                                # OPTIONAL
  params: <static dictionary>                                                # OPTIONAL
  eparams: <eval dictionary>                                                 # OPTIONAL
  body: <static json> | string                                               # OPTIONAL
  ebody: <eval dictionary> | <eval expression>                               # OPTIONAL
  ipipe: # input actions, multiple actions are run in sequence               # OPTIONAL
    - action: <action>
    - ...
  opipe: # output actions, multiple actions are run in sequence              # OPTIONAL
    - action: <action>
    - ...
  targets: <eval expression>                                                 # OPTIONAL
  page: <static dictionary>                                                  # OPTIONAL
```

Sample RCOMMAND YAML fragment:
```yaml
- # entry 1
  schedule: 10m
  request: GET /monitoring/v1/clients/count
- # entry 2
  schedule: 5m
  request: GET /monitoring/v1/swarms
  ipipe:
    - action: setvar
      name: SWARM
      mode: set
      value: "[]"
  opipe:
    - action: jfilter
      jfilter: $."swarms"[?(`this`."name" = "myname")]
    - action: print
    - action: setvar
      name: SWARM
      value: "[n['name'] for n in self.rr_adata]"
    - action: eval
      eval: "SWARM"
    - action: print
```

### 6.1 schedule
- <schedule>[s|m|h|d]: runs the rcommand every <schedule> (s=seconds, m=minutes, h=hours, d=days, default seconds) <schedule> is an integer or real value. Sub-second schedules can be specified using real values (i.e. use 0.5 for a schedule of 500 milliseconds).
- begin: runs the rcommand at the very beginning before any scheduled rcommands.
- end: runs the rcommand at the very end after any scheduled rcommands.
- name:<name>: defines a named rcommand. The rcommand is executed by the action "rcommand".
- ws:client: defines a web-socket client.
- service-*: defines a service such as service-ale-iap.

### 6.2 request
There are two use cases addressed:
- <method> <URL>: runs the REST <method> against a single URL <URL>
- <variable> <method> <dynamic URL>: runs the REST <method> against a list of dynamic URLs. Where:
  - <method> is a valid HTTP method, such as GET, PUT, etc... A special method name NULL will always succeed and produce no actual REST invocation. The NULL method can be used to iterate over list of values.
  - <URL> is a static URL, such as /monitoring/v1/swarms.
  - <variable> is the name of the python local variable that can be referenced in any of the actions and expressions. The variable is a dictionary with following keys:
    - "#": holds the current URL entry number in the processed URL list. Starts at 0.
    - "url": holds the current URL being processed.
  - <dynamic URL> is a python eval() expression that MUST generates an array of URLs. For example the expression:
    - ['/v1/configuration/showcommand' + str(x) for x in (1, 2)] will generate an array of two URLs ["/v1/configuration/showcommand1", "/v1/configuration/showcommand2"].
    - ["/URL" for x in self.APDB if x["Name"] in self.CSVLIST] will generate an array of URLs based on the contents of local variables APDB and CSVLIST.

### 6.3 headers and eheaders
- headers: is a static dictionary, such as { "header1": "value1", "header2": "value2" }.
- eheaders: is a dictionary where the values are python eval() expression, such as { "header1": "2 + 3", "header2": "X" }.

Note: a REST call will send the combined headers and eheaders.

### 6.4 params and eparams
- params: is a static dictionary, such as { "param1": "value1", "param2": "value2" }.
Note: multi-valued query parameters can be specified as lists such as { "param1": "value1", "param2": "value2", "param3": [1, 2, 3] }.
- eparams: is a dictionary where the values are python eval() expression, such as { "param1": "2 + 3", "param2": "X" }.

Note: a REST call will send the combined params and eparams.

### 6.5 body and ebody
- body: is either a statically defined valid JSON or a string. In the case of JSON the textual representation is sent.
- ebody: is either a dictionary where the values are python eval() expression or a simple python eval() expression. In the case of the dictionary, all values are evaluated and the result sent out in text form. The simple python eval() expression is evaluated and its results send out in text form.

Note: a REST call will send the combined body and ebody.

### 6.6 ipipe
- sequence of actions

### 6.7 opipe
- sequence of actions

### 6.8 targets
targets keyword is an optional field.
- When it is not specified
  - named rcommands will execute against all targets of the platform if called from an input pipeline ("ipipe"), otherwise execute against the target currently being processing from an output pipeline ("opipe").
  - other rcommands will execute against all targets of the platform.
- When targets is specified, it MUST be a valid Python expression, that will be evaluated after the input pipeline has been run. The targets expression MUST evaluate to following values:
  - None: the rcommand will execute against all targets of the platform
  - array of dictionaries: the rcommand will execute against the listed targets. The dictionary understands following keys:
    - "name": <target name>
    - "url": <target URL>
    - "clone": <target name of target to be cloned>

Two use cases are implemented:
1) reference an existing target by name. Use { "name": <name of target as defined in targets.yml> }
2) clone an existing target by name and rewrite selected parameters: { "clone": <name of target to clone>, "url": <new URL to use> }

### 6.9 page
page: is a static dictionary. When page is specified, it will execute the REST request in paged mode. Following keys are supported:
- offset: [OPTIONAL] this is the "offset" parameter used when paging (default "offset").
- limit: [OPTIONAL] this is the "limit" parameter used when paging (default "limit").
- size: [OPTIONAL] this is the page size used when paging (default 20).
- begin: [OPTIONAL] an eval expression that MUST return a dictionary of all parameters needed to start paging
         For example: '{ "offset": 0, "limit": 2 }' would start paging with an offset of 0 and a limit of 2.
- next: [OPTIONAL] an eval expression that MUST return a dictionary of the parameters needed for the next page
        For example: '{ "offset": self.rr_page["offset"] + 2, "limit": 2 }' would continue paging by incrementing
        offset by 2 and keeping the limit at 2.
- end: [OPTIONAL] an eval expression that MUST return a boolean to stop (TRUE) or continue (FALSE) paging
       (default 'self.rr_page["_rr_pdata"].get("count", 0) == 0')

Notes:
- the simplest form to indicate paging is: "page: {}" which would page with a size of 20.
- using a different page size is specified by: "page: { 'size': 10 }" which would page with a size of 10.
- end eval expression has access to the current REST output using the 'self.rr_page["_rr_pdata"]' value.
- self.rr_page is a dictionary that holds current paging parameters. Keys not starting with _rr are used as parameters
  for the REST call.


## 7. ACTIONS
An action is a processing step in a pipeline: <action1> <action2> ... <action N>
The output of an action is handed as input to the next action.
The first action in the *input* pipeline starts with:
- NO data for scheduled and web-socket rcommands.
- current action data for triggered rcommands.
The first action in the *output* pipeline starts with the output data of the REST call.

Following local variables are available to the action currently executing:
- self.rr_adata is the action data available.
- self.rr_result is the RestResult object of the last REST call.
- self.rr_self is a generator that produces the value self continuously. This is useful in the context of a list comprehension such as:
  - [{ "name": md["IP Address"], "url": "https://" + md["IP Address"] + ":4343", "clone": _self.rr_tname } for md, _self in zip(self.rr_adata, self.rr_self)]
- self.rr_tname is the current target name.

### 7.1 ale-iap-decoder
The action decodes an ALE feed from IAP.

YAML fragment:
```yaml
- action: ale-iap-decoder
```

### 7.2 central-streaming-decoder
The action decodes a Central streaming feed.

YAML fragment:
```yaml
- action: central-streaming-decoder
```

### 7.3 csv-read
The action reads a CSV file. The output is the content of the CSV file either as
an array of dictionaries (each entry a column/value pair) or as a dictionary of
dictionaries, with the key being the column name acting as a lookup index.
Note: the entire CSV file is loaded in memory.

YAML fragment:
```yaml
- action: csv-read
  path: <path>                  # MANDATORY path to CSV file
  delimiter: ","                # OPTIONAL, default is ","
  quotechar: '"'                # OPTIONAL, default is '"'
  fields:                       # OPTIONAL, default is first line of files
   - field1
   - field2
   ...
  key: <field name for key>     # OPTIONAL, default is array of dict, otherwise dict of dict
```
Sample YAML fragment:
```yaml
- action: csv-read
  path: file.csv
  key: ap_name
```

### 7.4 csv-write
The action writes a CSV file. The output is the same as the input.

YAML fragment:
```yaml
- action: csv-write
  path: <path to CSV file>  # MANDATORY
  fields:                   # OPTIONAL
   - field1
   - field2
```

Sample YAML fragment:
```yaml
- action: csv-write
  path: aplist.csv
  fields:
  - public_ip_address
  - group_name
  - ip_address
  - macaddr
  - site
  - serial
  - name
  - model
```

### 7.5 eval
The action output is the result of the Python expression evaluation.

YAML fragment:
```yaml
- action: eval
  eval: <python eval>
```
Sample YAML fragment:
```yaml
- action: eval
  eval: '[{ "name": md["IP Address"], "url": "https://" + md["IP Address"] + ":4343", "clone": _self.rr_tname } for md, _self in zip(self.rr_adata, self.rr_self)]'
```

### 7.6 jfilter
The action runs the JSON path filter expression. The output is the result of the JSON path expression
evaluation against the input.
Please refer to:
https://goessner.net/articles/JsonPath/
https://github.com/kennknowles/python-jsonpath-rw
for details on syntax.

YAML fragment:
```yaml
- action: jfilter
  jfilter: <JSON path expression>
```
Sample YAML fragment:
```yaml
- action: jfilter
  jfilter: $."All Switches"[?(`this`."Type" = "MD")]
```

### 7.7 kwrite
The action writes to Kafka. The output is the same as the input.

YAML fragment:
```yaml
- action: kwrite
  topic: <topic>                              # MANDATORY <topic> is the key used when writing the record to Kafka.
  output: raw | standard                      # OPTIONAL <output> is either raw or standard. Default is standard.
                                              # When raw is specified, the output is written as-is to Kafka.
  label: <label>                              # OPTIONAL when <label> is specified, it overrides the label supplied
                                              # with the command line option --label.
  keys: { '<key>': {                          # MANDATORY <key> identifies the JSON output to rewrite. Please see below
                                              # for special handling of key ''.
          'name': '<rewrite key>',            # OPTIONAL <rewrite key> is the name used instead of <key> when writing out
                                              # the record to Kafka. For every key present in input data, its value is
                                              # written to Kafka prefixed with the rewrite key.
                                              # List values are written as individual records to Kafka.
          'etags': {                          # OPTIONAL <etags> is a dictionary of dynamically evaluated tag/value pairs.
                                              # Each <eval expression> is evaluated and the resulting value associated with
                                              # the <tag key> and written along with the record to Kafka. When <tag key>
                                              # starts with a . it will used as a relative name to the <rewrite key>
                                              # else as-is.
              '<tag key>': <eval expression>,
              ...
          },
        },
        ...
  }
```
NOTE: when key is '' then process all keys and use 'name' as a python format string to set the kafka message key based on the upper case of original key.
      i.e. keys: {'': {'name': 'CENTRAL_STREAMING_{}_MESSAGE', 'etags': { '.name': "self.IFLIST[self.INTF['#']]" }}}


Sample YAML fragment:
```yaml
- action: kwrite
  topic: ASW_RADIUS_SERVER
  keys: {'radius_server_element': {'name': 'asw.radius.server'}}
```

### 7.8 print
The action prints the input to an output stream. The action output is the same as the input.
When specified the options can be one of "string-in" or "pprint":
- "string-in" decodes the action data as printed string.
- "pprint" will format any structural data (e.g. dict) using pretty print.

When specified the output can be one of "user-log" (default) or "console":
- "user-log" outputs to the user-log file that was provided with the --user-log command line option.
- "console" outputs to the console (i.e. standard output)

YAML fragment:
```yaml
- action: print
  options: string-in|pprint   # OPTIONAL
  output: user-log|console    # OPTIONAL, default user-log
```

Sample YAML fragment:
```yaml
- action: print
```

### 7.9 rcommand
The action executes a named rcommand. The rcommand is executed in its own context. The
input sets the initial data for the input pipeline of the rcommand. The output is the
return value of the output pipeline of the rcommand.

YAML fragment:
```yaml
- action: rcommand
  name: <rcommand name>
```
Sample YAML fragment:
```yaml
- action: rcommand
  name: fetch_ap_database
```

### 7.10 s3upload
The action uploads data to S3

### 7.11 setvar
The action sets the named variable. The action output is the same as the input.
The value is a Python expression that is evaluated.
A mode of:
- "set" sets the variable with the resulting value.
- "append" appends the resulting value to the variable.
- "extend" extends the variable with resulting value.
- "update" updates the variable with the resulting value.
Note: append/extend apply to lists whereas update applies to dictionaries.

YAML fragment:
```yaml
- action: setvar
  name: <variable name>             # MANDATORY
  value: <python eval expression>   # OPTIONAL, default self.rr_adata
  mode: <set|append|extend|update>  # OPTIONAL, default extend
  scope: <local|global>             # OPTIONAL, default local
```

Sample YAML fragment:
```yaml
- action: setvar
  name: UPMD
  value: "[]"
  mode: set
```

### 7.12 table-parser
The action parses input as tables of data. The input can be either text or a JSON object with a key providing an array of text lines.
Output is a dictionary with following keys:
- "name": table name (typically the heading of the table CLI output)
- "header": an array of dictionaries with each dictionary having following keys:
            - "title": column title
- "rows": an array with each entry representing a table row.
          Each table row is an array itself with one entry per table column.

YAML fragment:
```yaml
- action: table-parser
  tables:               # MANDATORY, MUST have at least one table
    - <table options>   # <table options> is a dictionary of the form as described below.
    ...
```
Sample YAML fragment:
```yaml
- action: table-parser
  tables:
    - { 'parser': 'aos-dp-std', 'json.lines': '_data' }
```

#### 7.12.1 TABLE-OPTIONS

**table options** specifies following key/value pairs:
- "parser": "aos-std|aos-dp-std|generic-regex"
- "begin": "<begin>"
- "data.trim": false|true
- "end": "<end>"
- "json.lines": "<key>"
- "marker": "<marker>"

#### 7.12.2 TABLE PARSERS

Following table parsers are available (key 'parser'):
- "aos-std": understands standard AOS table output such as "show ap active", "show user", "show ap bss-table", etc...
- "aos-dp-std": understands standard AOS datapath table output such as "show datapath tunnel table", etc...
- "generic-regex": generic regular expression based table parser.

#### 7.12.3 COMMOM TABLE PARSER PARAMETERS

All parsers will honor following optional parameters:
- "begin": "<begin regex>". Defines a regular expression that will mark the beginning of the CLI output to use for parsing the table. This will typically be needed when the CLI output holds several tables. Default: None
- "end": "<end regex>". Defines a regular expression that will mark the end of the CLI output to use for parsing the table. This will typically be needed when the table has trailing output that is not part of the table. Default: None
- "marker": "<marker>". Provide table marker, such as "Active AP Table" for table "show ap active". Default None, which auto-detects the marker based on the first lines of output.
- "json.lines": "<key>". By default input is assumed to be text. When "json.lines" is specified, input is expected to be a JSON object where the "json.lines" provided key specifies an array of text lines, such as: { "_data": [ "line1", "line2", "line3" ] } (i.e. "json.lines": "_data"). Default: None
- "data.trim": true|false. When true, all table values have beginning and ending white-spaces trimmed. Default: true

#### 7.12.4 aos-std TABLE PARSER PARAMETERS

None in addition to the common table parser parameters.

#### 7.12.5 aos-dp-std TABLE PARSER PARAMETERS

None in addition to the common table parser parameters.

#### 7.12.6 generic-regex TABLE PARSER PARAMETERS

The generic regular expression based parser supports three broad use cases:
- header driven split-up based on spacing between column names, specify: "header.offset" and "data.offset" parameters and optionally "stop.on.empty.line".
- header driven split-up based on regex with named groups, specify: "header.offset", "header.regex" and "data.offset" parameters and optionally "stop.on.empty.line".
- data driven split-up based on regex with named groups, specify: "data.offset" and "data.regex" parameters and optionally "stop.on.empty.line" and/or "skip.partial.match".

Parameter details:
- NOTE: all offsets are relative to the FIRST non blank line in CLI output, i.e. offset 0 is the first non blank line.
- "header.offset": sets the relative offset of the header line.
- "header.regex": sets the regular expression to be used to break-up the header line.
- "data.offset": sets the relative offset of the first data line
- "data.regex": sets the regular expression to be used to break-up each data line.
- "stop.on.empty.line": true or false, defaults to true. When true, parsers stops on first blank/empty line.
- "skip.partial.match": true or false, defaults to false. When true, parser ignores data lines that don't match the data regular expression.

Sample YAML fragments:
```yaml
# Parse "show datapath utilization"
- action: table-parser
  tables:
    - { 'parser': 'generic-regex',
        'data.regex': '\\s+(?P<cpu>\\d+) \\| \\s+(?P<util1>\\d+)% \\| \\s+(?P<util4>\\d+)% \\| \\s+(?P<util64>\\d+)% \\|',
        'data.offset': 5 }
```
```yaml
# Parse "show airmatch optimization"
- action: table-parser
  tables:
    - { "parser": "generic-regex",
        "header.offset": 0,
        "header.regex": "(?P<Seq>Seq +)(?P<Time>Time +)(?P<APs> APs +)(?P<FiveGRadios>5GHz Radios +)(?P<TwoFourGRadios>2GHz Radios +)(?P<Type>Type) *",
        "data.offset": 2 }
```
```yaml
# Parse white-space separated columnar data
- action: table-parser
  tables:
    - { "parser": "generic-regex", "header.offset": 3, "data.offset": 4 }
```

### 7.13 wait
The action wait sleeps for a certain time (in seconds).
YAML fragment:
```yaml
 - action: wait
   time: <python eval expression>
```


## 8. VARIABLES

### 8.1 GLOBAL VARIABLES
Global variables are Python global objects that are available from all rcommands.
All variable names starting with rr* are reserved for RestRecorder.
- rr_context: not to be used directly.


### 8.2. LOCAL VARIABLES
Local variables are Python local objects that are available only to the current REST execution.
All variable names starting with rr* are reserved for RestRecorder.
- self.rr*
- self.rr_adata (current action input/output) [available from within an action]
- self.rr_result (current REST result) [available from within an action]
- self.rr_self is a generator that produces the value self continuously.
- self.rr_tname (current target name) [available from within an action]

### 8.3 ENVIRONMENT VARIABLES
RR_DEBUG_LOG sets the path to the rr_debug.log file. Default is ./rr_debug.log

## 9. Server Management

### 9.1 Signals Handling

When RR is running on a platform that supports signals (Linux and MacOS), handlers for several
signals are installed to allow interaction with the RR process without restarting the application.

So send a signal to the running process, you would need to find out the process ID of the 'Main.py'
process using command such as 'ps'

```bash
ps -aux | grep Main.py
```

Then the command 'kill' can be used to send a signal to the process using the process id.

```bash
kill -<signal_name> <pid>
```

#### 9.1.1 SIGINT (Ctrl-C)

When the RR process received the SIGINT signal, it will terminate.

```
kill -INT <pid>
```

#### 9.1.2 SIGUSR1

The SIGUSR1 signal toggles the logging level (of all loggers) between DEBUG and default (INFO)

```
kill -USR1 <pid>
```

#### 9.1.3 SIGUSR2

The SIGUSR2 signal would cause all process tasks to be displayed to the original terminal window

```
kill -USR2 <pid>
```

### 9.2 REST API / Web Server

A web server is also started with the RR application starts.  It listens at port 9988 by default which can be
configured by cli options (--web-server-port).  It is disabled by specifying 0 as the port number.  Several endpoints
are defined with output in JSON format.  Most of the endpoints supports the GET operation while some of them support
POST.

### 9.2.1 / or /status

Method: GET

Useful for checking whether the server is running.

Normal Output:
```
{"status": "ok"}
```

### 9.2.2 /info

Method: GET

Returns the configuration info about rest recorder.  (CLI options, targets/rcommand files)


### 9.2.3 /logging


Method: GET

Returns the logging level of individual sub-modules.

Method: POST

Set the individual logging level of sub-modules.  Use the output of GET /logging to retrieve a list of modules.

Usage:

First create a configuration file in JSON format with format similar to the following (d.json in example):

```JSON
{
  "level": "DEBUG",
  "loggers": ["restrecorder.dataparser",
              "restrecorder.WebServer",
              "restrecorder.targets.TargetCentralWs",
              "restrecorder.Kafka"]
}
```

And POST the data to Rest Recorder using 'curl'

```bash
 curl -X POST  http://localhost:9988/logging -d"@d.json" -H "Content-Type: application/json"
```

To change back to 'INFO'

```JSON
{
  "level": "INFO",
  "loggers": ["restrecorder.dataparser",
              "restrecorder.WebServer",
              "restrecorder.targets.TargetCentralWs",
              "restrecorder.Kafka"]
}
```

Logging is hierachical.  I.e. changing the 'restrecorder' logger will chage all the loggers for all modules.


### 9.2.4 /stats

Returns the statistics of the application on a variety of topics:
- Kafka partition distribution
- Kafka keys counts and keys
- Source counts and keys


## A. FEEDBACK
Feedback is welcome! Please send them to: tbastian@hpe.com.

## B. ACKNOWLEDGEMENTS
- Rafael Rivero for JFilter
