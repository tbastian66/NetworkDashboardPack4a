RestRecorder
------------

- Submits a set of predefined REST commands against REST enabled targets and records output.
  The output is saved in a file named 
    "rr-<target>-<date>-<time>-<id>.log".

For help, run with: 
bin/RestRecorder -h
 
Please read the HOWTO.html file for instructions.
